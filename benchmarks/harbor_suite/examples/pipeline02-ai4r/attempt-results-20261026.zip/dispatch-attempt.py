"""Attempt the real suite dispatcher; retain unavailable outcomes unchanged."""
import asyncio
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

from benchmarks.harbor_suite.adapter import dispatch, load_config
from benchmarks.harbor_suite.contracts import read_json, validate_bundle
from benchmarks.harbor_suite.grade import assess, load_oracle
from benchmarks.harbor_suite.prepare import prepare
from benchmarks.harbor_suite.report import summarize

REPO = Path(r'D:\Codex Development Runs\jiuwenswarm-pipeline02-ai4r')
ROOT = Path(r'D:\Codex Development Runs\pipeline02-ai4r-20261026')
IMAGE = 'python:3.12-slim-bookworm@sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')


async def main():
    ROOT.mkdir(exist_ok=False)
    assets = ROOT/'assets'
    with zipfile.ZipFile(REPO/'benchmarks/harbor_suite/assets/AI4Research-Benchmark-Cases-2026-10-26.zip') as archive:
        archive.extractall(assets)
    cases = assets/'AI4Research-Benchmark-Cases-2026-10-26/cases'
    bundle = ROOT/'bundle'
    prepare(bundle, cases_root=cases, case_ids=['pipeline02-recovery'], profile='smoke',
            expected_model='gpt-6.1-sol', python_image=IMAGE)
    index = validate_bundle(bundle)
    output = ROOT/'evidence'
    output.mkdir()
    config_path = ROOT/'suite-config.json'
    save(config_path, dict(schema='ai4r-harbor-suite-config:1', bundle_root=str(bundle),
                           output_root=str(output), mode='live'))
    config = load_config(config_path)
    outcomes, assessments = [], []
    for task in index['tasks']:
        folder, receipt, cancelled = await dispatch(config, task, 'ai4r-pipeline02-20261026-'+task['variant_id'])
        verifier = bundle/'tasks'/task['task_key']/'tests'
        assessment = assess(folder, task, read_json(verifier/'criteria.json'), load_oracle(verifier/'oracle.py'))
        save(folder/'assessment.json', assessment)
        outcomes.append(dict(variant=task['variant_id'], status=receipt['status'],
                             launched=receipt['launched'], blockers=receipt['blockers'],
                             native_run_id=None, correctness=assessment['case_correctness'],
                             assessment_status=assessment['status'], evidence_folder=str(folder)))
        assessments.append(assessment)
    report = summarize(index, assessments)
    save(ROOT/'report.json', report)
    from jiuwenswarm.research.contracts import ResearchError
    from jiuwenswarm.research.metric_contract import metric_protocol, validate_metric_ids
    from jiuwenswarm.research.trusted_scoring import parse_public_dataset
    scientific = dict(installed_metric_protocol=metric_protocol()['protocol_id']
                      if 'protocol_id' in metric_protocol() else metric_protocol())
    try:
        parse_public_dataset((cases/'pipeline02-recovery/public/cache-traces.json').read_bytes())
        scientific['classification_resource_parser']='accepted'
    except ResearchError as error:
        scientific['classification_resource_parser']=dict(code=error.code, detail=str(error))
    try:
        validate_metric_ids(['hits','misses','miss_ratio'])
        scientific['cache_metric_admission']='accepted'
    except ResearchError as error:
        scientific['cache_metric_admission']=dict(code=error.code, detail=str(error))
    result = dict(date='2026-10-26', recorded_at=datetime.now(timezone.utc).isoformat(),
                  source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
                  branch='benchmark/pipeline02-ai4r', requested_mode='live',
                  scope='Actual suite dispatch attempt; no native E1 application request launched',
                  variants=outcomes, scientific_binding_checks=scientific,
                  native_application_requests=0, model_calls=0,
                  full_task_success=None, services_and_ports_unchanged=True)
    save(ROOT/'RESULT.json', result)
    save(ROOT/'source-pins.json', {name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() for name in [
        'benchmarks/harbor_suite/adapter.py','benchmarks/harbor_suite/deployment.py',
        'jiuwenswarm/research/metric_contract.py','jiuwenswarm/research/local_science.py']})
    print(json.dumps(dict(variants=outcomes, native_application_requests=0, model_calls=0),indent=2))


if __name__=='__main__':
    asyncio.run(main())
