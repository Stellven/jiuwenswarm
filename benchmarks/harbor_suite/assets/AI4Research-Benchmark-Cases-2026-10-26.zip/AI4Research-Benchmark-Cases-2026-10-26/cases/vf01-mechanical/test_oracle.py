"""Oracle unit tests only. Synthetic records below are NOT campaign evidence."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('vf01_oracle', ROOT / 'oracle.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
CRITERIA = json.loads((ROOT / 'referee/criteria.json').read_text())


def synthetic(variant):
    """Exercise only the checker; these locally minted Refs grant no authority."""
    label = CRITERIA['variants'][variant]
    rows = []
    def add(kind, data):
        ref = {'id': 'unit-only:' + str(len(rows)), 'sha256': hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()}
        rows.append(dict(kind=kind, ref=ref, record=data))
        return ref
    request = add('request', {'entry_point': 'E2'})
    source = {'id': 'unit-only-source', 'sha256': 'a' * 64}
    scope = add('scope', {'source_contract_ref': source, 'selected_output_port': 'result'})
    raw = (ROOT / 'public' / (variant + '.json')).read_text(encoding='utf-8')
    output = dict(id='unit-only-output', sha256=hashlib.sha256(raw.encode()).hexdigest())
    plan = add('check_plan', {'mandatory_deterministic': ['unit-only-obligation']})
    traces = []
    artifacts = {'submitted.json': raw}
    if label['cause'] == 'environment':
        content = "ModuleNotFoundError: No module named 'vf01_optional_fft'\n"
        trace = dict(id='unit-only-trace', sha256=hashlib.sha256(content.encode()).hexdigest())
        artifacts['trace.txt'] = content
        traces = [dict(path='trace.txt', ref=trace)]
    observed = add('source_observation', dict(contract_ref=source,
                    outcome='budget_exhausted' if label['cause'] == 'timeout' else 'failed' if label['cause'] == 'environment' else 'success',
                    duration_s=1.1 if label['cause'] == 'timeout' else 0.1,
                    failure_class='infrastructure' if label['cause'] == 'environment' else 'none', trace_refs=[t['ref'] for t in traces]))
    checked = add('deterministic_result', dict(subject_ref=output, check_plan_ref=plan,
                  results=[dict(check_id='unit-only-obligation', outcome=label['tier1'], reason='Unit checker exercise', evidence_refs=[output])]))
    assessments = []
    if label['tier2'] == 'PASS':
        assessments = [add('assessment', dict(verdict='PASS'))]
        add('model_call', dict(call_function='verifier'))
    measurement = add('measurement', dict(contract_ref=source, observation_ref=observed, deterministic_ref=checked,
                      output_refs={'result': output}, assessment_refs=assessments, verifier_check_refs=[]))
    result = add('result', {'result': dict(evidence_refs=[measurement], tier1_verdict=label['tier1'],
                 tier2_verdict=label['tier2'], advanced=label['action'] == 'advance', gate_decision=dict(verdict=label['verdict'],
                 action=label['action'], deterministic_result_ref=checked))})
    return dict(variant_id=variant, entrypoint='node_replay', records=rows, artifacts=artifacts,
                module_observations={'vf01_e2': dict(request_ref=request, scope_ref=scope, measurement_ref=measurement,
                                     result_ref=result, output_path='submitted.json', trace_paths=traces)})


def statuses(result):
    return {r['id']: r['status'] for r in result['checks']}


class OracleTests(unittest.TestCase):
    def test_each_label_with_bound_synthetic_evidence(self):
        for variant in CRITERIA['variants']:
            with self.subTest(variant=variant):
                result = oracle.evaluate(synthetic(variant), CRITERIA)
                self.assertNotIn('fail', statuses(result).values())
                self.assertEqual(statuses(result)['live_gate_causality'], 'unavailable')
                self.assertEqual(result['metrics']['exact_classification_numerator'], 3)

    def test_missing_capture_and_unbound_boolean_never_pass(self):
        result = oracle.evaluate(dict(variant_id='timeout', module_observations={'enforced': True}), CRITERIA)
        self.assertEqual(statuses(result)['original_binding'], 'unavailable')

    def test_original_bytes_must_match(self):
        e = synthetic('valid'); e['artifacts']['submitted.json'] += ' '
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['original_binding'], 'fail')

    def test_missing_record_is_unavailable(self):
        e = synthetic('valid'); e['records'] = e['records'][1:]
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['original_binding'], 'unavailable')

    def test_actual_tier1_failure_required(self):
        e = synthetic('missing-field')
        row = next(r for r in e['records'] if r['kind'] == 'deterministic_result')
        row['record']['results'][0]['outcome'] = 'PASS'
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['tier1'], 'fail')

    def test_tier2_call_on_mechanical_failure_is_failure(self):
        e = synthetic('missing-field'); e['records'].append(dict(kind='model_call', ref={'id':'unit-call','sha256':'b'*64}, record=dict(call_function='verifier')))
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['tier2'], 'fail')

    def test_false_advance_is_critical(self):
        e = synthetic('stale-experiment')
        r = next(r['record']['result'] for r in e['records'] if r['kind'] == 'result')
        r['advanced'] = True; r['gate_decision']['action'] = 'advance'
        self.assertIn('false_advance', oracle.evaluate(e, CRITERIA)['critical_violations'])

    def test_environment_verdict_not_collapsed_to_fail(self):
        e = synthetic('dependency-unavailable')
        next(r['record']['result'] for r in e['records'] if r['kind'] == 'result')['gate_decision']['verdict'] = 'FAIL'
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['exact_verdict_action'], 'fail')

    def test_runtime_timeout_needs_original_observation(self):
        e = synthetic('timeout')
        next(r['record'] for r in e['records'] if r['kind'] == 'source_observation')['outcome'] = 'success'
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['independent_defect'], 'fail')

    def test_environment_needs_trace(self):
        e = synthetic('dependency-unavailable'); e['module_observations']['vf01_e2']['trace_paths'] = []
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['independent_defect'], 'unavailable')

    def test_duplicate_original_ref_is_unavailable(self):
        e = synthetic('valid'); e['records'].append(copy.deepcopy(e['records'][0]))
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['original_binding'], 'unavailable')

    def test_replay_cannot_prove_actual_live_release(self):
        e = synthetic('delayed-persistence'); e['module_observations']['live_gate'] = {'mode':'actual','held':True,'correct':True}
        self.assertEqual(statuses(oracle.evaluate(e, CRITERIA))['live_gate_causality'], 'unavailable')


if __name__ == '__main__':
    unittest.main()
