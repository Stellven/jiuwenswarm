"""Protected deterministic DEVELOPMENT checker; never executes submitted code."""
import ast
import hashlib
import json
import math


class Missing(ValueError):
    pass


def evaluate(evidence, criteria):
    checks, violations = [], []
    label = criteria.get('variants', {}).get(evidence.get('variant_id'))
    def emit(ident, status, reason, refs=()):
        checks.append(dict(id=ident, status=status, reason=reason, evidence_refs=list(refs)))
    if label is None:
        emit('variant', 'unavailable', 'No independently frozen label for this variant')
        return dict(checks=checks, metrics={}, critical_violations=[])
    rows = evidence.get('records', [])
    def get(ref, kind):
        matches = [r for r in rows if r.get('ref') == ref and r.get('kind') == kind]
        if len(matches) != 1:
            raise Missing('Exact original ' + kind + ' record absent or ambiguous')
        return matches[0]['record']
    def text(path, ref):
        raw = evidence.get('artifacts', {}).get(path)
        if not isinstance(raw, str):
            raise Missing('Original UTF-8 artifact absent')
        if hashlib.sha256(raw.encode('utf-8')).hexdigest() != ref.get('sha256'):
            raise ValueError('Original artifact bytes differ from selected output Ref')
        return raw
    projection = evidence.get('module_observations', {}).get('vf01_e2')
    try:
        if not isinstance(projection, dict):
            raise Missing('Validated EvaluationRecords E2 projection unavailable')
        request = get(projection['request_ref'], 'request')
        scope = get(projection['scope_ref'], 'scope')
        measured = get(projection['measurement_ref'], 'measurement')
        response = get(projection['result_ref'], 'result')['result']
        deterministic = get(measured['deterministic_ref'], 'deterministic_result')
        basis = get(deterministic['check_plan_ref'], 'check_plan')
        observed = get(measured['observation_ref'], 'source_observation')
        selected = measured['output_refs'][scope['selected_output_port']]
        raw = text(projection['output_path'], selected)
        payload = json.loads(raw)
        if request['entry_point'] != 'E2' or evidence.get('entrypoint') != 'node_replay':
            raise ValueError('Wrong entry point')
        if measured['contract_ref'] != scope['source_contract_ref'] or observed['contract_ref'] != measured['contract_ref']:
            raise ValueError('Selected measurement/source contract join differs')
        if deterministic['subject_ref'] != selected or response['evidence_refs'][0] != projection['measurement_ref']:
            raise ValueError('Checks or response target another measured subject')
        if hashlib.sha256(raw.encode()).hexdigest() != label['submission_sha256']:
            raise ValueError('Replay did not inspect the frozen variant submission')
        refs = [projection['measurement_ref'], measured['deterministic_ref'], measured['observation_ref'], selected]
        emit('original_binding', 'pass', 'Original selected measurement, checks and frozen bytes joined', refs)
    except Missing as exc:
        emit('original_binding', 'unavailable', str(exc))
        emit('live_gate_causality', 'unavailable', 'Isolated E2 replay cannot establish live scheduler locking')
        return dict(checks=checks, metrics={'judged_score_share': 0}, critical_violations=[])
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        emit('original_binding', 'fail', str(exc))
        return dict(checks=checks, metrics={'judged_score_share': 0}, critical_violations=[])

    # Recompute defect from exact frozen subject bytes or original runtime capture.
    cause = label['cause']
    valid_schema = (isinstance(payload, dict) and set(payload) == {'experiment_digest', 'capsule_digest', 'median_ms', 'sample_count', 'code'}
                    and type(payload['median_ms']) in (int, float) and math.isfinite(payload['median_ms'])
                    and type(payload['sample_count']) is int and payload['sample_count'] > 0
                    and all(isinstance(payload[k], str) for k in ('experiment_digest', 'capsule_digest', 'code')))
    cause_ok = valid_schema
    if cause == 'schema':
        cause_ok = not valid_schema
    elif cause == 'stale':
        cause_ok = payload.get('experiment_digest') != criteria['experiment_digest']
    elif cause == 'capsule':
        cause_ok = payload.get('capsule_digest') != criteria['capsule_digest']
    elif cause == 'prohibited':
        tree = ast.parse(payload['code'])
        cause_ok = any(isinstance(n, ast.Import) and any(a.name.split('.')[0] in criteria['forbidden_modules'] for a in n.names)
                       or isinstance(n, ast.ImportFrom) and (n.module or '').split('.')[0] in criteria['forbidden_modules']
                       for n in ast.walk(tree))
    elif cause == 'timeout':
        cause_ok = (observed.get('outcome') == 'budget_exhausted'
                    and type(observed.get('duration_s')) in (int, float)
                    and observed['duration_s'] >= label['runtime_limit_s'])
    elif cause == 'environment':
        try:
            traces = projection.get('trace_paths', [])
            captures = [text(t['path'], t['ref']) for t in traces if t['ref'] in observed.get('trace_refs', [])]
            if not captures:
                raise Missing('Original dependency failure trace unavailable')
            cause_ok = (observed.get('failure_class') == 'infrastructure'
                        and any("ModuleNotFoundError: No module named 'vf01_optional_fft'" in t for t in captures))
        except Missing as exc:
            cause_ok = None
            emit('independent_defect', 'unavailable', str(exc), refs)
    if cause_ok is not None:
        emit('independent_defect', 'pass' if cause_ok else 'fail', 'Frozen ' + cause + ' predicate independently recomputed', refs)

    try:
        mandatory = basis['mandatory_deterministic']
        results = deterministic['results']
        ids = [r['check_id'] for r in results]
        if not mandatory or len(ids) != len(set(ids)) or not set(mandatory).issubset(ids):
            raise Missing('Original mandatory check population unavailable or ambiguous')
        actual_tier1 = 'PASS' if all(r['outcome'] == 'PASS' for r in results if r['check_id'] in mandatory) else 'FAIL'
        emit('tier1', 'pass' if response['tier1_verdict'] == actual_tier1 == label['tier1'] else 'fail',
             'Actual mandatory deterministic outcomes versus exact frozen Tier-1 label', refs)
        calls = [r for r in rows if r.get('kind') == 'model_call' and r['record'].get('call_function') == 'verifier']
        assessments = measured['assessment_refs']
        actual_tier2 = get(assessments[0], 'assessment')['verdict'] if len(assessments) == 1 else 'NOT_RUN'
        no_semantic = label['tier2'] != 'NOT_RUN' or (not calls and not assessments and not measured['verifier_check_refs'])
        emit('tier2', 'pass' if no_semantic and response['tier2_verdict'] == actual_tier2 == label['tier2'] else 'fail',
             'Original assessment and captured verifier call population; NOT_RUN requires zero calls', refs)
        decision = response['gate_decision']
        exact = decision['verdict'] == label['verdict'] and decision['action'] == label['action']
        exact = exact and decision['deterministic_result_ref'] == measured['deterministic_ref']
        exact = exact and response['advanced'] is (label['action'] == 'advance')
        emit('exact_verdict_action', 'pass' if exact else 'fail', 'Preserve exact verdict and replay advance/halt classification', refs)
        if label['action'] == 'halt' and (response['advanced'] or decision['action'] == 'advance'):
            violations.append('false_advance')
        reasons = [r for r in results if r['outcome'] != 'PASS'] if label['tier1'] == 'FAIL' else results
        explained = bool(reasons) and all(r.get('reason') and r.get('evidence_refs') for r in reasons)
        emit('attributed_reason', 'pass' if explained else 'fail', 'Original checker reasons must cite evidence for violated obligations', refs)
    except Missing as exc:
        emit('tier_classification', 'unavailable', str(exc), refs)
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        emit('tier_classification', 'fail', str(exc), refs)
    # Recording scheduler actions are expressly not live causality evidence.
    emit('live_gate_causality', 'unavailable', 'Requires actual live persisted gate/acceptance commits, successor starts or locked-node evidence and held barrier capture; E2 recording replay is insufficient')
    return dict(checks=checks, metrics={'judged_score_share': 0,
                'exact_classification_numerator': sum(c['status'] == 'pass' for c in checks if c['id'] in {'tier1', 'tier2', 'exact_verdict_action'}),
                'exact_classification_denominator': 3,
                'live_gate_available': 0}, critical_violations=violations)
