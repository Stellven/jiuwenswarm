# VF01 mechanical verification

All nine fixtures are DEVELOPMENT material. The research obligation concerns
integer lookup caching on supplied, frozen latency observations; this case makes
no empirical speedup or production performance claim. The original submitted
JSON is replayed unchanged, even when it violates the declared output obligation.
The protected checker parses Python with `ast` and never imports submitted code.

Requirements 12.1 checklist: #2 missing field/wrong type; #3 stale experiment and
swapped capsule digest; #5 forced timeout; #6 prohibited import; #7 dependency
unavailable; #10 delayed persistence. A valid counterpart also covers #1 at the
isolated classification level. VF02 supplies semantic cases #1/#4/#8/#9. Digest
tags in fixtures identify research material, not fabricated product run IDs.

`evaluate(evidence, criteria)` uses only stdlib and the AUTHORING normalized
interface. Protected `referee/criteria.json` fixes exact original verdicts before
execution. Zero LLM judges; no model verdict, shell exit, or self-reported
enforcement boolean is ground truth. Unit tests use synthetic records solely to
exercise this checker and are not product/campaign observations.

## Required adapter binding

The parent must first authenticate and completely validate an original
`EvaluationRecords` E2 export, including its source closure, publication ownership,
captured model-call population, source node/output port, scope and expected
request/campaign. Only then expose all original typed records with their original
Refs. `module_observations.vf01_e2` must contain `request_ref`, `scope_ref`,
`measurement_ref`, `result_ref` and `output_path`. These refs resolve respectively
to original `request`, `scope`, `measurement`, and `result` records. `result` retains
its original outer wrapper and nested `result`. `output_path` names the selected
original UTF-8 output in `artifacts`; its hash must match the measured selected
output Ref. Preserve `deterministic_result`, `check_plan`, `source_observation`,
`model_call` and `assessment` original kinds. For environment failure, supply
`trace_paths: [{path, ref}]` for original trace bytes already referenced by the
source observation. No case-authored ID replaces a real source contract.

Schema, stale and capsule cases require an admitted actual output contract/check
bundle enforcing this public obligation. Runtime variants require a protected
campaign fault plan and original observations, not submitted timeout/dependency
claims. Timeout requires original `budget_exhausted` and duration at least the
frozen one-second bound; environment requires original infrastructure failure
and an exact referenced ModuleNotFoundError trace for vf01_optional_fft. Missing
fixtures/bindings are unavailable, never substituted with model-generated logs.

Current `EvaluationRecords._response_closure` forces replay mechanical failure's
gate verdict to FAIL; it cannot presently express the required exact environment
ENVIRONMENT_BLOCKED outcome. The frozen expectation is preserved: an authentic
FAIL export fails classification rather than silently normalizing this mismatch.
Environment's recorded human-review action needs a supported original capture;
it is not established by this replay checker and remains a campaign obligation.

The replay result's `gate_decision` has `invalid_for_product: true` and its optional
recording scheduler is not actual live scheduler proof. Consequently
`live_gate_causality` always reports unavailable here, including the delay variant.
Actual #10 needs a separate real live run joined through accepted output commits,
advancing node gate Refs, exact successor consumed inputs, starts/locked-node
observations and a held persistence barrier, following `validate_live_order` in
the maintained verifier adapter. Missing live capture blocks acceptance, even
when isolated tier classifications pass. No live causality performance is claimed.

Run `python -m unittest discover -s benchmarks/harbor_suite/cases/vf01-mechanical`.
