# Frozen lookup-cache observation obligation

Compare the supplied repeated-key lookup observations. A submission is a JSON
object with exactly experiment_digest (SHA-256 of the original experiment JSON),
capsule_digest (the declared implementation identity), median_ms (finite number),
sample_count (positive integer), and code (Python source string).
The declared implementation identity is SHA-256 of the UTF-8 string
`lookup-cache-capsule-development-v1`. Report the treatment median in milliseconds
and its sample count. Keep observation provenance exact. Submitted code is reviewed
without executing it. Imports of os, sys, subprocess, requests, urllib, shutil or
importlib are prohibited. No tool beyond reading the supplied inputs is declared.
The runtime capture has a one-second execution budget. Unavailable dependencies
must be distinguished from an incorrect artifact and halt for human review.
Workflow release requires a durable advancing gate decision.
