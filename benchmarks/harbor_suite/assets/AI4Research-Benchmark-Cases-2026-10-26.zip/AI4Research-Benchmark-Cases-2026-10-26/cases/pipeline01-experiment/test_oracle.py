"""Oracle unit tests only: constructed records confer no product authority."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from oracle import evaluate, recompute

spec = importlib.util.spec_from_file_location('unit_reference', ROOT / 'public/reference_index.py')
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)
CRITERIA = json.loads((ROOT / 'referee/criteria.json').read_text(encoding='utf-8'))


def fixture(variant='sparse-positive'):
    """Minimal original-field projections for oracle logic, not schema/custody tests."""
    evidence = {'variant_id': variant, 'entrypoint': 'run', 'execution': {
        'launched': True, 'terminal': True, 'status': 'completed', 'app_run_id': 'oracle-unit-only'},
        'records': [], 'artifacts': {}, 'module_observations': {}}

    def put(kind, value):
        raw = json.dumps(value, sort_keys=True)
        ref = {'id': 'unit-' + str(len(evidence['artifacts'])), 'sha256': hashlib.sha256(raw.encode()).hexdigest()}
        evidence['artifacts']['unit/' + ref['id'] + '.json'] = raw
        if kind:
            evidence['records'].append({'kind': kind, 'ref': ref, 'record': value})
        return ref

    def text(raw):
        ref = {'id': 'unit-' + str(len(evidence['artifacts'])), 'sha256': hashlib.sha256(raw.encode()).hexdigest()}
        evidence['artifacts']['unit/' + ref['id'] + '.txt'] = raw
        return ref

    rule = CRITERIA['variants'][variant]
    generic = put(None, {'unit_test_only': True})
    plan = {'frozen': True, 'plan_source': 'static', 'nodes': [], 'topological_order': []}
    for i, stage in enumerate(CRITERIA['required_stages']):
        name = stage.split('.')[1]
        plan['nodes'].append({'node_id': name, 'cc': {'cc_name': stage, 'cc_version': 'unit', 'declaration_sha256': generic['sha256']},
                              'predecessors': [] if i == 0 else [CRITERIA['required_stages'][i-1].split('.')[1]]})
        plan['topological_order'].append(name)
    put('run-plan', plan)
    for name in ('intention_compiler', 'planner'):
        put('gate-decision', {'scope_kind': 'node', 'node_id': name, 'run_id': 'oracle-unit-only', 'action': 'advance'})
    run_rows = []
    if rule['expected'] == 'complete':
        for repeat in range(3):
            for role in ('baseline', 'treatment'):
                raw = reference.run(rule['workload'], role, repeat)
                stdout = put(None, raw)
                run_rows.append({'role': role, 'repeat_index': repeat, 'seed': rule['seed'],
                    'stdout_ref': stdout, 'exit_code': 0, 'wall_time_s': 0.001,
                    'command': ['python', 'reference_index.py', '--role', role]})
        receipt = put('execution-receipt', {'blueprint_ref': generic, 'runs': run_rows,
            'hardware_inventory': {'cpu_model': 'oracle-unit-only', 'cpu_cores': 1, 'ram_mb': 256,
                                   'os': 'oracle-unit-only', 'captured_at': '2026-01-01T00:00:00Z'}})
        payload = put('benchmark-payload', {'repeat_count': 3, 'seed': rule['seed'], 'execution_receipt_ref': receipt})
        truth = recompute(rule['workload'])
        classification = 'PASS' if sum(t['treatment'] for t in truth) < sum(t['baseline'] for t in truth) else 'FAIL'
        verdict = put('evaluation-verdict', {'classification': classification, 'benchmark_ref': payload, 'blueprint_ref': generic})
    previous, evaluation_gate = [generic], None
    for i, node in enumerate(plan['nodes']):
        name = node['node_id']
        halt = rule['expected'] == 'halt' and name == rule['halt_node']
        if name == 'benchmark':
            outputs = [payload]
        elif name == 'evaluation':
            outputs = [verdict]
        elif name == 'delivery':
            report = text('Scientific ' + classification + ': posting mutations. Actual latency in ns is descriptive.')
            outputs = [put('delivery-manifest', {'verdict_ref': verdict, 'report_ref': report,
                'missing_evidence': [], 'gate_decision_refs': [evaluation_gate]})]
        else:
            outputs = [put(None, {'unit_stage': name})]
        contract = put('node-execution-contract', {'run_id': 'oracle-unit-only', 'node_id': name,
                        'attempt_id': name + '-a1', 'input_refs': previous})
        obs = put('invocation-observation', dict(node['cc'], node_id=name, node_contract_ref=contract,
            run_id='oracle-unit-only', input_refs=previous, output_refs=outputs, observed_runtime=True,
            outcome='success', measurement_status='observed', started_at=f'2026-01-01T00:{i+1:02d}:00Z'))
        checked = put('deterministic-check-result', {'check_plan_ref': generic, 'results': [
            {'outcome': 'FAIL' if halt else 'PASS', 'reason': 'unit ns conflicts with ms' if halt else 'unit fixture'}]})
        assessment = put('verifier-assessment', {'verdict': 'PASS'})
        gate = put('gate-decision', {'scope_kind': 'node', 'run_id': 'oracle-unit-only', 'node_id': name,
            'attempt_id': name + '-a1', 'node_contract_ref': contract, 'invocation_refs': [obs],
            'recorded_at': f'2026-01-01T00:{i+1:02d}:30Z',
            'deterministic_result_ref': checked, 'check_plan_ref': generic, 'assessment_ref': assessment,
            'action': 'halt' if halt else 'advance', 'verdict': 'FAIL' if halt else 'PASS',
            'accepted_refs': [] if halt else outputs, 'output_refs': outputs})
        if name == 'evaluation':
            evaluation_gate = gate
        previous = outputs
        if halt:
            evidence['execution']['status'] = 'halted'
            break
    return evidence


class OracleTests(unittest.TestCase):
    def assert_pass(self, evidence):
        result = evaluate(evidence, CRITERIA)
        self.assertEqual(result['metrics']['full_task_success'], 1, result)
        self.assertTrue(all(c['status'] == 'pass' for c in result['checks']), result)
        return result

    def test_positive(self):
        self.assertEqual(self.assert_pass(fixture())['metrics']['scientific_result'], 'PASS')

    def test_genuine_negative_delivers(self):
        self.assertEqual(self.assert_pass(fixture('dense-negative'))['metrics']['scientific_result'], 'FAIL')

    def test_conflict_halts(self):
        self.assert_pass(fixture('conflicting-units'))

    def test_missing_evidence_never_passes(self):
        result = evaluate({'variant_id': 'sparse-positive', 'entrypoint': 'run'}, CRITERIA)
        self.assertEqual(result['checks'][-1]['status'], 'unavailable')
        self.assertIsNone(result['metrics']['full_task_success'])

    def test_claimed_projection_ignored(self):
        evidence = {'variant_id': 'sparse-positive', 'entrypoint': 'run', 'execution': {'launched': True, 'terminal': True},
                    'module_observations': {'pipeline01': {'complete': True, 'speedup': 50}}}
        self.assertEqual(evaluate(evidence, CRITERIA)['checks'][-1]['status'], 'unavailable')

    def test_missing_stdout_unavailable(self):
        evidence = fixture()
        evidence['artifacts'] = {}
        self.assertEqual(evaluate(evidence, CRITERIA)['checks'][-1]['status'], 'unavailable')

    def test_negative_cannot_be_relabelled(self):
        evidence = fixture('dense-negative')
        next(r['record'] for r in evidence['records'] if r['kind'] == 'evaluation-verdict')['classification'] = 'PASS'
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_dropped_stage(self):
        evidence = fixture()
        next(r['record'] for r in evidence['records'] if r['kind'] == 'run-plan')['nodes'].pop(2)
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_binding_substitution(self):
        evidence = fixture()
        next(r['record'] for r in evidence['records'] if r['kind'] == 'invocation-observation')['cc_version'] = 'substitute'
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_missing_invocation(self):
        evidence = fixture()
        evidence['records'] = [r for r in evidence['records'] if r['kind'] != 'invocation-observation']
        self.assertEqual(evaluate(evidence, CRITERIA)['checks'][-1]['status'], 'unavailable')

    def test_failed_mechanical_gate(self):
        evidence = fixture()
        next(r['record'] for r in evidence['records'] if r['kind'] == 'deterministic-check-result')['results'][0]['outcome'] = 'FAIL'
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_failed_semantic_gate(self):
        evidence = fixture()
        next(r['record'] for r in evidence['records'] if r['kind'] == 'verifier-assessment')['verdict'] = 'FAIL'
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_cross_run_rejected(self):
        evidence = fixture()
        next(r['record'] for r in evidence['records'] if r['kind'] == 'invocation-observation')['run_id'] = 'foreign'
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_raw_recompute_catches_corruption(self):
        evidence = fixture()
        receipt = next(r['record'] for r in evidence['records'] if r['kind'] == 'execution-receipt')
        ref = receipt['runs'][0]['stdout_ref']
        name = next(k for k, value in evidence['artifacts'].items() if hashlib.sha256(value.encode()).hexdigest() == ref['sha256'])
        raw = json.loads(evidence['artifacts'][name])
        raw['batches'][0]['answers']['cpu'] = []
        evidence['artifacts'][name] = json.dumps(raw)
        ref['sha256'] = hashlib.sha256(evidence['artifacts'][name].encode()).hexdigest()
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_missing_delivery_does_not_pass(self):
        evidence = fixture('dense-negative')
        evidence['records'] = [r for r in evidence['records'] if r['kind'] != 'delivery-manifest']
        self.assertEqual(evaluate(evidence, CRITERIA)['checks'][-1]['status'], 'unavailable')

    def test_dispatch_before_gate_fails(self):
        evidence = fixture()
        observations = [r['record'] for r in evidence['records'] if r['kind'] == 'invocation-observation']
        observations[1]['started_at'] = '2026-01-01T00:00:00Z'
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_duplicate_repeat_fails(self):
        evidence = fixture()
        receipt = next(r['record'] for r in evidence['records'] if r['kind'] == 'execution-receipt')
        receipt['runs'][2]['repeat_index'] = 0
        self.assertEqual(evaluate(evidence, CRITERIA)['metrics']['full_task_success'], 0)

    def test_baseline_source_actually_runs(self):
        for variant in ('sparse-positive', 'dense-negative'):
            for role in ('baseline', 'treatment'):
                process = subprocess.run([sys.executable, str(ROOT/'public/reference_index.py'), str(ROOT/'public'/f'{variant}.json'),
                    '--role', role, '--repeat', '0'], capture_output=True, text=True, check=True, timeout=10)
                raw = json.loads(process.stdout)
                expected = recompute(CRITERIA['variants'][variant]['workload'])
                for actual, truth in zip(raw['batches'], expected):
                    self.assertEqual(actual['answers'], truth['answers'])
                    self.assertEqual(actual['postings_sha256'], truth['postings_sha256'])
                    self.assertEqual(actual['operations'], truth[role])
                    self.assertIs(type(actual['elapsed_ns']), int)

    def test_source_rejects_conflicting_units(self):
        process = subprocess.run([sys.executable, str(ROOT/'public/reference_index.py'), str(ROOT/'public/conflicting-units.json'),
            '--role', 'baseline'], capture_output=True, text=True, timeout=10)
        self.assertNotEqual(process.returncode, 0)
        self.assertFalse(process.stdout)


if __name__ == '__main__':
    unittest.main()
