"""Independent stdlib DEVELOPMENT checker over custody-validated originals.

Never executes candidate code. Recomputes expected retrieval and logical work
from protected frozen workloads, separately from the public reference program.
Raw elapsed times are checked for provenance/units, never inferred or invented.
"""
import datetime
import hashlib
import json
import re
import statistics


class Missing(Exception):
    pass


def refkey(ref):
    if not isinstance(ref, dict) or not ref.get('id') or not re.fullmatch('[a-f0-9]{64}', ref.get('sha256', '')):
        raise Missing('Original artifact Ref unavailable')
    return ref['id'], ref['sha256']


def recompute(workload):
    """Direct document scan; deliberately does not import public index code."""
    docs = dict(workload['documents'])
    expected = []
    for changes in workload['batches']:
        mutations = 0
        for ident, text in changes:
            mutations += len(set(re.findall('[a-z0-9]+', docs.get(ident, '').lower())))
            if text is None:
                docs.pop(ident, None)
            else:
                docs[ident] = text
                mutations += len(set(re.findall('[a-z0-9]+', text.lower())))
        words = {ident: set(re.findall('[a-z0-9]+', text.lower())) for ident, text in docs.items()}
        vocabulary = sorted(set().union(*words.values())) if words else []
        postings = {term: sorted(ident for ident, terms in words.items() if term in terms) for term in vocabulary}
        digest = hashlib.sha256(json.dumps(postings, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        answers = {}
        for query in workload['queries']:
            terms = set(re.findall('[a-z0-9]+', query.lower()))
            answers[query] = sorted(ident for ident, terms_doc in words.items() if terms and terms <= terms_doc)
        expected.append({'baseline': sum(map(len, words.values())), 'treatment': mutations,
                         'postings_sha256': digest, 'answers': answers})
    return expected


def evaluate(evidence, criteria):
    checks, refs, critical = [], [], []
    metrics = {'full_task_success': None, 'composition_success': None,
               'retrieval_exact_fraction': None, 'median_update_ns': None,
               'scientific_result': None, 'human_review_required': True}

    def check(ident, ok, reason):
        checks.append({'id': ident, 'status': 'pass' if ok else 'fail',
                       'reason': reason, 'evidence_refs': list(refs)})

    try:
        rule = criteria['variants'].get(evidence.get('variant_id'))
        if not rule or evidence.get('entrypoint') != 'run':
            raise Missing('Scheduled E1 variant unavailable')
        execution = evidence.get('execution', {})
        if not execution.get('launched') or not execution.get('terminal'):
            raise Missing('No collected terminal E1 attempt')
        rows = evidence.get('records', [])
        by_ref = {}
        for row in rows:
            key = refkey(row.get('ref'))
            if key in by_ref:
                raise ValueError('Duplicate original Ref')
            by_ref[key] = row

        def record(ref, kind=None):
            row = by_ref.get(refkey(ref))
            if row is None:
                raise Missing('Referenced original record not collected')
            if kind and row.get('kind') != kind:
                raise ValueError('Wrong original record kind: ' + str(kind))
            if ref not in refs:
                refs.append(ref)
            return row['record']

        def unique(kind):
            found = [row for row in rows if row.get('kind') == kind]
            if not found:
                raise Missing('Original ' + kind + ' not collected')
            if len(found) != 1:
                raise ValueError('Ambiguous original ' + kind)
            return found[0]['ref'], record(found[0]['ref'], kind)

        def blob(ref):
            refkey(ref)
            found = {raw for raw in evidence.get('artifacts', {}).values()
                     if isinstance(raw, str) and hashlib.sha256(raw.encode('utf-8')).hexdigest() == ref['sha256']}
            if not found:
                raise Missing('Original UTF-8 bytes for referenced artifact not collected')
            if len(found) != 1:
                raise ValueError('Ambiguous original bytes')
            if ref not in refs:
                refs.append(ref)
            return found.pop()

        plan_ref, plan = unique('run-plan')
        stages = criteria['required_stages']
        nodes = plan['nodes']
        check('fixed-full-lifecycle', plan.get('plan_source') == 'static' and plan.get('frozen') is True
              and len(nodes) >= 4 and [n['cc']['cc_name'] for n in nodes] == stages,
              'Frozen static plan must preserve all seven required research stages.')
        if [n['cc']['cc_name'] for n in nodes] != stages:
            raise ValueError('Required lifecycle stage omitted/substituted')
        ids = [n['node_id'] for n in nodes]
        check('graph-closure', len(set(ids)) == len(ids) and plan.get('topological_order') == ids
              and all(set(n['predecessors']) <= set(ids[:i]) for i, n in enumerate(nodes))
              and all(ids[i-1] in nodes[i]['predecessors'] for i in range(1, len(ids))),
              'Acyclic fixed graph retains every adjacent lifecycle dependency.')
        observations = [r for r in rows if r.get('kind') == 'invocation-observation']
        gates = [r for r in rows if r.get('kind') == 'gate-decision' and r['record'].get('scope_kind') == 'node']
        app_run = execution.get('app_run_id')
        if not app_run:
            raise Missing('Normalized actual app run identity unavailable')
        foreign = [r for r in observations + gates if r['record'].get('run_id') != app_run]
        check('run-identity', not foreign, 'All gate and invocation records must bind the actual run.')
        all_accepted = {}
        stage_gates = {}
        for prelude in ('intention_compiler', 'planner'):
            prelude_gates = [g for g in gates if g['record'].get('node_id') == prelude]
            if not prelude_gates:
                raise Missing('Required original intake/planning gate absent: ' + prelude)
            check('prelude-' + prelude, len(prelude_gates) == 1 and prelude_gates[0]['record'].get('action') == 'advance',
                  'Full workflow retains accepted intention/requirements compilation and fixed planning gates.')
        for i, node in enumerate(nodes):
            matches = [g for g in gates if g['record'].get('node_id') == node['node_id']]
            if not matches:
                if rule['expected'] == 'halt' and i > ids.index(rule['halt_node']):
                    continue
                raise Missing('Original node gate absent: ' + node['node_id'])
            if len(matches) != 1:
                raise ValueError('Multiple node attempts/gates in no-repair fixed profile')
            gate_ref = matches[0]['ref']
            gate = record(gate_ref, 'gate-decision')
            stage_gates[node['node_id']] = gate_ref
            contract = record(gate['node_contract_ref'], 'node-execution-contract')
            check('node-binding-' + node['node_id'], contract['run_id'] == app_run and
                  contract['node_id'] == node['node_id'] and contract['attempt_id'] == gate['attempt_id'],
                  'Effective node contract and actual gate share run/node/attempt identity.')
            actual = [record(ref, 'invocation-observation') for ref in gate['invocation_refs']]
            workers = [o for o in actual if o.get('cc_name') == node['cc']['cc_name']]
            if not workers:
                raise Missing('Actual worker invocation absent: ' + node['node_id'])
            worker = workers[0]
            binding_ok = len(workers) == 1 and all(worker.get(k) == node['cc'].get(k) for k in ('cc_name', 'cc_version', 'declaration_sha256'))
            check('actual-execution-' + node['node_id'], binding_ok and worker.get('observed_runtime') is True
                  and worker.get('outcome') == 'success' and worker.get('measurement_status') == 'observed'
                  and worker.get('node_contract_ref') == gate['node_contract_ref']
                  and worker.get('input_refs') == contract.get('input_refs'),
                  'Actual observed work must preserve exact declaration/version/hash and effective inputs.')
            # A predecessor output must be consumed as its exact accepted Ref.
            if i and node['node_id'] != 'search':
                previous = all_accepted.get(ids[i-1], [])
                check('handoff-' + node['node_id'], bool(previous) and any(r in worker['input_refs'] for r in previous),
                      'Consumer uses an original accepted immediate predecessor artifact.')
                prior_gate = record(stage_gates[ids[i-1]], 'gate-decision')
                if worker.get('started_at') is None:
                    raise Missing('Worker start timestamp unavailable')
                check('gate-before-dispatch-' + node['node_id'],
                      datetime.datetime.fromisoformat(worker['started_at'].replace('Z', '+00:00')) >=
                      datetime.datetime.fromisoformat(prior_gate['recorded_at'].replace('Z', '+00:00')),
                      'Actual consumer start occurs after the predecessor gate commits.')
            result = record(gate['deterministic_result_ref'], 'deterministic-check-result')
            if gate['action'] == 'advance':
                assessment = record(gate['assessment_ref'], 'verifier-assessment')
                check('gate-' + node['node_id'], gate['verdict'] in {'PASS', 'PASS_WITH_KNOWN_LIMITATIONS'}
                      and bool(gate['accepted_refs']) and all(r in gate['output_refs'] for r in gate['accepted_refs'])
                      and bool(result.get('results')) and all(r.get('outcome') == 'PASS' for r in result['results'])
                      and result.get('check_plan_ref') == gate.get('check_plan_ref')
                      and assessment.get('verdict') in {'PASS', 'PASS_WITH_KNOWN_LIMITATIONS'},
                      'Advancement retains mandatory deterministic checks, semantic assessment and accepted outputs.')
            else:
                check('halt-' + node['node_id'], rule['expected'] == 'halt' and node['node_id'] == rule['halt_node']
                      and gate['verdict'] in {'FAIL', 'INCONCLUSIVE'} and not gate['accepted_refs']
                      and any(r.get('outcome') == 'FAIL' for r in result.get('results', [])),
                      'Conflicting units must be mechanically retained and halt before experiment dispatch.')
            all_accepted[node['node_id']] = gate['accepted_refs']

        if rule['expected'] == 'halt':
            halt = record(stage_gates[rule['halt_node']], 'gate-decision')
            reason_bytes = json.dumps(record(halt['deterministic_result_ref'], 'deterministic-check-result')).lower()
            check('unit-conflict-attribution', 'unit' in reason_bytes and 'ns' in reason_bytes and 'ms' in reason_bytes,
                  'Retained failing check identifies the actual ns/ms disagreement.')
            forbidden = set(ids[ids.index(rule['halt_node'])+1:])
            leaked = [r for r in observations if r['record'].get('node_id') in forbidden]
            check('no-downstream-after-conflict', not leaked and execution['status'] in {'halted', 'failed', 'blocked'},
                  'Original complete collection contains no downstream experiment or Delivery invocation.')
            if leaked:
                critical.append('Conflicting intermediate units reached downstream execution')
        else:
            receipt_ref, receipt = unique('execution-receipt')
            payload_ref, payload = unique('benchmark-payload')
            verdict_ref, verdict = unique('evaluation-verdict')
            manifest_ref, manifest = unique('delivery-manifest')
            expected = recompute(rule['workload'])
            expected_science = 'PASS' if sum(x['treatment'] for x in expected) < sum(x['baseline'] for x in expected) else 'FAIL'
            raw_times = {'baseline': [], 'treatment': []}
            seen = set()
            correct, total = 0, 0
            run_rows = receipt['runs']
            hardware = receipt.get('hardware_inventory')
            if not isinstance(hardware, dict):
                raise Missing('Actual hardware inventory not retained with execution receipt')
            check('hardware-inventory', bool(hardware.get('cpu_model')) and hardware.get('cpu_cores', 0) > 0
                  and hardware.get('ram_mb', 0) > 0 and bool(hardware.get('os')) and bool(hardware.get('captured_at')),
                  'Original execution receipt retains CPU, memory, operating system and capture timestamp.')
            check('experimental-protocol', len(run_rows) == 2 * rule['repeats']
                  and [r['role'] for r in run_rows] == ['baseline', 'treatment'] * rule['repeats']
                  and payload['repeat_count'] == rule['repeats'] and payload['seed'] == rule['seed']
                  and payload['execution_receipt_ref'] == receipt_ref,
                  'Preregistered paired role order, repeat count, seed and original execution receipt are preserved.')
            for run in run_rows:
                role, repeat = run['role'], run['repeat_index']
                if (role, repeat) in seen:
                    raise ValueError('Duplicate role/repeat measurement')
                seen.add((role, repeat))
                raw = json.loads(blob(run['stdout_ref']))
                # Reading stdout through receipt Ref ties research measurements to actual execution.
                check('raw-provenance-' + role + '-' + str(repeat), run['exit_code'] == 0
                      and run['seed'] == rule['seed'] and run['command'] and run['wall_time_s'] >= 0
                      and raw['role'] == role and raw['repeat_index'] == repeat
                      and raw['schema'] == 'index-update-observation:1'
                      and raw.get('workload_sha256') == hashlib.sha256(json.dumps(rule['workload'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
                      and raw['elapsed_unit'] == 'ns' and raw['operation_unit'] == 'posting_mutation'
                      and raw['clock'] == 'perf_counter_ns' and bool(raw['python']) and bool(raw['machine']),
                      'Retained execution stdout must identify actual role/repeat, clock, units and environment.')
                if len(raw['batches']) != len(expected):
                    raise ValueError('Missing workload batch')
                for batch, truth in zip(raw['batches'], expected):
                    elapsed = batch['elapsed_ns']
                    if type(elapsed) is not int or elapsed < 0:
                        raise ValueError('Invalid elapsed raw observation')
                    raw_times[role].append(elapsed)
                    total += 1
                    ok = batch['answers'] == truth['answers'] and batch['postings_sha256'] == truth['postings_sha256']
                    correct += int(ok)
                    check('recompute-' + role + '-' + str(repeat) + '-' + str(total),
                          ok and type(batch['operations']) is int and batch['operations'] == truth[role],
                          'Independent direct scan verifies complete postings, conjunctive retrieval and exact posting mutations.')
            check('repeat-coverage', seen == {(role, repeat) for role in ('baseline', 'treatment') for repeat in range(rule['repeats'])},
                  'All preregistered repetitions remain in the denominator.')
            metrics['retrieval_exact_fraction'] = correct / total if total else None
            metrics['median_update_ns'] = {role: statistics.median(times) if times else None for role, times in raw_times.items()}
            metrics['scientific_result'] = expected_science
            check('scientific-conclusion', verdict['classification'] == expected_science
                  and verdict['benchmark_ref'] == payload_ref and verdict['blueprint_ref'] == receipt['blueprint_ref'],
                  'Scientific PASS/FAIL follows the preregistered logical-work hypothesis; latency remains descriptive.')
            check('negative-delivery', manifest['verdict_ref'] == verdict_ref and not manifest['missing_evidence']
                  and stage_gates['evaluation'] in manifest['gate_decision_refs']
                  and record(stage_gates['evaluation'], 'gate-decision')['action'] == 'advance'
                  and record(stage_gates['delivery'], 'gate-decision')['action'] == 'advance'
                  and execution['status'] == 'completed',
                  'Scientific negative findings retain infrastructure PASS and execute accepted Delivery.')
            report = blob(manifest['report_ref'])
            check('report-retains-result', expected_science in report and 'posting' in report.lower()
                  and 'latency' in report.lower() and 'ns' in report,
                  'Delivered report preserves the result, logical-work scope, latency units and source evidence.')
            benchmark_accepted = all_accepted.get('benchmark', [])
            check('measurement-accepted-handoff', payload_ref in benchmark_accepted
                  and verdict_ref in all_accepted.get('evaluation', [])
                  and manifest_ref in all_accepted.get('delivery', []),
                  'Measured payload, scientific verdict and Delivery manifest are actual accepted stage outputs.')
        metrics['composition_success'] = int(all(c['status'] == 'pass' for c in checks))
        metrics['full_task_success'] = metrics['composition_success']
    except Missing as error:
        checks.append({'id': 'required-evidence', 'status': 'unavailable', 'reason': str(error), 'evidence_refs': list(refs)})
    except (KeyError, TypeError, ValueError, IndexError, ZeroDivisionError) as error:
        check('evidence-integrity', False, 'Malformed or inconsistent original evidence: ' + str(error))
        critical.append('Original evidence or experiment protocol is inconsistent')
        metrics['full_task_success'] = 0
        metrics['composition_success'] = 0
    return {'checks': checks, 'metrics': metrics, 'critical_violations': critical}
