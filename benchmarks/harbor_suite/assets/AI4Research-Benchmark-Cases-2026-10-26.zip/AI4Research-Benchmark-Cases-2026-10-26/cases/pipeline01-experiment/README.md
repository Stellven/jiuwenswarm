# pipeline01-experiment — DEVELOPMENT S04

Complete governed CPU research closure, retaining intention/requirements
compilation and planning plus Search, Screening, Hypothesis, POC Builder,
Scientific Benchmarking, Scientific Evaluation and Delivery. All seven research
stages remain actual executed nodes; a short research prompt or report cannot
stand in for the pipeline. The fixture fixes the stage graph, admits additional
existing Delivery artifact dependencies, and requires exact current admitted
capsule declaration pins from the frozen library. It grants no product authority.

Three independent small public workloads cover sparse replacement/deletion/new
IDs, dense replacement, and schema-valid incompatible ns/ms handoff units.
The first two test a preregistered logical posting-mutation hypothesis and exact
retrieval. Sparse edits reduce work; dense edits require old-posting removal plus
new insertion and yield a genuine negative logical-work finding. Actual CPU
latency is measured and reported in nanoseconds, descriptively; there is no
assumed speed ratio, timing threshold, fabricated measurement or guarantee that
the logical-work result predicts wall time. Scientific FAIL must retain an
infrastructure advancing gate and actual Delivery. Conflicting units halt at
Hypothesis before any Builder/Benchmark/Delivery invocation.

`public/reference_index.py` is a runnable stdlib source. `source-notes.md` and
the 64-document microcorpus are authored public development material with no
download dependency. Three paired baseline/treatment repeats use cumulative
batches, identical frozen inputs, seed and protocol. Initial construction and
queries are outside measured update intervals. This bounded workload makes no
large-scale, held-out, or general performance claim.

## Supported binding and evidence

Entrypoint is ordinary E1 `run`, through the existing research_sidecar sequential
runner and suite adapter. The offline suite normalizer validates original product
record schemas and original Ref inventory joins; original UTF-8 artifact bytes
are independently joined by their retained SHA-256. No module observation or
case-generated enforcement boolean is used. It requires original `run-plan`,
`node-execution-contract`, `invocation-observation` v4, node-scope `gate-decision`,
`deterministic-check-result`, `verifier-assessment`, `execution-receipt`,
`benchmark-payload`, `evaluation-verdict`, and `delivery-manifest` records. Intake
and Planner node gates must also survive export. Foreign runs, substitutions,
missing work observations, broken predecessor accepted-Ref handoffs, consumer
starts before predecessor gate timestamps, and missing negative Delivery fail.

Scientific measurement stdout must be an original execution-receipt run's
`stdout_ref`, containing the `index-update-observation:1` record emitted by the
frozen source. Every role/repeat and batch is independently recomputed by a
direct document scan in the protected oracle, without importing or executing
candidate source. Receipt, payload, verdict and manifest Refs must join accepted
actual stage outputs. Missing source stdout/report bytes are unavailable.
Additional custom projections are unnecessary. The normalizer must preserve the
actual terminal run identity and complete original observations, including any
failed attempts; a partial record census cannot prove absence of dispatch.

The public JSON workload/handoff schema is a benchmark input contract, never a
new product wire schema. `public/workflow.json` declares stage names and graph
obligations, not fabricated library pins or execution grants. A supported
scientific metric/resource/blueprint and qualified executor binding must carry
these inputs through existing product contracts. If such a binding is absent,
record BLOCKED/unavailable; do not map this task into a read-only paper workflow.

## Remaining readiness and scope

Current observed product prerequisites include missing scientific executor
qualification and intention compiler JSON failure. They are unresolved acceptance
evidence. This case does not modify product capability, qualify the executor,
weaken gates, repair scored artifacts, or run any model. Ordinary E1 launch is a
supported route; successful research execution is not established here.

The report keyword checks establish retained structured facts only. Broader
source interpretation, methodological adequacy and prose quality remain
`human_review_required`. Hidden custody/held-out status requires independent
review; `referee/` and `oracle.py` belong only in the separate verifier.

Run `python -m unittest discover -s benchmarks/harbor_suite/cases/pipeline01-experiment -p test_oracle.py -v`
from the repository root. These are oracle unit tests with explicitly constructed
test records and actual local reference-source subprocess checks; they are not
production invocation observations or M1 acceptance results. `_author.py`
regenerates fixtures only and is never transported into the evaluated app.
