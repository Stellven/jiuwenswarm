"""Frozen DEVELOPMENT CPU experiment; stdlib, no network or installation.

Usage: reference_index.py workload.json --role baseline|treatment --repeat 0
Each process measures one role. Initial index construction is outside update
timing. Counts are logical posting mutations, not a timing surrogate.
"""
import argparse
import hashlib
import json
import platform
import re
import time


def tokens(text):
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def rebuild(documents):
    index = {}
    operations = 0
    for ident, text in documents.items():
        for term in tokens(text):
            index.setdefault(term, set()).add(ident)
            operations += 1
    return index, operations


def run(data, role, repeat=0):
    documents = dict(data['documents'])
    index, _ = rebuild(documents)
    batches = []
    for changes in data['batches']:
        started = time.perf_counter_ns()
        operations = 0
        if role == 'baseline':
            for ident, text in changes:
                if text is None:
                    documents.pop(ident, None)
                else:
                    documents[ident] = text
            index, operations = rebuild(documents)
        else:
            for ident, text in changes:
                for term in tokens(documents.get(ident, '')):
                    index[term].discard(ident)
                    operations += 1
                    if not index[term]:
                        del index[term]
                if text is None:
                    documents.pop(ident, None)
                else:
                    documents[ident] = text
                    for term in tokens(text):
                        index.setdefault(term, set()).add(ident)
                        operations += 1
        ended = time.perf_counter_ns()
        postings = {term: sorted(ids) for term, ids in sorted(index.items())}
        answers = {q: sorted(set.intersection(*(index.get(term, set()) for term in tokens(q))))
                   if tokens(q) else [] for q in data['queries']}
        digest = hashlib.sha256(json.dumps(postings, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        batches.append({'operations': operations, 'elapsed_ns': ended - started,
                        'postings_sha256': digest, 'answers': answers})
    return {'schema': 'index-update-observation:1', 'role': role,
            'workload_sha256': hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'repeat_index': repeat, 'elapsed_unit': 'ns', 'operation_unit': 'posting_mutation',
            'clock': 'perf_counter_ns', 'python': platform.python_version(),
            'machine': platform.machine(), 'batches': batches}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('workload')
    parser.add_argument('--role', choices=['baseline', 'treatment'], required=True)
    parser.add_argument('--repeat', type=int, default=0)
    args = parser.parse_args()
    with open(args.workload, encoding='utf-8') as stream:
        data = json.load(stream)
    if data['handoff']['baseline_latency_unit'] != data['handoff']['treatment_latency_unit']:
        parser.error('Conflicting intermediate latency units; resolve before dispatch')
    print(json.dumps(run(data, args.role, args.repeat), sort_keys=True))
