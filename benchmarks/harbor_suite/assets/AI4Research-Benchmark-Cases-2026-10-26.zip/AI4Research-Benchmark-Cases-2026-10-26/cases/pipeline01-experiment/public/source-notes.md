# Frozen technical source: incremental inverted indexes

This is an authored public DEVELOPMENT microcorpus and reference implementation,
released for unrestricted benchmark reuse. It contains no private documents or
download dependency. It is a small executable technical source, not a literature
survey or evidence of measured product execution.

An inverted index associates each distinct normalized token with document IDs.
An exact rebuild visits every remaining document and inserts every posting.
An incremental replacement removes the old document's postings and inserts the
new document's postings. Deletion removes its postings; insertion adds postings.
Both methods must agree after every cumulative batch, including deletion and
new document IDs. Tokenization and empty-query behavior are frozen in protocol.

The research question concerns logical posting mutations and measured CPU update
latency. These are different units and must remain distinct. High replacement
fractions can increase incremental logical work because both removals and
insertions are required. Fixed small inputs do not establish broad performance
claims. Repeated actual timings and hardware/software provenance belong in the
report; no operation count may be relabeled as elapsed time.

Run the source directly with Python 3.10+ and a workload JSON. It emits one JSON
stdout record containing exact retrieval answers, a complete-postings digest,
logical posting counts and actual measured elapsed nanoseconds. It performs no
network access, package install, subprocess or external write. The initial
index build and retrieval queries are excluded from update timing.
