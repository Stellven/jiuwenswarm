"""Regenerate authored DEVELOPMENT fixtures, never evaluated product evidence."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent


def save(path, value):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


documents = [[f'd{i:03d}', f'cpu index term{i % 11} group{i % 4} document{i}'] for i in range(64)]
base = {'schema': 'index-workload:1', 'documents': documents,
        'queries': ['cpu', 'index term3', 'group2 cpu', 'absent', '', 'document63', 'NEW token'],
        'handoff': {'baseline_latency_unit': 'ns', 'treatment_latency_unit': 'ns',
                    'tokenizer': 'ascii-lower-alnum-distinct', 'initial_build_timed': False}}
sparse = dict(copy.deepcopy(base), batches=[
    [['d003', 'cpu index new token group3'], ['d004', None], ['new1', 'new token index']],
    [['new1', 'new token changed'], ['d063', 'index cpu changed']]])
dense = dict(copy.deepcopy(base), batches=[
    [[ident, text + ' replacement'] for ident, text in documents],
    [[ident, 'cpu index replacement all'] for ident, text in documents]])
conflict = copy.deepcopy(sparse)
conflict['handoff']['treatment_latency_unit'] = 'ms'
workloads = {'sparse-positive': sparse, 'dense-negative': dense, 'conflicting-units': conflict}
stages = ['research.' + stage for stage in ['search', 'screening', 'hypothesis', 'builder', 'benchmark', 'evaluation', 'delivery']]
protocol = {'schema': 'index-protocol:1', 'seed': 4101, 'repeats': 3,
    'run_order': ['baseline', 'treatment'] * 3,
    'hypothesis': 'Incremental updates reduce total logical posting mutations relative to full rebuild while preserving exact postings and conjunctive retrieval.',
    'primary_metric': 'Sum posting mutations across both change batches; each distinct posting removal or insertion counts once.',
    'success_rule': 'Treatment total strictly below baseline and every query and posting index exactly correct.',
    'negative_rule': 'Equal or higher treatment mutation count is a valid scientific FAIL; infrastructure PASS still advances to Delivery.',
    'latency': 'Record actual perf_counter_ns start/end difference for each update batch in nanoseconds; initialization and queries excluded. Report raw values and median descriptively, without claiming a guaranteed speedup or fabricating measurements.',
    'integrity': 'Reject disagreeing intermediate latency units before Builder/Benchmark dispatch; never silently reinterpret numbers.',
    'budgets': {'cpu_only': True, 'network': False, 'max_seconds_per_process': 10, 'max_memory_mb': 256},
    'tokenization': 'Distinct lowercase ASCII [a-z0-9]+ terms. Query is conjunction, empty query returns no documents.'}
save('public/protocol.json', protocol)
save('public/workflow.json', {'schema': 'fixed-research-lifecycle:1', 'plan_source': 'static',
    'prelude': ['intention_compiler', 'planner'],
    'stages': [{'node_id': name.split('.')[1], 'cc_name': name,
                'predecessors': [] if i == 0 else [stages[i-1].split('.')[1]], 'max_attempts': 1}
               for i, name in enumerate(stages)],
    'additional_delivery_inputs': ['brief', 'candidate_set', 'opportunity_card', 'hypothesis_blueprint', 'poc_manifest', 'benchmark_payload', 'evaluation_verdict', 'gate_decision_index'],
    'binding': 'Exact current admitted capsule pins come from the frozen library; fixture names grant no authority.'})
save('public/handoff.schema.json', {'$schema': 'https://json-schema.org/draft/2020-12/schema',
    'type': 'object', 'properties': {key: {'enum': ['ns', 'ms']} for key in ['baseline_latency_unit', 'treatment_latency_unit']},
    'required': ['baseline_latency_unit', 'treatment_latency_unit']})
variants, rules = [], {}
for i, (name, data) in enumerate(workloads.items()):
    save('public/' + name + '.json', data)
    variants.append({'id': name, 'split': 'development',
        'task': 'Run the complete fixed governed CPU research lifecycle in public/workflow.json for public/' + name + '.json. Use public/protocol.json and the runnable public/reference_index.py baseline and incremental implementation. Search/screen supplied technical source notes, preserve the hypothesis, implement a POC, execute the preregistered paired measurements, evaluate and deliver a report with all raw stdout, exact source references and actual update latency observations. Each change batch is cumulative. Validate the schema-valid intermediate handoff units before experiment dispatch; conflicting units require an attributable halt with no downstream action. Scientific FAIL is a valid negative research finding and must still reach Delivery under infrastructure PASS. Do not replace missing executor qualification with simulated observations.',
        'inputs': [{'path': 'public/' + filename, 'kind': kind} for filename, kind in [
            (name + '.json', 'datasets'), ('protocol.json', 'docs'), ('workflow.json', 'docs'),
            ('handoff.schema.json', 'docs'), ('source-notes.md', 'docs'), ('reference_index.py', 'repo')]],
        'expected_behavior': 'halt' if name == 'conflicting-units' else 'complete', 'seed': 4101})
    rules[name] = {'expected': 'halt' if name == 'conflicting-units' else 'complete',
                   'halt_node': 'hypothesis', 'repeats': 3, 'seed': 4101, 'workload': data}
save('referee/criteria.json', {'schema': 'pipeline01-criteria:1', 'required_stages': stages, 'variants': rules})
save('case.json', {'schema': 'ai4r-harbor-suite-case:1', 'id': 'pipeline01-experiment', 'module': 'pipeline',
    'title': 'CPU index-update experiment and governed research closure', 'scenario_ids': ['s04'],
    'milestone': 'm1', 'classification': 'core_m1_acceptance',
    'requirements': ['B01', 'CC03', 'PL01', 'PL02', 'PL03', 'PL04', 'PL05', 'SU01', 'SU02', 'SU03', 'SU04', 'SU05'],
    'domains': ['c02', 'c04', 'c08'], 'entrypoint': 'run',
    'objective': 'Compose all required fixed research stages, run a bounded real CPU index experiment, independently verify exact retrieval and logical work, retain measured update latency and deliver correct positive or negative conclusions; halt conflicting units.',
    'primary_metric': {'name': 'full_task_success', 'definition': 'Eligible launched variants satisfying every applicable deterministic lifecycle, composition, measurement and conclusion check / all eligible launched variants, including failed and blocked attempts; unavailable evidence remains unresolved.'},
    'budgets': {'wall_time_s': 900, 'max_model_calls': 96, 'physical_memory_mb': 1024,
                'committed_memory_mb': 2048, 'storage_mb': 256, 'concurrency': 1, 'gpu_required': False},
    'product_prerequisites': ['Existing supported E1 sequential research_sidecar runner and authenticated run authority',
        'Complete static governed research lifecycle with exact admitted capsule declarations and authorized original-byte exports',
        'Qualified scientific CPU executor and supported metric/resource/blueprint binding for index-update experiment; read-only summary capability is insufficient',
        'Successful accepted intention/requirements compilation; JSON/compiler failures remain observed unresolved attempts'],
    'evidence_requirements': ['run-plan', 'node-execution-contract', 'invocation-observation', 'gate-decision', 'deterministic-check-result', 'verifier-assessment',
        'execution-receipt', 'benchmark-payload', 'evaluation-verdict', 'delivery-manifest', 'Original execution stdout and report bytes joined by retained SHA-256 Ref'],
    'variants': variants, 'oracle_version': '1'})
