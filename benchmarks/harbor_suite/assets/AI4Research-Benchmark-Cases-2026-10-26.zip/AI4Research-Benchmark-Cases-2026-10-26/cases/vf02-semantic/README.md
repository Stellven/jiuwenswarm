# VF02 semantic replay case

Development benchmark material only. Ten finite CPU retrieval evaluation packets cover valid output, unsupported local citation, wrong arithmetic, unfair batching comparison, insufficient evidence, prompt injection, documented limitation, scientific negative result, threshold substitution and understated scope. Local source excerpts and repeated numbers are authored research inputs, not measurements or product proof. Public packets contain no oracle labels or rubric. Protected criteria freeze independent detailed verdicts, primary violated criteria and original packet hashes.

Requirements12.1 mapping: valid covers case 1, broken citation case 4, known limitation case 8, scientific negative case 9. VF01 owns cases 2, 3, 5, 6, 7 and 10. All scientific negatives retain their scientific FAIL classification while infrastructure acceptance is PASS. The maintained science checking profile supplies the exact ten criterion objects, including blocking, answerable_from and target_port; see referee/rubric.json. The oracle recomputes its blocking aggregation without calling product code. No model judge is enabled. Model decisions under test are predictions, never label authority.

Readiness: not execution-qualified. Actual source-template admission, contract/output-schema binding, private export capture, independent two-reviewer label approval and host qualification are required. These packets deliberately omit invented source run IDs, product artifact Refs, grants and authority tokens. They require an admitted output contract for the declared finite packet, including nullable unmeasured values; do not submit them as the maintained evaluation-verdict schema without a valid supported binding. If that binding is unavailable, report BLOCKED. The maintained client currently restricts detailed Tier 2 values more tightly than the assessment schema; preserve original INCONCLUSIVE records and report unsupported transport explicitly. Never coerce them to FAIL or fabricate a run.

## Normalized original evidence projection

The parent normalizer must first validate the complete private E2 export with EvaluationRecords, preserving its original request/source/port closure. Pass original records under their exact export kinds. module_observations.vf02 is only a selector of those records, with these fields:

| Projection field | Original records kind |
| --- | --- |
| result_ref | result (record.result is the original response) |
| measurement_ref | measurement |
| assessment_ref | assessment |
| profile_ref | source_check_profile |
| review_context_ref | review_context |
| deterministic_ref | deterministic_result |
| check_plan_ref | check_plan (private evaluation checking basis) |
| evaluation_gate_ref | evaluation_gate |
| recording_action_ref | recording_action |

Also supply subject_ref, declaration_ref and subject_path. subject_path selects exact original UTF-8 bytes from artifacts, preserving line endings. Its SHA256 must equal both selected original output Ref and frozen public packet hash. The original measurement, assessment, review context, deterministic result and exact rubric must join; findings must cite original declaration and subject. Missing or ambiguous captures are unavailable. No projection boolean or producer exit code substitutes for records. Parent export validation remains responsible for original custody, schemas, source declaration and selected-port binding; these unit-test structures do not confer that authority.

The original E2 response must retain invalid_for_product=true. Its recording gate and scheduler action are measured only as replay behavior. Actual downstream starts, locks and Delivery are always unavailable in this oracle: replay cannot prove live scheduler causality. Requirements12.1 acceptance requires separate actual capture using the maintained live-order adapter and original accepted-output/gate/dispatch joins. The parent must never drop this unavailable check or renormalize it away.

## Scoring and validation

Exact detailed-verdict prediction, primary-criterion prediction, recording advance/block, deterministic Tier 1 isolation, metadata retention and negative-result separation are distinct checks. False advances on frozen block labels are critical. Defective packets can violate collateral criteria; only their independently labeled primary failure is constrained, while advancing packets require all findings to pass. All-ten campaign denominators include unavailable cases. Do not aggregate an available-only accuracy as a full case score. Full semantic quality and free-text reason accuracy remain human_review_required; no unqualified semantic score is published.

Run `python -m unittest discover -s benchmarks/harbor_suite/cases/vf02-semantic -p test_oracle.py -v` from repository root. These are oracle unit tests with synthetic unit-only records, not product correctness or performance observations. They cover every label plus missing captures, forged selectors, subject and rubric swaps, false advance, Tier 1 failure, missing finding, missing limitation and scientific-negative separation. Scored stochastic campaigns require three repeats per configuration; one-repeat smoke is only a wiring check.
