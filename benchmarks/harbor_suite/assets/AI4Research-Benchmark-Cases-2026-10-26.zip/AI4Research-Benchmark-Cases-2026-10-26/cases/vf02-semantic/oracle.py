"""Independent development-label oracle. No model judge or product execution."""
import hashlib
import re

HEX = re.compile(r'^[0-9a-f]{64}$')


def _key(ref):
    if not isinstance(ref, dict) or not isinstance(ref.get('id'), str) or not ref['id'] or not HEX.fullmatch(ref.get('sha256', '')):
        raise ValueError('missing original capture Ref')
    return ref['id'], ref['sha256']


def evaluate(evidence, criteria):
    checks = []
    metrics = {'model_judged_share': 0, 'human_review_required': True, 'live_gate_acceptance': 'unavailable'}
    critical = []
    def add(ident, status, reason, refs=()):
        checks.append({'id': ident, 'status': status, 'reason': reason, 'evidence_refs': list(refs)})
    label = criteria.get('variants', {}).get(evidence.get('variant_id'))
    if not label:
        add('variant-label', 'unavailable', 'No frozen independent variant label.')
        return {'checks': checks, 'metrics': metrics, 'critical_violations': critical}
    add('human-semantic-review', 'unavailable', 'human_review_required: free-text reason quality and two-reviewer label approval are not established by deterministic self-tests.')
    add('actual-downstream-action', 'unavailable', 'E2 recording scheduler cannot prove actual next-node start, locking, or Delivery execution. Requires separate actual live scheduler capture.')
    try:
        p = evidence['module_observations']['vf02']
        rows = evidence['records']
        def get(name, kind):
            ref = p[name]; key = _key(ref)
            found = [r for r in rows if r.get('kind') == kind and _key(r.get('ref')) == key]
            if len(found) != 1:
                raise ValueError('missing or ambiguous original ' + kind)
            return found[0]['record']
        result = get('result_ref', 'result')['result']
        measured = get('measurement_ref', 'measurement')
        assessment = get('assessment_ref', 'assessment')
        profile = get('profile_ref', 'source_check_profile')
        review = get('review_context_ref', 'review_context')
        checked = get('deterministic_ref', 'deterministic_result')
        basis = get('check_plan_ref', 'check_plan')
        gate = get('evaluation_gate_ref', 'evaluation_gate')
        action = get('recording_action_ref', 'recording_action')
        subject = p['subject_ref']; _key(subject); _key(p['declaration_ref'])
        text = evidence['artifacts'][p['subject_path']]
        if hashlib.sha256(text.encode('utf-8')).hexdigest() != subject['sha256'] or subject['sha256'] != label['subject_sha256']:
            raise ValueError('selected original output bytes differ from frozen fixture')
        if profile['criteria'] != criteria['rubric'] or profile['model_call_limit'] != 1:
            raise ValueError('original protected rubric differs from exact maintained criterion contract')
        if (assessment['subject_ref'] != subject or assessment['review_context_ref'] != p['review_context_ref']
            or review['subject_ref'] != subject or review['deterministic_result_ref'] != p['deterministic_ref']
            or measured['assessment_refs'] != [p['assessment_ref']] or measured['deterministic_ref'] != p['deterministic_ref']
            or checked['check_plan_ref'] != p['check_plan_ref'] or basis['profile_ref'] != p['profile_ref']):
            raise ValueError('assessment/review/measurement/rubric joins differ')
        if subject not in measured['output_refs'].values():
            raise ValueError('reviewed output not in original measurement')
        if review['criteria'] != [x['criterion_id'] for x in criteria['rubric']]:
            raise ValueError('review context criterion coverage differs')
        findings = assessment['findings']; by_id = {f['criterion_id']: f for f in findings}
        if len(findings) != len(by_id) or set(by_id) != set(label['finding_outcomes']):
            raise ValueError('finding population is missing, duplicated or unregistered')
        for f in findings:
            if not f.get('reason', '').strip() or subject not in f['evidence_refs'] or p['declaration_ref'] not in f['evidence_refs']:
                raise ValueError('finding lacks original subject/declaration citations and reason')
        if (result['invalid_for_product'] is not True or result['gate_decision']['assessment_ref'] != p['assessment_ref']
            or result['evidence_refs'] != [p['measurement_ref'], p['evaluation_gate_ref']]
            or gate['decision'] != result['gate_decision'] or gate['persisted_at'] != result['persisted_at']
            or result['persisted_at'] is None or action['gate_ref'] != p['evaluation_gate_ref']
            or action['scheduler_kind'] != 'recording' or action['invalid_for_product'] is not True
            or action['action'] != result['downstream_action']):
            raise ValueError('original E2 recording gate/action joins differ')
    except (KeyError, TypeError, ValueError, AttributeError) as exc:
        add('original-e2-bindings', 'unavailable', str(exc))
        return {'checks': checks, 'metrics': metrics, 'critical_violations': critical}
    refs = [p['result_ref'], p['measurement_ref'], p['assessment_ref']]
    add('original-e2-bindings', 'pass', 'Selected subject bytes, original assessment, exact rubric and private E2 recording action joined.', refs)
    mandatory = basis.get('mandatory_deterministic', [])
    checkrows = checked.get('results', [])
    cm = {x['check_id']: x['outcome'] for x in checkrows}
    tier1 = bool(mandatory) and len(cm) == len(checkrows) and all(cm.get(k) == 'PASS' for k in mandatory)
    add('tier1-isolation', 'pass' if tier1 and result.get('tier1_verdict') == 'PASS' else 'fail', 'Semantic fixtures require original mandatory deterministic checks to pass before Tier 2.', [p['deterministic_ref']])
    verdict = assessment.get('verdict')
    exact = verdict == label['expected_verdict'] and result.get('tier2_verdict') == verdict and result['gate_decision'].get('verdict') == verdict
    blocking = {c['criterion_id'] for c in criteria['rubric'] if c['blocking']}
    failed = [f['outcome'] for f in findings if f['criterion_id'] in blocking and f['outcome'] != 'PASS']
    legal = all(f['outcome'] in {'PASS','FAIL','INCONCLUSIVE','ENVIRONMENT_BLOCKED'} for f in findings)
    assembled = next((v for v in ('FAIL','ENVIRONMENT_BLOCKED','INCONCLUSIVE') if v in failed), None)
    if assembled is None:
        assembled = 'PASS' if all(f['outcome'] == 'PASS' for f in findings) and not assessment.get('uncertainties') and not assessment.get('limitations') else 'PASS_WITH_KNOWN_LIMITATIONS'
    consistent = legal and verdict == assembled and (verdict not in {'PASS','PASS_WITH_KNOWN_LIMITATIONS'} or assessment.get('required_correction') is None)
    add('verdict-from-findings', 'pass' if consistent else 'fail', 'Recomputed maintained blocking-criterion aggregation and advancing correction rule.', [p['assessment_ref']])
    add('detailed-verdict', 'pass' if exact else 'fail', 'Frozen label: ' + label['expected_verdict'] + '; observed ' + str(verdict), refs)
    # Defective artifacts may violate multiple criteria. Require the independently
    # labeled primary failure without forcing all collateral findings to PASS.
    required = {k:v for k,v in label['finding_outcomes'].items() if v != 'PASS'}
    outcomes = all(by_id[k]['outcome'] == v for k,v in (required or label['finding_outcomes']).items())
    add('criterion-predictions', 'pass' if outcomes else 'fail', label['rationale'], [p['assessment_ref']])
    advance = verdict in {'PASS', 'PASS_WITH_KNOWN_LIMITATIONS'}
    recorded = (result.get('advanced') is label['advance'] and advance is label['advance']
                and result.get('downstream_action') == ('started' if label['advance'] else 'halted')
                and result['gate_decision'].get('action') == ('advance' if label['advance'] else 'halt'))
    add('recording-action', 'pass' if recorded else 'fail', 'Checks private replay recording action only; invalid_for_product remains true.', [p['evaluation_gate_ref'], p['recording_action_ref']])
    if label['expected_verdict'] == 'PASS_WITH_KNOWN_LIMITATIONS':
        add('warning-preserved', 'pass' if assessment.get('limitations') else 'fail', 'Known non-blocking limitation must persist in assessment metadata.', [p['assessment_ref']])
    if label['scientific_classification'] == 'FAIL':
        add('scientific-negative-separation', 'pass' if verdict == 'PASS' and recorded else 'fail', 'Original scientific FAIL stays in frozen output; infrastructure PASS is assessed separately from actual Delivery.', refs + [subject])
    if not label['advance'] and (advance or result.get('advanced') is True):
        critical.append('false_advance_on_frozen_block_label')
    metrics.update({'exact_verdict_numerator': int(exact), 'variant_denominator': 1,
                    'false_advance_numerator': int(not label['advance'] and (advance or result.get('advanced') is True)),
                    'block_label_denominator': int(not label['advance']),
                    'false_block_numerator': int(label['advance'] and not advance),
                    'advance_label_denominator': int(label['advance'])})
    return {'checks': checks, 'metrics': metrics, 'critical_violations': critical}
