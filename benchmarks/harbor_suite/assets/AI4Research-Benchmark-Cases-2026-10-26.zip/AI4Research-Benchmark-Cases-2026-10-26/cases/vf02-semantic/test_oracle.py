"""Oracle unit tests only. Synthetic records below are never product evidence."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
import oracle

ROOT = Path(__file__).parent
CRITERIA = json.loads((ROOT/'referee/criteria.json').read_text(encoding='utf-8'))


def fixture(variant):
    label = CRITERIA['variants'][variant]
    p = {}
    for name in ('result','measurement','assessment','profile','subject','declaration','review_context','deterministic','check_plan','evaluation_gate','recording_action'):
        p[name+'_ref'] = {'id':'unit-only:'+name, 'sha256':hashlib.sha256(name.encode()).hexdigest()}
    p['subject_ref']['sha256'] = label['subject_sha256']
    p['subject_path'] = label['subject_path']
    decision = {'assessment_ref':p['assessment_ref'],'verdict':label['expected_verdict'],'action':'advance' if label['advance'] else 'halt'}
    result = {'invalid_for_product':True,'tier1_verdict':'PASS','tier2_verdict':label['expected_verdict'],'advanced':label['advance'],'downstream_action':'started' if label['advance'] else 'halted','gate_decision':decision,'persisted_at':'unit-test-time','evidence_refs':[p['measurement_ref'],p['evaluation_gate_ref']]}
    bodies = {
      'result':{'result':result},
      'measurement':{'assessment_refs':[p['assessment_ref']],'deterministic_ref':p['deterministic_ref'],'output_refs':{'evaluation_verdict':p['subject_ref']}},
      'assessment':{'subject_ref':p['subject_ref'],'review_context_ref':p['review_context_ref'],'verdict':label['expected_verdict'],'findings':[{'criterion_id':k,'outcome':v,'reason':label['rationale'],'evidence_refs':[p['declaration_ref'],p['subject_ref']]} for k,v in label['finding_outcomes'].items()],'limitations':['Single workload only'] if variant=='known-limitation' else [],'uncertainties':[],'required_correction':None},
      'source_check_profile':{'criteria':CRITERIA['rubric'],'model_call_limit':1},
      'review_context':{'subject_ref':p['subject_ref'],'deterministic_result_ref':p['deterministic_ref'],'criteria':[x['criterion_id'] for x in CRITERIA['rubric']]},
      'deterministic_result':{'check_plan_ref':p['check_plan_ref'],'results':[{'check_id':'mechanical','outcome':'PASS'}]},
      'check_plan':{'profile_ref':p['profile_ref'],'mandatory_deterministic':['mechanical']},
      'evaluation_gate':{'decision':decision,'persisted_at':'unit-test-time'},
      'recording_action':{'gate_ref':p['evaluation_gate_ref'],'scheduler_kind':'recording','invalid_for_product':True,'action':result['downstream_action']}}
    names={'source_check_profile':'profile','deterministic_result':'deterministic'}
    return {'variant_id':variant,'records':[{'kind':k,'ref':p[names.get(k,k)+'_ref'],'record':v} for k,v in bodies.items()],'artifacts':{p['subject_path']:(ROOT/p['subject_path']).read_bytes().decode('utf-8')},'module_observations':{'vf02':p}}


def check(out, ident):
    return next(x for x in out['checks'] if x['id']==ident)['status']


class OracleTests(unittest.TestCase):
    def test_all_frozen_labels(self):
        for variant in CRITERIA['variants']:
            with self.subTest(variant=variant):
                out=oracle.evaluate(fixture(variant), CRITERIA)
                self.assertEqual(check(out,'detailed-verdict'),'pass')
                self.assertEqual(check(out,'criterion-predictions'),'pass')
                self.assertEqual(check(out,'actual-downstream-action'),'unavailable')
                self.assertFalse(out['critical_violations'])
    def test_missing_capture_is_unavailable(self):
        e=fixture('valid');e['records']=[]
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'original-e2-bindings'),'unavailable')
    def test_forged_projection_is_not_evidence(self):
        e={'variant_id':'valid','module_observations':{'vf02':{'correct':True}}}
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'original-e2-bindings'),'unavailable')
    def test_subject_swap(self):
        e=fixture('valid');e['artifacts']['public/valid.json']+=' '
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'original-e2-bindings'),'unavailable')
    def test_rubric_swap(self):
        e=copy.deepcopy(fixture('valid'));next(x for x in e['records'] if x['kind']=='source_check_profile')['record']['criteria']=[]
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'original-e2-bindings'),'unavailable')
    def test_false_advance_is_critical(self):
        e=fixture('broken-citation')
        for row in e['records']:
            if row['kind']=='assessment':row['record']['verdict']='PASS'
            if row['kind']=='result':row['record']['result'].update(tier2_verdict='PASS',advanced=True)
        out=oracle.evaluate(e,CRITERIA)
        self.assertEqual(check(out,'detailed-verdict'),'fail')
        self.assertIn('false_advance_on_frozen_block_label',out['critical_violations'])
    def test_tier1_failure_cannot_be_semantic_success(self):
        e=fixture('valid');next(x for x in e['records'] if x['kind']=='deterministic_result')['record']['results'][0]['outcome']='FAIL'
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'tier1-isolation'),'fail')
    def test_missing_warning_fails(self):
        e=fixture('known-limitation');next(x for x in e['records'] if x['kind']=='assessment')['record']['limitations']=[]
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'warning-preserved'),'fail')
    def test_scientific_fail_is_not_infrastructure_fail(self):
        out=oracle.evaluate(fixture('scientific-negative'),CRITERIA)
        self.assertEqual(check(out,'scientific-negative-separation'),'pass')
    def test_injection_label_still_blocks(self):
        self.assertFalse(CRITERIA['variants']['prompt-injection']['advance'])
        self.assertEqual(check(oracle.evaluate(fixture('prompt-injection'),CRITERIA),'recording-action'),'pass')
    def test_unknown_variant(self):
        self.assertEqual(check(oracle.evaluate({'variant_id':'unknown'},CRITERIA),'variant-label'),'unavailable')
    def test_missing_finding_is_not_pass(self):
        e=fixture('valid');next(x for x in e['records'] if x['kind']=='assessment')['record']['findings'].pop()
        self.assertEqual(check(oracle.evaluate(e,CRITERIA),'original-e2-bindings'),'unavailable')

if __name__=='__main__':unittest.main()

