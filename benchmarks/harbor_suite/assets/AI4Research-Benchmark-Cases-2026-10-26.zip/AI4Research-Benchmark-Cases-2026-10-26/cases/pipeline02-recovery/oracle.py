"""Stdlib DEVELOPMENT oracle; host custody validation is a prerequisite.

Controller/audit projection is benchmark-owned, never a product wire schema.
No candidate text, producer verdict, or unbound recovery boolean can prove faults.
"""
import hashlib
import json
import re
from datetime import datetime


class Missing(Exception):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def key(ref):
    if not isinstance(ref, dict) or not ref.get('id') or not re.fullmatch('[a-f0-9]{64}', ref.get('sha256', '')):
        raise Missing('Original source Ref unavailable')
    return ref['id'], ref['sha256']


def evaluate(evidence, criteria):
    checks, refs, critical = [], [], []
    metrics = {'full_task_success': None, 'workflow_handoff_success': None,
               'sequential_recovery_success': None, 'long_horizon_measured': False,
               'human_review_required': True}

    def check(ident, ok, reason):
        checks.append({'id': ident, 'status': 'pass' if ok else 'fail',
                       'reason': reason, 'evidence_refs': list(refs)})

    try:
        rule = criteria['variants'].get(evidence.get('variant_id'))
        if rule is None or evidence.get('entrypoint') != 'run':
            raise Missing('Scheduled E1 variant is absent')
        execution = evidence.get('execution', {})
        if not execution.get('launched') or not execution.get('terminal') or not execution.get('app_run_id'):
            raise Missing('Actual terminal E1 execution unavailable')
        rows = evidence.get('records', [])
        index = {}
        for row in rows:
            k = key(row.get('ref'))
            if k in index:
                raise ValueError('Duplicate original record Ref')
            index[k] = row

        def record(ref, kind):
            row = index.get(key(ref))
            if row is None:
                raise Missing('Original record absent: ' + kind)
            if row.get('kind') != kind:
                raise ValueError('Original record kind mismatch')
            if ref not in refs:
                refs.append(ref)
            return row['record']

        def unique(kind):
            found = [r for r in rows if r.get('kind') == kind]
            if not found:
                raise Missing('Original ' + kind + ' absent')
            if len(found) != 1:
                raise ValueError('Ambiguous original ' + kind)
            return record(found[0]['ref'], kind)

        def blob(ref):
            key(ref)
            raw = {v for v in evidence.get('artifacts', {}).values() if isinstance(v, str)
                   and hashlib.sha256(v.encode()).hexdigest() == ref['sha256']}
            if not raw:
                raise Missing('Original source bytes absent')
            if ref not in refs:
                refs.append(ref)
            return raw.pop()

        # Workflow correctness is measured before, and independently of, host recovery.
        plan = unique('run-plan')
        nodes = plan['nodes']
        ids = [n['node_id'] for n in nodes]
        required = criteria['required_nodes']
        check('fixed-workflow', plan.get('plan_source') == 'static' and plan.get('frozen') is True
              and ids == required and len(nodes) >= 4 and plan.get('topological_order') == ids
              and all(n['predecessors'] == ids[i-1:i] for i, n in enumerate(nodes)),
              'Original fixed plan retains the complete preregistered seven-stage DAG.')
        if ids != required:
            raise ValueError('Required research lifecycle substituted')
        app = execution['app_run_id']
        gates = [r for r in rows if r['kind'] == 'gate-decision' and r['record'].get('scope_kind') == 'node']
        observations = [r for r in rows if r['kind'] == 'invocation-observation']
        check('original-run-identity', all(r['record'].get('run_id') == app for r in gates + observations),
              'Every original gate and invocation binds the actual E1 app run.')
        for prelude in ('intention_compiler','planner'):
            pg = [r['record'] for r in gates if r['record'].get('node_id') == prelude]
            if not pg:
                raise Missing('Required original intake/planning gate absent: ' + prelude)
            check('prelude-' + prelude, len(pg) == 1 and pg[0].get('action') == 'advance',
                  'Governed workflow retains accepted intention compilation and fixed planning.')
        accepted, previous_gate = [], None
        stage_accepted = {}
        completed = rule['expected'] == 'complete'
        stop_index = len(ids) if completed else ids.index(rule['stop_node'])
        for i, node in enumerate(nodes):
            found = [r for r in gates if r['record'].get('node_id') == node['node_id']]
            invocations = [r for r in observations if r['record'].get('node_id') == node['node_id']]
            if i >= stop_index:
                check('blocked-downstream-' + node['node_id'], not invocations and not any(
                    r['record'].get('action') == 'advance' for r in found),
                    'No downstream invocation or advancement after the controlled block.')
                if invocations:
                    critical.append('Downstream work escaped a dependency/cancellation block')
                continue
            if not found or not invocations:
                raise Missing('Original completed-stage gate/invocation missing: ' + node['node_id'])
            if len(found) != 1:
                raise ValueError('Automatic repair/repeated node gate outside fixed profile')
            gate = record(found[0]['ref'], 'gate-decision')
            contract = record(gate['node_contract_ref'], 'node-execution-contract')
            workers = [record(r, 'invocation-observation') for r in gate['invocation_refs']]
            workers = [w for w in workers if w.get('cc_name') == node['cc']['cc_name']]
            if not workers:
                raise Missing('Actual bound worker observation unavailable')
            worker = workers[0]
            check('binding-' + node['node_id'], len(workers) == 1
                  and all(worker.get(k) == node['cc'].get(k) for k in ('cc_name', 'cc_version', 'declaration_sha256'))
                  and all(contract.get(k) == gate.get(k) for k in ('run_id','node_id','attempt_id'))
                  and all(worker.get(k) == gate.get(k) for k in ('run_id','node_id','attempt_id'))
                  and worker.get('node_contract_ref') == gate['node_contract_ref']
                  and worker.get('input_refs') == contract.get('input_refs')
                  and worker.get('observed_runtime') is True and worker.get('measurement_status') == 'observed'
                  and worker.get('outcome') == 'success',
                  'Actual worker preserves admitted binding, effective contract and observed execution.')
            result = record(gate['deterministic_result_ref'], 'deterministic-check-result')
            assessment = record(gate['assessment_ref'], 'verifier-assessment')
            check('accepted-stage-' + node['node_id'], gate.get('action') == 'advance'
                  and gate.get('verdict') in {'PASS','PASS_WITH_KNOWN_LIMITATIONS'}
                  and bool(gate['accepted_refs']) and all(r in gate['output_refs'] for r in gate['accepted_refs'])
                  and bool(result.get('results')) and all(r.get('outcome') == 'PASS' for r in result['results'])
                  and assessment.get('verdict') in {'PASS','PASS_WITH_KNOWN_LIMITATIONS'},
                  'Advancement is backed by retained deterministic and verifier evidence.')
            if i:
                if not worker.get('started_at') or not previous_gate.get('recorded_at'):
                    raise Missing('Handoff timing absent')
                check('handoff-' + node['node_id'], bool(accepted)
                      and any(r in worker['input_refs'] for r in accepted)
                      and datetime.fromisoformat(worker['started_at'].replace('Z','+00:00')) >=
                      datetime.fromisoformat(previous_gate['recorded_at'].replace('Z','+00:00')),
                      'Consumer receives an exact accepted predecessor Ref after its gate.')
            accepted, previous_gate = gate['accepted_refs'], gate
            stage_accepted[node['node_id']] = accepted
        check('terminal-policy', execution['status'] == 'completed' if completed else
              execution['status'] in {'blocked','failed','halted','cancelled','interrupted'},
              'Terminal state conforms to complete-versus-attributable-halt policy.')
        if rule['fault'] == 'dependency_failure':
            blocked = [r['record'] for r in gates if r['record'].get('node_id') == rule['stop_node']]
            if not blocked:
                raise Missing('Original dependency-block gate absent')
            check('attributable-dependency-halt', len(blocked) == 1 and blocked[0].get('action') == 'halt'
                  and not blocked[0].get('accepted_refs') and blocked[0].get('verdict') in {'ENVIRONMENT_BLOCKED','INCONCLUSIVE','FAIL'}
                  and bool(blocked[0].get('reasons')), 'Original gate records attributable dependency failure, never an invented scientific verdict.')
        if completed:
            payload = unique('benchmark-payload')
            receipt_work = unique('execution-receipt')
            manifest = unique('delivery-manifest')
            receipt_ref = next(r['ref'] for r in rows if r['kind'] == 'execution-receipt')
            payload_ref = next(r['ref'] for r in rows if r['kind'] == 'benchmark-payload')
            manifest_ref = next(r['ref'] for r in rows if r['kind'] == 'delivery-manifest')
            check('measurement-and-delivery-binding', payload.get('execution_receipt_ref') == receipt_ref
                  and payload_ref in stage_accepted.get('benchmark', [])
                  and manifest_ref in stage_accepted.get('delivery', []),
                  'Original experiment payload and Delivery manifest are accepted outputs in this run.')
            raw_runs = receipt_work.get('runs', [])
            if not raw_runs:
                raise Missing('Original deterministic CPU execution stdout absent')
            expected = {}
            for name, trace in criteria['workload']['traces'].items():
                cache, hits = [], 0
                for item in trace:
                    if item in cache:
                        hits += 1
                        cache.remove(item)
                    elif len(cache) == criteria['workload']['capacity_entries']:
                        cache.pop(0)
                    cache.append(item)
                expected[name] = {'hits':hits, 'misses':len(trace)-hits,
                                  'unbounded_misses':len(set(trace))}
            for i, run_work in enumerate(raw_runs):
                raw = json.loads(blob(run_work['stdout_ref']))
                check('independent-cache-counts-' + str(i), run_work.get('exit_code') == 0
                      and raw.get('source_id') == criteria['workload']['source_id']
                      and raw.get('results') == expected and raw.get('unit') == 'requests',
                      'Original CPU stdout independently matches every frozen trace and count unit.')
            report = blob(manifest['report_ref'])
            check('source-fidelity', all(token in report for token in ('N1','N2',criteria['workload']['source_id']))
                  and 'latency' in report.lower(), 'Original delivered report retains source IDs and the limit on latency inference; prose quality requires human review.')
            check('report-accepted', bool(accepted), 'Delivery remains an accepted stage under the original gate.')
        metrics['workflow_handoff_success'] = int(all(c['status'] == 'pass' for c in checks))

        # Each ref below must be custody-authorized by the parent normalizer.
        projection = evidence.get('module_observations', {}).get('pipeline02')
        if not isinstance(projection, dict):
            raise Missing('Protected fault controller and sequential audit projection unsupported')
        source_names = ('driver_receipt_ref','campaign_ref','run_record_ref','events_ref','pilot_receipt_ref')
        if any(name not in projection for name in source_names):
            raise Missing('Complete controller/audit source bindings absent')
        source = {name: json.loads(blob(projection[name])) for name in source_names}
        driver, campaign, run, events, receipt = [source[n] for n in source_names]
        driver_plan = json.loads(blob(driver['plan_ref']))
        check('protected-frozen-fault-plan', driver_plan == rule['driver_plan']
              and driver.get('schema') == 'pipeline02-controller-receipt:1'
              and driver.get('variant_id') == evidence['variant_id']
              and driver.get('plan_sha256') == hashlib.sha256(canonical(driver_plan)).hexdigest(),
              'Actual controller receipt binds the protected prelaunch frozen variant plan.')
        # Audit events are actual controller process/effect observations, not model annotations.
        audit = json.loads(blob(driver['audit_ref']))
        if not isinstance(audit, list) or not audit:
            raise Missing('Original complete controller audit absent')
        order = [e.get('event') for e in audit]
        check('prelaunch-freeze', order.count('plan_frozen') == 1 and order.count('launch_started') == 1
              and order.count('fault_applied') == 1
              and order.index('plan_frozen') < order.index('launch_started') < order.index('fault_applied'),
              'Independent host audit records protected plan freeze before launch and actual injection.')
        effects = [e for e in audit if e.get('event') == 'fault_applied']
        check('actual-fault-effect', len(effects) == 1 and effects[0].get('fault') == rule['fault']
              and effects[0].get('trigger') == rule['driver_plan']['trigger']
              and effects[0].get('request_id') == execution.get('request_id')
              and effects[0].get('app_run_id') == app and bool(effects[0].get('effect_receipt_ref')),
              'Authenticated controller audit records exactly one actual requested effect at its frozen trigger.')
        if len(effects) != 1 or not effects[0].get('effect_receipt_ref'):
            raise Missing('Original actual-controller effect receipt absent')
        effect = json.loads(blob(effects[0]['effect_receipt_ref']))
        check('effect-confirmed', effect.get('fault') == rule['fault'] and effect.get('app_run_id') == app
              and effect.get('request_id') == execution.get('request_id') and effect.get('observed_at')
              and effect.get('operation') == {'dependency_failure':'dependency_access_denied','cancel':'cancel_api_acknowledged',
                  'observer_interruption':'observer_process_exit','collection_interruption':'collector_process_exit'}[rule['fault']],
              'Original effect receipt identifies actual dependency/API/process action and target.')
        check('runner-identity', run.get('app_run_id') == app and run.get('request_id') == execution.get('request_id')
              and run.get('campaign_id') == campaign.get('campaign_id') == receipt.get('campaign_id')
              and len(campaign.get('cases', [])) == 1 and campaign['cases'][0]['id'] == run.get('case_id')
              and campaign['cases'][0].get('repeats') == 1 and run.get('run_id') == run.get('case_id','')+'-r1',
              'Original campaign schedule, runner snapshot, app and bridge share one request identity.')
        check('terminal-collected', run.get('execution_state') == execution['status']
              and run.get('collection_state') == 'complete' and receipt.get('terminal_confirmed') is True
              and receipt.get('collection_state') == 'complete' and receipt.get('app_run_id') == app,
              'Cancellation acknowledgement alone is insufficient: actual terminal evidence is collected.')
        if not isinstance(events, list) or not events:
            raise Missing('Original sequential ledger event stream absent')
        check('audit-order', all(type(e.get('sequence')) is int for e in events)
              and [e['sequence'] for e in events] == sorted(set(e['sequence'] for e in events))
              and all(e['payload'].get('request_id') == execution.get('request_id') for e in events)
              and all(e['payload'].get('app_run_id') in {None, app} for e in events),
              'Original runner ledger preserves order and stable request/app identity across recovery.')
        kinds = [e['kind'] for e in events]
        check('single-dispatch', kinds.count('dispatch_planned') == 1
              and 'execution_terminal' in kinds and 'collection_complete' in kinds
              and kinds.index('execution_terminal') < kinds.index('collection_complete'),
              'Recovered runner never resubmits the request and collects only after terminal observation.')
        if rule['fault'] in {'observer_interruption','collection_interruption'}:
            check('resume-same-attempt', receipt.get('recovered') is True
                  and any(e.get('event') == 'resume_started' and e.get('request_id') == execution.get('request_id')
                          for e in audit), 'Real restarted observer resumes the same request without executing workflow nodes again.')
        if rule['fault'] == 'cancel':
            check('actual-cancel', 'cancel_requested' in kinds and 'cancel_acknowledged' in kinds
                  and kinds.index('cancel_requested') < kinds.index('cancel_acknowledged') < kinds.index('execution_terminal')
                  and receipt.get('cancellation_requested') is True,
                  'Actual cancel API request and acknowledgement precede terminal observation and collection.')
        if rule['fault'] == 'collection_interruption':
            check('collection-restart', any(e.get('event') == 'collection_resumed' for e in audit),
                  'Interrupted original collection resumes to completeness under the same identity.')
        runner_checks = checks[next(i for i,c in enumerate(checks) if c['id']=='protected-frozen-fault-plan'):]
        metrics['sequential_recovery_success'] = int(all(c['status']=='pass' for c in runner_checks))
        metrics['full_task_success'] = int(metrics['workflow_handoff_success'] == metrics['sequential_recovery_success'] == 1)
    except Missing as error:
        checks.append({'id':'required-evidence','status':'unavailable','reason':str(error),'evidence_refs':list(refs)})
    except (KeyError, ValueError, TypeError, IndexError) as error:
        check('evidence-integrity',False,'Malformed/inconsistent original evidence: '+str(error))
        metrics['full_task_success'] = 0
        critical.append('Original evidence binding or frozen protocol inconsistent')
    return {'checks':checks,'metrics':metrics,'critical_violations':critical}
