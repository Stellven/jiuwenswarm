"""Oracle unit tests only: synthetic records exercise checker logic, not product outcomes."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
import oracle

CRITERIA = json.loads((Path(__file__).parent/'referee/criteria.json').read_text())


def sample(variant='observer-restart'):
    rule=CRITERIA['variants'][variant]
    e={'variant_id':variant,'entrypoint':'run','execution':{'launched':True,'terminal':True,
       'status':'completed' if rule['expected']=='complete' else 'cancelled','app_run_id':'unit-app','request_id':'unit-request'},
       'records':[],'artifacts':{},'module_observations':{}}
    serial=0
    def blob(value):
        nonlocal serial
        serial+=1
        text=value if isinstance(value,str) else json.dumps(value,sort_keys=True,separators=(',',':'))
        ref={'id':'unit-'+str(serial),'sha256':hashlib.sha256(text.encode()).hexdigest()}
        e['artifacts']['unit/'+str(serial)]=text
        return ref
    def record(kind,value):
        ref=blob(value);e['records'].append({'kind':kind,'ref':ref,'record':value});return ref
    stages=CRITERIA['required_nodes'];nodes=[]
    for i,s in enumerate(stages):
        nodes.append({'node_id':s,'predecessors':stages[i-1:i],
                      'cc':{'cc_name':'research.'+s,'cc_version':'unit-v1','declaration_sha256':'a'*64}})
    record('run-plan',{'plan_source':'static','frozen':True,'nodes':nodes,'topological_order':stages})
    for prelude in ('intention_compiler','planner'):
        record('gate-decision',{'scope_kind':'node','run_id':'unit-app','node_id':prelude,'action':'advance'})
    previous=[]
    for i,node in enumerate(nodes):
        if rule['expected']=='halt' and i>=stages.index(rule['stop_node']):break
        identity={'run_id':'unit-app','node_id':node['node_id'],'attempt_id':'unit-attempt'}
        contract=record('node-execution-contract',{**identity,'input_refs':previous})
        out=blob({'unit-stage':node['node_id']})
        worker=record('invocation-observation',{**identity,**node['cc'],'node_contract_ref':contract,
          'input_refs':previous,'output_refs':[out],'observed_runtime':True,'measurement_status':'observed',
          'outcome':'success','started_at':'2026-10-25T00:00:00Z'})
        deterministic=record('deterministic-check-result',{'results':[{'outcome':'PASS'}]})
        assessment=record('verifier-assessment',{'verdict':'PASS'})
        record('gate-decision',{**identity,'scope_kind':'node','node_contract_ref':contract,'action':'advance',
          'verdict':'PASS','accepted_refs':[out],'output_refs':[out],'invocation_refs':[worker],
          'deterministic_result_ref':deterministic,'assessment_ref':assessment,'recorded_at':'2026-10-25T00:00:00Z'})
        previous=[out]
    if rule['fault']=='dependency_failure':
        e['execution']['status']='blocked'
        record('gate-decision',{'scope_kind':'node','run_id':'unit-app','node_id':'benchmark','action':'halt',
                               'verdict':'ENVIRONMENT_BLOCKED','accepted_refs':[],'reasons':[{'code':'dependency_unavailable'}]})
    if rule['expected']=='complete':
        result={'locality':{'hits':2,'misses':4,'unbounded_misses':3},'scan':{'hits':0,'misses':6,'unbounded_misses':4},'burst':{'hits':3,'misses':3,'unbounded_misses':3}}
        stdout=blob({'source_id':'frozen-cache-traces-v1','unit':'requests','results':result})
        receipt=record('execution-receipt',{'runs':[{'exit_code':0,'stdout_ref':stdout}]})
        payload_ref=record('benchmark-payload',{'execution_receipt_ref':receipt})
        report=blob('N1 N2 frozen-cache-traces-v1 counts do not establish latency improvement.')
        manifest_ref=record('delivery-manifest',{'report_ref':report})
        for row in e['records']:
            if row['kind']=='gate-decision' and row['record']['node_id'] in ('benchmark','delivery'):
                r=payload_ref if row['record']['node_id']=='benchmark' else manifest_ref
                row['record']['accepted_refs'].append(r);row['record']['output_refs'].append(r)
    plan=blob(rule['driver_plan'])
    effect=blob({'fault':rule['fault'],'app_run_id':'unit-app','request_id':'unit-request','observed_at':'2026-10-25T00:00:01Z',
                 'operation':{'dependency_failure':'dependency_access_denied','cancel':'cancel_api_acknowledged',
                 'observer_interruption':'observer_process_exit','collection_interruption':'collector_process_exit'}[rule['fault']]})
    audit=[{'event':'plan_frozen','recorded_at':'2026-10-25T00:00:00Z'},
           {'event':'launch_started'},
           {'event':'fault_applied','fault':rule['fault'],'trigger':rule['driver_plan']['trigger'],
             'request_id':'unit-request','app_run_id':'unit-app','effect_receipt_ref':effect},
           {'event':'resume_started','request_id':'unit-request'},{'event':'collection_resumed'}]
    driver=blob({'schema':'pipeline02-controller-receipt:1','variant_id':variant,'plan_ref':plan,
                 'plan_sha256':hashlib.sha256(oracle.canonical(rule['driver_plan'])).hexdigest(),'audit_ref':blob(audit)})
    run={'app_run_id':'unit-app','request_id':'unit-request','campaign_id':'unit-campaign','case_id':'unit-case',
         'run_id':'unit-case-r1','execution_state':e['execution']['status'],'collection_state':'complete'}
    kinds=['dispatch_planned']
    if rule['fault']=='cancel':kinds+=['cancel_requested','cancel_acknowledged']
    kinds+=['execution_terminal','collection_complete']
    events=[{'sequence':i+1,'kind':k,'payload':{'request_id':'unit-request','app_run_id':'unit-app'}} for i,k in enumerate(kinds)]
    pilot={'campaign_id':'unit-campaign','terminal_confirmed':True,'collection_state':'complete','app_run_id':'unit-app',
           'recovered':True,'cancellation_requested':True}
    e['module_observations']['pipeline02']={'driver_receipt_ref':driver,'campaign_ref':blob({'campaign_id':'unit-campaign','cases':[{'id':'unit-case','repeats':1}]}),
        'run_record_ref':blob(run),'events_ref':blob(events),'pilot_receipt_ref':blob(pilot)}
    return e


class OracleTests(unittest.TestCase):
    def test_correct_each_fault(self):
        for variant in CRITERIA['variants']:
            with self.subTest(variant=variant):
                result=oracle.evaluate(sample(variant),CRITERIA)
                self.assertEqual(result['metrics']['full_task_success'],1,result)
    def test_missing_controller_is_unavailable(self):
        e=sample();e['module_observations']={}
        result=oracle.evaluate(e,CRITERIA)
        self.assertEqual(result['metrics']['workflow_handoff_success'],1)
        self.assertIsNone(result['metrics']['sequential_recovery_success'])
        self.assertEqual(result['checks'][-1]['status'],'unavailable')
    def test_prompt_claim_cannot_replace_controller(self):
        e=sample();e['module_observations']={'pipeline02':{'recovered':True,'fault_applied':True}}
        self.assertEqual(oracle.evaluate(e,CRITERIA)['checks'][-1]['status'],'unavailable')
    def test_missing_run(self):
        e=sample();e['execution']['launched']=False
        self.assertEqual(oracle.evaluate(e,CRITERIA)['checks'][-1]['status'],'unavailable')
    def test_wrong_binding(self):
        e=sample();next(r for r in e['records'] if r['kind']=='invocation-observation')['record']['cc_version']='wrong'
        self.assertEqual(oracle.evaluate(e,CRITERIA)['metrics']['full_task_success'],0)
    def test_wrong_handoff(self):
        e=sample();workers=[r for r in e['records'] if r['kind']=='invocation-observation'];workers[1]['record']['input_refs']=[]
        self.assertEqual(oracle.evaluate(e,CRITERIA)['metrics']['workflow_handoff_success'],0)
    def test_foreign_identity(self):
        e=sample();next(r for r in e['records'] if r['kind']=='gate-decision')['record']['run_id']='foreign'
        self.assertEqual(oracle.evaluate(e,CRITERIA)['metrics']['full_task_success'],0)
    def test_tampered_source_bytes(self):
        e=sample();ref=e['module_observations']['pipeline02']['events_ref']
        name=next(n for n,v in e['artifacts'].items() if hashlib.sha256(v.encode()).hexdigest()==ref['sha256']);e['artifacts'][name]='[]'
        self.assertEqual(oracle.evaluate(e,CRITERIA)['checks'][-1]['status'],'unavailable')
    def test_downstream_after_dependency_block(self):
        e=sample('dependency-unavailable');r=copy.deepcopy(next(r for r in e['records'] if r['kind']=='invocation-observation'))
        r['ref']={'id':'unit-leak','sha256':'e'*64};r['record']['node_id']='delivery';e['records'].append(r)
        result=oracle.evaluate(e,CRITERIA)
        self.assertEqual(result['metrics']['full_task_success'],0)
        self.assertTrue(result['critical_violations'])
    def test_duplicate_dispatch(self):
        e=sample();ref=e['module_observations']['pipeline02']['events_ref'];name=next(n for n,v in e['artifacts'].items() if hashlib.sha256(v.encode()).hexdigest()==ref['sha256'])
        events=json.loads(e['artifacts'][name]);events.append({'sequence':4,'kind':'dispatch_planned','payload':events[0]['payload']})
        e['artifacts'][name]=json.dumps(events);ref['sha256']=hashlib.sha256(e['artifacts'][name].encode()).hexdigest()
        self.assertEqual(oracle.evaluate(e,CRITERIA)['metrics']['sequential_recovery_success'],0)
    def test_bad_cache_count(self):
        e=sample();name=next(n for n,v in e['artifacts'].items() if 'unbounded_misses' in v);old=hashlib.sha256(e['artifacts'][name].encode()).hexdigest()
        raw=json.loads(e['artifacts'][name]);raw['results']['scan']['hits']=6;e['artifacts'][name]=json.dumps(raw)
        new=hashlib.sha256(e['artifacts'][name].encode()).hexdigest()
        for row in e['records']:
            if row['kind']=='execution-receipt':row['record']['runs'][0]['stdout_ref']['sha256']=new
        self.assertEqual(oracle.evaluate(e,CRITERIA)['metrics']['workflow_handoff_success'],0)


if __name__=='__main__':unittest.main()
