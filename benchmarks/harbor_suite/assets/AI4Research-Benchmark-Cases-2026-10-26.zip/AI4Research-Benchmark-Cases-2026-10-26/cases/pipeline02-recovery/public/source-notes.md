# Frozen cache research notes (development)
N1: A hit means the key is resident before its request. A miss inserts it; a full LRU cache evicts its least recently requested key. Every request updates recency.
N2: Compare two-entry LRU with unbounded caching on every supplied trace. Compute counts deterministically; do not infer elapsed-time speedups from hit counts.
N3: Retain unfavorable traces. Cite N1/N2 and frozen-cache-traces-v1. A negative hypothesis is a valid research result.
These authored notes define the experiment; they are not external published research or held-out data.
