# pipeline02-recovery

Development-only S03 fixed-workflow fault benchmark with a short S10 analogue.
It makes no 2/4/10-hour, memory-pressure, long-horizon or autonomous recovery
claim. All public fixtures are authored development material, not held-out data.

The research task compares two-entry LRU with unbounded caching on three frozen
request traces. The seven governed research stages are search, screening,
hypothesis, builder, benchmark, evaluation and delivery. Exact admitted capsule
versions/hashes come from the installed frozen library, not fixture names.
Public notes specify hit/miss semantics and prohibit inferring elapsed-time
speedups from counts. The oracle independently recomputes every trace and checks
source IDs in the original delivered report. Interpretation and citation quality
beyond deterministic source tokens require human review.

Four independently controlled variants cover dependency unavailability before
benchmark dispatch, cancellation after builder, observer process interruption
after initial submission, and collection process interruption. First two require
an attributable halt with no benchmark/evaluation/delivery execution. Last two
resume the host observer/collector on the same request and finish the original
workflow. Restarting an observer is not restarting or repairing a workflow node.
The original fixed plan forbids replanning, repeated node attempts and automatic
repair. Fault plans live only in referee/criteria.json and never enter prompts.

The oracle reports workflow_handoff_success independently of
sequential_recovery_success. Full success requires both. Workflow checks use
original E1 run-plan, node-execution-contract, invocation-observation,
gate-decision, deterministic-check-result and verifier-assessment records.
Completed variants additionally require actual execution-receipt stdout,
benchmark-payload and delivery-manifest artifacts accepted by original gates.
CPU stdout is JSON with source_id=frozen-cache-traces-v1, unit=requests and
results mapping every trace to hits, misses and unbounded_misses. Every measured
run is retained; no candidate code executes in the oracle.

## Required protected projection (currently unavailable)

The current shared adapter explicitly blocks this case because no supported
fault controller is available. Packaging and unit tests are not live readiness.
Missing controller, authority, originals or audit binding is unavailable/BLOCKED,
never a simulated performance result. Ordinary E1 text asking a model to pretend
an interruption cannot satisfy this case. Do not implement new product fields.

A future parent normalizer may expose module_observations.pipeline02 only after
independent host custody validation. It contains these source Refs:

- driver_receipt_ref: original protected host controller receipt.
- campaign_ref: original sequential campaign.json (sequential-campaign:1).
- run_record_ref: original runs/<attempt>/run_record.json.
- events_ref: read-only original ledger.events(attempt) export, retaining sequence,
  kind and payload exactly as Ledger.events() returns them.
- pilot_receipt_ref: original pilot-receipt.json from the existing Harbor bridge.

Each Ref has id and sha256, and the original bounded UTF-8 bytes must be included
in artifacts. The parent must authenticate producer/custody and preserve the
complete read-only audit closure, not invent successful receipt fields. File
hashes alone do not authenticate who caused an effect. These are benchmark
projection requirements, not accepted product record kinds or product tokens.
Do not pass controller documents through the product-record schema validator.

The proposed benchmark host controller receipt schema is
pipeline02-controller-receipt:1 with variant_id, plan_ref, plan_sha256 and
audit_ref. plan_ref resolves to the exact protected driver_plan in the selected
criteria variant; plan_sha256 hashes its canonical sorted compact JSON. The
controller must freeze this plan before dispatch and emit real audit events in
order: plan_frozen, launch_started, fault_applied. fault_applied includes fault,
trigger, request_id, app_run_id and effect_receipt_ref. The latter resolves to an
original actual controller effect receipt with fault, request_id, app_run_id,
observed_at and operation. Operations are dependency_access_denied,
cancel_api_acknowledged, observer_process_exit or collector_process_exit,
respectively. Controller process/API/dependency action evidence must be
independently collected and authenticated; candidate-authored JSON is invalid.
An exit event must identify the actual protected process in the external audit
closure; a nonzero candidate script exit code is insufficient evidence.

Interrupted observer/collection variants additionally retain actual
resume_started(request_id), and collection interruption retains collection_resumed.
The normalizer must join process exits/resumes to the exact observer/collector
process identities and campaign, preserve fault timing at the declared trigger,
and reject incomplete/contradictory audit records. Attributable dependency gate
and cancellation API request/acknowledgement must bind to the same affected app
run. No authenticated audit source means the projection remains absent.

Actual maintained sequential fields are campaign_id, case_id, run_id,
request_id, app_run_id, execution_state, collection_state. Ledger payloads retain
request_id/app_run_id and original kind events such as dispatch_planned,
cancel_requested, cancel_acknowledged, execution_terminal, collection_complete.
Bridge receipt fields include campaign_id, app_run_id, terminal_confirmed,
collection_state, recovered and cancellation_requested. Recovery must reconcile
same request without resubmission and collect a terminal run before another
trial can dispatch. Parent normalization must separately validate the durable
ledger attempt claim/fingerprint, active pointer/lock ownership, immutable public
input/build pins and absence of later dispatch until collection resolves; these
host authority checks cannot be inferred from candidate booleans or exit codes.

Source alignment: AUTHORING.md; approved QA/BENCHMARK_REQUIREMENTS.md S03,
S10, PL01-05 and LH02/04/05; maintained research/run_contracts.py and
research_contracts/schemas/{gate-decision,invocation-observation.v4};
research_sidecar/{sequential,ledger}.py and harbor_pilot/bridge.py. Proposed
QA/BENCHMARK_INTERFACE_CONTRACT.md does not grant controller authority or add a
supported injection interface.

## Oracle unit tests only

Run `python -m unittest discover -s benchmarks/harbor_suite/cases/pipeline02-recovery`.
All test identities and receipts are synthetic unit-test inputs only, never
production observations or benchmark measurements. Coverage includes each fault,
missing actual execution/controller, prompt flags, byte tampering, duplicate
dispatch, foreign identity, changed binding/handoff, downstream execution after
block, and wrong independently recomputed cache results.
