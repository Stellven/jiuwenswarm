"""Oracle unit tests only; synthetic in-memory records are never campaign evidence."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).parent
SPEC = importlib.util.spec_from_file_location('mr01_oracle', ROOT/'oracle.py')
oracle = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(oracle)
CRITERIA = json.loads((ROOT/'referee/criteria.json').read_text())


def fixture(variant='c01-inference'):
    evidence = {'variant_id': variant, 'entrypoint': 'routing', 'execution': {'launched': True, 'terminal': True, 'status': 'completed'}, 'records': [], 'artifacts': {}, 'module_observations': {'mr01': {'compatible_tiers': ['small', 'gpt-6.1-sol'], 'calibration_snapshot': {'frozen_at':'2026-10-25T00:00:30Z','expected_cost_by_tier':{'small':1,'gpt-6.1-sol':3}}, 'samples': []}}}
    def record(kind, ident, body):
        ref = {'id': 'unit-'+ident, 'sha256': hashlib.sha256(json.dumps(body,sort_keys=True).encode()).hexdigest()}
        evidence['records'].append({'kind':kind,'ref':ref,'record':body})
        return ref
    plan = record('run-plan','plan',{'frozen':True,'nodes':[{'node_id':'work','cc':{'cc_name':'research.work','cc_version':'1','declaration_sha256':'b'*64}}],'limits':{'tokens':1000},'library_snapshot_ref':{'id':'unit-library','sha256':'a'*64}})
    profile = record('model-selection-profile','profile',{'approved_model_ids':['small','gpt-6.1-sol']})
    for phase, tier in [('calibration','small'),('calibration','gpt-6.1-sol'),('fixed','gpt-6.1-sol'),('routed','small')]:
        for repeat in range(3):
            ident=phase+tier+str(repeat)
            deployment={'id':'unit-deployment-'+tier,'sha256':'1'*64}
            decision=record('model-route','decision-'+ident,{'identity':{'requested':tier},'execution_id':'unit-exec-'+ident,'model_selection_profile_ref':profile,'deployment_ref':deployment,'binding_id':'unit-binding'}) if phase=='routed' else None
            text=json.dumps(CRITERIA['variants'][variant]['answer'])
            path='outputs/'+ident+'.json'
            evidence['artifacts'][path]=text
            output={'id':'unit-output-'+ident,'sha256':hashlib.sha256(text.encode()).hexdigest()}
            when='2026-10-25T00:00:0%dZ'%repeat if phase=='calibration' else '2026-10-25T00:01:0%dZ'%repeat
            call={'execution_id':'unit-exec-'+ident,'invocation_id':'unit-inv-'+ident,'purpose':'task_execution','call_function':'worker','observed_runtime':True,'outcome':'completed','identity':{'requested':tier,'effective':tier,'basis':'unit-test'},'deployment_ref':deployment,'route_decision_ref':decision if phase=='routed' else None,'model_selection_profile_ref':profile,'started_at':when,'ended_at':when,'usage':{'cost_amount':1 if tier=='small' else 3,'currency':'USD'}}
            cr=record('model-call','call-'+ident,call)
            route={'run_id':'unit-run-'+ident,'node_id':'work','route_id':'unit-route-'+ident,'invocation_id':call['invocation_id'],'model_id':tier,'decision_source':'router' if phase=='routed' else 'codex_router_disabled','router_enabled':phase=='routed','route_decision_ref':call['route_decision_ref']}
            rr=record('route-record','route-'+ident,route)
            obs={'run_id':route['run_id'],'node_id':'work','binding_id':'unit-binding','route_id':route['route_id'],'observed_runtime':True,'outcome':'success','trace_refs':[cr,rr],'output_refs':[output],'cc_name':'research.work','cc_version':'1','declaration_sha256':'b'*64,'body_files_sha256':'c'*64,'contract_ref':{'id':'unit-contract','sha256':'d'*64},'input_refs':[{'id':'unit-input','sha256':'e'*64}]}
            ir=record('invocation-observation','obs-'+ident,obs)
            evidence['module_observations']['mr01']['samples'].append({'phase':phase,'tier':tier,'repeat':repeat,'call_ref':cr,'route_ref':rr,'observation_ref':ir,'plan_ref':plan,'output_ref':output,'output_path':path})
    return evidence


def rows(evidence, kind):
    return [r['record'] for r in evidence['records'] if r['kind']==kind]


class OracleTests(unittest.TestCase):
    def run_case(self,e):
        return oracle.evaluate(e,CRITERIA)

    def test_complete_correct_all_eight_domains(self):
        for variant in CRITERIA['variants']:
            with self.subTest(variant=variant):
                result=self.run_case(fixture(variant))
                self.assertTrue(all(c['status']=='pass' for c in result['checks']),result)
                self.assertAlmostEqual(result['metrics']['quality_preserving_savings'],2/3)
                self.assertEqual(result['metrics']['quality_denominator'],3)
                self.assertEqual(len(result['metrics']['domains']),8)
                self.assertEqual(sum(d['observed_pairs'] for d in result['metrics']['domains'].values()),3)

    def test_missing_projection_unavailable(self):
        result=self.run_case({'variant_id':'c01-inference'})
        self.assertEqual(result['checks'][0]['status'],'unavailable')

    def test_missing_original_call_unavailable(self):
        e=fixture();e['records']=[r for r in e['records'] if r['kind']!='model-call']
        self.assertIn('unavailable',[c['status'] for c in self.run_case(e)['checks']])

    def test_static_route_cannot_score_dynamic_quality(self):
        e=fixture()
        for r in rows(e,'route-record'):
            r['decision_source']='codex_router_disabled'
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_actual_model_call_join_required(self):
        e=fixture();rows(e,'model-call')[-1]['invocation_id']='foreign'
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_synthetic_runtime_rejected(self):
        e=fixture();rows(e,'model-call')[-1]['observed_runtime']=False
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_changed_capsule_pin_rejected(self):
        e=fixture();rows(e,'invocation-observation')[-1]['body_files_sha256']='f'*64
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_no_lucky_single_calibration_pass(self):
        e=fixture();e['module_observations']['mr01']['samples'].pop(0)
        result=self.run_case(e)
        self.assertIn('unavailable',[c['status'] for c in result['checks']])
        self.assertIsNone(result['metrics']['savings_fraction'])

    def test_wrong_answer_preserves_failure_denominator(self):
        e=fixture();s=e['module_observations']['mr01']['samples'][-1]
        text='{}';e['artifacts'][s['output_path']]=text
        s['output_ref']['sha256']=hashlib.sha256(text.encode()).hexdigest()
        # Exact same Ref object is held in the invocation in this unit fixture.
        result=self.run_case(e)
        self.assertEqual(result['metrics']['routed_correct'],2)
        self.assertEqual(result['metrics']['quality_denominator'],3)
        self.assertIsNone(result['metrics']['quality_preserving_savings'])

    def test_answer_bytes_hash_checked(self):
        e=fixture();s=e['module_observations']['mr01']['samples'][-1];e['artifacts'][s['output_path']]='{}'
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_cost_unavailable_never_invents_savings(self):
        e=fixture();rows(e,'model-call')[-1]['usage']['cost_amount']=None
        result=self.run_case(e)
        self.assertEqual(result['metrics']['routed_correct'],3)
        self.assertIsNone(result['metrics']['savings_fraction'])
        self.assertEqual(result['checks'][-1]['status'],'unavailable')

    def test_full_execution_accounts_for_verifier_expense(self):
        e=fixture();call=copy.deepcopy(rows(e,'model-call')[-1]);call['call_function']='verifier';call['usage']['cost_amount']=9
        e['records'].append({'kind':'model-call','ref':{'id':'unit-extra-verifier','sha256':'9'*64},'record':call})
        result=self.run_case(e)
        self.assertEqual(result['metrics']['routed_expense'],12)
        self.assertLess(result['metrics']['savings_fraction'],0)

    def test_post_router_calibration_rejected(self):
        e=fixture();rows(e,'model-call')[0]['ended_at']='2026-10-25T01:00:00Z'
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_duplicate_observation_cannot_expand_denominator(self):
        e=fixture();s=e['module_observations']['mr01']['samples'];s.append(copy.deepcopy(s[-1]))
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_insufficient_cheap_route_keeps_negative_gaps(self):
        e=fixture();s=e['module_observations']['mr01']['samples'][0]
        e['artifacts'][s['output_path']]='{}';s['output_ref']['sha256']=hashlib.sha256(b'{}').hexdigest()
        result=self.run_case(e)
        self.assertEqual(result['metrics']['cheapest_qualifying_tier'],'gpt-6.1-sol')
        self.assertEqual(result['metrics']['insufficient_tier_choices'],3)
        self.assertEqual(result['metrics']['signed_regret'],[-2,-2,-2])
        self.assertIsNone(result['metrics']['quality_preserving_savings'])

    def test_boolean_is_not_numeric_answer(self):
        self.assertFalse(oracle.equal_answer({'correct':True},{'correct':1}))

    def test_decision_must_select_actual_model(self):
        e=fixture();rows(e,'model-route')[-1]['identity']['requested']='other-model'
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_cost_table_must_precede_router(self):
        e=fixture();e['module_observations']['mr01']['calibration_snapshot']['frozen_at']='2026-10-25T01:00:00Z'
        self.assertTrue(self.run_case(e)['critical_violations'])

    def test_actual_capsule_must_match_plan(self):
        e=fixture()
        for obs in rows(e,'invocation-observation'):
            obs['cc_name']='foreign.capsule'
        self.assertTrue(self.run_case(e)['critical_violations'])


if __name__=='__main__':
    unittest.main()
