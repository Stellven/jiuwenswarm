# MR-01: matched routing quality and complete expense

Development benchmark for S07 / RT01, RT02, RT04, RT05, RT06 and RT07 at **M2**, reusable with independently pinned configuration at **M3**. This is not an M1 release criterion. Eight independently authored bounded technical research nodes cover C01 inference threshold selection, C02 retrieval precision, C03 directed shortest paths, C04 tail-latency deployment decisions, C05 deduplication, C06 quorum intersection, C07 fail-closed authorization semantics and C08 paired experimental data. Each public fixture states its operation and output contract. Protected labels are independently deterministic computations; they are not producer verdicts or model judgments. All files are DEVELOPMENT material, without held-out claims.

The research obligation is to retain exact technical correctness while changing only the worker model route. Qualifying difficulty is measured by real calibration; the domain, prompt length and author opinion do not assign difficulty. Small structured outputs exercise mechanical correctness, not open-ended research interpretation. The latter remains `human_review_required`. These compact inputs do not establish long-context quality, broad verifier quality or real long-horizon reliability. Verifier calls remain fixed Codex under RTR-8 unless an existing approved alternate-verifier profile applies; their complete expense is included. Router compatibility/failure fault coverage is in MR-02.

## Execution binding and readiness

Use the existing `routing` entrypoint with externally supplied supported campaign, job and evaluation-profile bindings. The parent owns invocation and export validation. This case creates no API, profile approval, endpoint grant or placeholder product identity. Without those bindings, qualified real endpoints, complete original exports and the projection below, report **BLOCKED / unavailable**. A prompt through the static Codex route is not a routing experiment.

The existing adapter `jiuwenswarm/research_sidecar/adapters/routing.py` requires actual `task_execution` calls joined by invocation/model/decision/profile, rejecting synthetic evidence. The maintained `Architecture_Design/side-systems/model-routing.md` defines static `codex_router_disabled`, dynamic `router`, immutable call choice, and fixed verifier behavior. Original record fields come from `jiuwenswarm/research_contracts/schemas/field-contracts.compiled.schema.json`: `route-record`, `model-call`, `model-route`, `invocation-observation`, `run-plan` and `model-selection-profile`. `frozen_records.py` defines exact Ref/export verification. Requirements authority is approved QA `BENCHMARK_REQUIREMENTS.md` v0.12, Sections 6, 6.1 and S07; the proposed interface contract supplies no new authority.

Per domain item, replay one frozen node/plan against each compatible tier for three calibration repeats, then three fixed `gpt-6.1-sol` and three routed observations paired by repeat index. At least two qualified compatible tiers are required. The planned minimum is 12 worker observations per item, 96 across eight items, plus any existing planning, verifier and selection calls. The per-variant 96-call ceiling includes those calls; preflight must establish feasibility rather than assume enough remaining host memory. A one-repeat smoke is only a wiring check and cannot yield a scored campaign. No real calls were launched while authoring this case.

Keep capsule declaration/body/admission/catalogue, contract and check pins, exact plan Ref, inputs, tools, input/output limits and verifier profile identical across calibration/fixed/routed arms. Freeze host/settings/environment and call-role policies in the supported external campaign configuration. The oracle compares original plan, node limits/check pins, library and invocation identity/input pins. The parent must validate the external tool/verifier/environment pins, deployment qualification and roster rather than accept an unbound boolean asserting equality.

## Read-only normalized projection required from parent

`evaluate(evidence, criteria)` consumes the AUTHORING normalized envelope and returns checks with `pass`, `fail` or `unavailable`, metric values, and integrity violations. It does not import product code. Original validated records remain in `records`; original bounded UTF-8 answer text remains in `artifacts`. Ref IDs and SHA-256 values must match the exported bytes. The oracle independently hashes answer bytes and checks that their output Ref belongs to the invocation. The parent independently validates all record bytes, schemas, source authority, run identity and archive completeness before projection.

`module_observations.mr01` is a **read-only external campaign projection**, not a new product wire schema:

```json
{
  "compatible_tiers": ["actual externally qualified model IDs"],
  "calibration_snapshot": {
    "frozen_at": "UTC timestamp from externally frozen campaign metadata",
    "expected_cost_by_tier": {"actual model ID": 0.0}
  },
  "samples": [{
    "phase": "calibration|fixed|routed",
    "tier": "actual model ID",
    "repeat": 0,
    "call_ref": {"id": "original", "sha256": "original digest"},
    "route_ref": {"id": "original", "sha256": "original digest"},
    "observation_ref": {"id": "original", "sha256": "original digest"},
    "plan_ref": {"id": "original", "sha256": "original digest"},
    "output_ref": {"id": "original", "sha256": "original digest"},
    "output_path": "safe original artifact path"
  }]
}
```

The example illustrates field names only, not runnable identities or cost observations. `repeat` takes 0, 1, 2. Parent derives assignments from immutable supported campaign/job bindings, never from worker output. Each sample is one distinct complete execution and one worker call. Node replay must preserve the same frozen plan Ref; a plan regenerated per arm cannot establish isolation. Join each projected call to the original `route-record` via invocation, requested model and decision Ref; join the route to original invocation via route/run/node identities and `trace_refs`. Resolve the call's `model_selection_profile_ref` and require the selected model in `approved_model_ids`; require effective model attribution. Dynamic decisions must resolve an original `model-route` matching model, deployment, profile, execution and binding. Absence cannot be replaced with a claimed route success.

`output_ref` resolves the invocation's actual output text payload, whose bytes the parent places at `output_path`; nested envelopes must be resolved and verified before supplying this payload relationship. Do not supply a report mentioning the answer as though it were the bound answer artifact. If the current supported export cannot expose the needed output identity relationship, withhold this check rather than fabricate it.

The compatible-tier roster and calibration snapshot come from the protected, externally frozen campaign metadata, with its existing source identities retained by the parent. Freeze calibration outputs and complete per-tier cost table before the first scored routed call and keep them outside worker/router context. The oracle checks temporal order and recomputes the frozen table from original calls. Parent must validate roster completeness/compatibility and metadata custody; these are not unbound product claims. Missing this protected projection yields unavailable. It must never be synthesized from the selected tier alone.

For every sample execution ID, export **all** original `model-call` records, including planner, worker, verifier, routing-selection and permitted fallback calls, failures and unknown outcomes. The oracle sums every such call's `usage.cost_amount`; matching currency is mandatory. Parent must establish export completeness from original supported retrieval/manifest accounting, because an oracle cannot detect a call omitted from its input. Unknown provider price/currency withholds costs and savings while preserving independent quality counts. Authoring and RSI costs are measured separately, with no amortization implied. If full role coverage, tariffs or source exports are unavailable, retain explicit unavailable reasons, never infer zero expense.

## Scoring and interpretation

Calibration uses three repeats per compatible tier, exact required JSON answers, success rate 1.0 and two-sided Wilson 95% lower confidence bound at least 0.4. This preregistered development criterion admits 3/3 (lower bound about 0.4385); it is not a deployment-reliability guarantee or a requirements-mandated universal threshold. All calibration observations must end before the frozen table and routed test. The cheapest qualifying tier is selected by independently recomputed mean complete calibration execution expense. Incomparable costs or no qualifying tier withhold difficulty/regret.

Per-domain quality numerator is exact-answer passes over the fixed denominator of three per arm. Preserve eight domain rows, including unavailable rows; full suite denominator is 24 matched pairs. Report domain and calibrated-tier results before aggregating. Quality delta is `(routed_passes-fixed_passes)/3`; a routed regression cannot be hidden by another domain. Capsule-gain retention is explicitly unavailable without a separately measured capsule-free comparison.

Expense saving is `(fixed_complete_expense-routed_complete_expense)/fixed_complete_expense`. Quality-preserving saving is exposed only with all fixed and routed answers correct, complete comparable accounting and no insufficient-tier choices. No proposed 20% threshold is made a release gate. Item regret is `calibrated_expected_cost(chosen)-calibrated_expected_cost(cheapest_qualifying)`. Report each signed gap, positive excess cost and insufficient-tier choice count/3 separately. A cheaper insufficient route can have negative regret but never earns a quality-preserving-savings claim. Domain rows from one invocation do not establish all-eight campaign completion. Repeats and calibration Wilson bounds are retained; three observations cannot establish broad statistical superiority.

## Oracle unit tests

Run `D:\Codex Development Runs\.harbor-pilot-runtime\venv\Scripts\python.exe test_oracle.py` from this directory. Tests use labeled in-memory synthetic records solely to test the checker; they are not eligible real-endpoint evidence and must never be submitted as production observations. They cover correct outputs in every domain, missing evidence, static/synthetic route rejection, joins, pin mutation, repeated calibration, wrong/hash-mismatched answers, expense gaps, verifier overhead, insufficient cheap choices and frozen-table order. The protected referee directory, oracle, tests and labels must remain outside the evaluated application/container.
