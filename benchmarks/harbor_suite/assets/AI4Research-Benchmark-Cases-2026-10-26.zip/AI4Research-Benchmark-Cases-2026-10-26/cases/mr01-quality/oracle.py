"""Independent development oracle. No product imports, services or model judge."""
import hashlib
import json
import math
import re


class Missing(ValueError):
    pass


def key(ref):
    if not isinstance(ref, dict) or set(ref) != {'id', 'sha256'} or not isinstance(ref['id'], str) or not ref['id'] or not isinstance(ref['sha256'], str) or not re.fullmatch('[a-f0-9]{64}', ref['sha256']):
        raise Missing('exact Ref absent')
    return ref['id'], ref['sha256']


def wilson_lower(passed, total):
    z = 1.959963984540054
    p = passed / total
    return (p + z*z/(2*total) - z*math.sqrt(p*(1-p)/total + z*z/(4*total*total))) / (1+z*z/total)


def equal_answer(actual, expected):
    if isinstance(expected, dict):
        return isinstance(actual, dict) and set(actual) == set(expected) and all(equal_answer(actual[k], v) for k,v in expected.items())
    if isinstance(expected, list):
        return isinstance(actual, list) and len(actual) == len(expected) and all(equal_answer(a,b) for a,b in zip(actual,expected))
    if type(expected) in (int,float):
        return type(actual) in (int,float) and math.isfinite(actual) and actual == expected
    return type(actual) is type(expected) and actual == expected


def evaluate(evidence, criteria):
    checks, metrics, violations = [], {'model_judged_share': 0, 'human_review_required': ['open-ended scientific interpretation'], 'domains': {v['domain']: {'planned_paired_observations': criteria['repeats'], 'observed_pairs': 0, 'status': 'unavailable'} for v in criteria['variants'].values()}, 'quality_preserving_savings': None, 'savings_fraction': None}, []
    records = {}
    try:
        for row in evidence.get('records', []):
            k = key(row['ref'])
            if k in records:
                raise Missing('duplicate original Ref')
            records[k] = row
    except (KeyError, TypeError, ValueError) as exc:
        return {'checks': [{'id': 'record-integrity', 'status': 'fail', 'reason': str(exc), 'evidence_refs': []}], 'metrics': metrics, 'critical_violations': ['ambiguous-records']}

    def resolve(ref, kind=None):
        row = records.get(key(ref))
        if row is None or kind and row['kind'] != kind:
            raise Missing('original ' + str(kind) + ' record unavailable')
        return row['record']

    def sample(row, phase):
        call = resolve(row['call_ref'], 'model-call')
        route = resolve(row['route_ref'], 'route-record')
        obs = resolve(row['observation_ref'], 'invocation-observation')
        plan = resolve(row['plan_ref'], 'run-plan')
        if plan.get('frozen') is not True:
            raise ValueError('plan not frozen')
        nodes = [node for node in plan.get('nodes', []) if node.get('node_id') == obs.get('node_id')]
        if len(nodes) != 1 or nodes[0].get('cc') != {k:obs.get(k) for k in ('cc_name','cc_version','declaration_sha256')}:
            raise ValueError('actual invocation capsule does not match frozen plan node')
        if call.get('observed_runtime') is not True or obs.get('observed_runtime') is not True or obs.get('outcome') == 'synthetic_example':
            raise ValueError('real runtime evidence required')
        if call.get('purpose') != 'task_execution' or call.get('call_function') != 'worker':
            raise ValueError('worker task call required')
        if (call.get('invocation_id') != route.get('invocation_id') or route.get('route_id') != obs.get('route_id') or route.get('run_id') != obs.get('run_id') or route.get('node_id') != obs.get('node_id')):
            raise ValueError('route/call/invocation join mismatch')
        if row['call_ref'] not in obs.get('trace_refs', []) or row['route_ref'] not in obs.get('trace_refs', []):
            raise ValueError('invocation trace excludes selected call or route')
        if call.get('route_decision_ref') != route.get('route_decision_ref'):
            raise ValueError('decision join mismatch')
        profile = resolve(call['model_selection_profile_ref'], 'model-selection-profile')
        model = call.get('identity', {}).get('requested')
        if model != route.get('model_id') or model not in profile.get('approved_model_ids', []):
            raise ValueError('selected model not approved or mismatched')
        if call.get('identity', {}).get('effective') != model:
            raise Missing('effective model identity unavailable or differs')
        if phase == 'routed':
            if route.get('decision_source') != 'router' or route.get('router_enabled') is not True:
                raise ValueError('static/fallback route is not dynamic routing quality')
            decision = resolve(route['route_decision_ref'], 'model-route')
            if (decision.get('identity', {}).get('requested') != model or decision.get('execution_id') != call.get('execution_id') or decision.get('model_selection_profile_ref') != call.get('model_selection_profile_ref') or decision.get('deployment_ref') != call.get('deployment_ref') or decision.get('binding_id') != obs.get('binding_id')):
                raise ValueError('API decision model/deployment/profile/execution/binding mismatch')
        elif phase == 'fixed' and (model != criteria['baseline_model'] or route.get('decision_source') != 'codex_router_disabled'):
            raise ValueError('fixed baseline must use pinned gpt-6.1-sol')
        if route.get('decision_source') != 'router' and route.get('route_decision_ref') is not None:
            raise ValueError('fixed route carries API decision')
        if row['output_ref'] not in obs.get('output_refs', []):
            raise ValueError('answer not bound to invocation output')
        raw = evidence.get('artifacts', {}).get(row['output_path'])
        if not isinstance(raw, str) or len(raw) > 16384:
            raise Missing('bounded original answer bytes unavailable')
        if hashlib.sha256(raw.encode()).hexdigest() != row['output_ref']['sha256']:
            raise ValueError('answer bytes fail original Ref hash')
        def pairs(items):
            obj = {}
            for name,value in items:
                if name in obj:
                    raise ValueError('duplicate answer field')
                obj[name] = value
            return obj
        try:
            answer = json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite answer')))
        except ValueError:
            answer = None
        correct = call.get('outcome') == 'completed' and obs.get('outcome') == 'success' and equal_answer(answer, criteria['variants'][evidence['variant_id']]['answer'])
        pins = (row['plan_ref'], plan.get('nodes'), plan.get('limits'), plan.get('library_snapshot_ref'), obs.get('cc_name'), obs.get('cc_version'), obs.get('declaration_sha256'), obs.get('body_files_sha256'), obs.get('contract_ref'), obs.get('input_refs'))
        return {'correct': correct, 'model': model, 'pins': pins, 'call': call, 'row': row}

    p = evidence.get('module_observations', {}).get('mr01')
    variant = evidence.get('variant_id')
    if variant not in criteria['variants'] or not isinstance(p, dict):
        return {'checks': [{'id': 'routing-campaign', 'status': 'unavailable', 'reason': 'Supported campaign/profile projection or known variant absent; BLOCKED', 'evidence_refs': []}], 'metrics': metrics, 'critical_violations': []}
    domain = criteria['variants'][variant]['domain']
    metrics['domains'][domain] = {'planned_paired_observations': criteria['repeats'], 'observed_pairs': 0}
    refs = []
    def check(ident, status, reason):
        checks.append({'id': ident, 'status': status, 'reason': reason, 'evidence_refs': refs[:]})
    try:
        if evidence.get('entrypoint') != 'routing' or not evidence.get('execution', {}).get('terminal'):
            raise Missing('terminal routing execution unavailable')
        rows = p['samples']
        if not rows:
            raise Missing('actual paired/calibration observations absent')
        seen = set()
        samples = []
        for row in rows:
            identity = (row['phase'], row.get('tier'), row['repeat'])
            if identity in seen:
                raise ValueError('duplicate phase/tier/repeat')
            seen.add(identity)
            refs.extend([row['call_ref'], row['route_ref'], row['observation_ref'], row['plan_ref']])
            if row['phase'] not in {'calibration', 'fixed', 'routed'}:
                raise ValueError('unknown phase')
            samples.append(sample(row, row['phase']))
        if len({key(s['row']['call_ref']) for s in samples}) != len(samples) or len({s['call']['execution_id'] for s in samples}) != len(samples):
            raise ValueError('sample call or complete execution reused across observations')
        if any(s['pins'] != samples[0]['pins'] for s in samples):
            raise ValueError('capsule/plan/catalogue/contract/input/budget pins changed across arms')
        check('real-route-and-matched-pins', 'pass', 'Original route, actual model call, invocation, approved profile and output bytes joined; frozen pins equal.')
        n = criteria['repeats']
        tiers = p['compatible_tiers']
        if len(tiers) < 2 or len(tiers) != len(set(tiers)):
            raise Missing('at least two externally qualified compatible tiers required')
        fixed = [s for s in samples if s['row']['phase'] == 'fixed']
        routed = [s for s in samples if s['row']['phase'] == 'routed']
        if any(sorted(s['row']['repeat'] for s in arm) != list(range(n)) for arm in (fixed, routed)):
            raise Missing('three fixed/routed repeats required; smoke is wiring only')
        calibration = {}
        for tier in tiers:
            arm = [s for s in samples if s['row']['phase'] == 'calibration' and s['row']['tier'] == tier]
            if sorted(s['row']['repeat'] for s in arm) != list(range(n)) or any(s['model'] != tier for s in arm):
                raise Missing('complete tier calibration absent')
            calibration[tier] = arm
        if len(samples) != (len(tiers)+2)*n:
            raise ValueError('unrecognized or unassigned sample')
        if max(s['call']['ended_at'] for arm in calibration.values() for s in arm) >= min(s['call']['started_at'] for s in routed):
            raise ValueError('calibration was not completed before routed testing')
        stats = {t: {'passed': sum(s['correct'] for s in arm), 'denominator': n, 'wilson95_lower': wilson_lower(sum(s['correct'] for s in arm), n)} for t, arm in calibration.items()}
        metrics['calibration'] = stats
        for stat in stats.values():
            stat['qualifying'] = stat['passed']/n >= criteria['calibration_min_rate'] and stat['wilson95_lower'] >= criteria['calibration_wilson_lower']
        check('calibration', 'pass', 'Every compatible tier repeated before router; deterministic exact-answer oracle, fixed rate and Wilson criterion.')
        fq, rq = sum(s['correct'] for s in fixed), sum(s['correct'] for s in routed)
        metrics.update(fixed_correct=fq, routed_correct=rq, quality_denominator=n, quality_delta=(rq-fq)/n, capsule_gain_retention=None, capsule_gain_retention_reason='No separately measured capsule-free comparison; do not invent capsule gains.')
        metrics['domains'][domain].update(observed_pairs=n, fixed_correct=fq, routed_correct=rq, status='observed')
        check('quality-preservation', 'pass' if rq == fq == n else 'fail', 'Exact technical answers: fixed %d/%d; routed %d/%d. No cross-domain compensation.' % (fq,n,rq,n))
        # Complete expense is the sum of every call belonging to each externally
        # bound execution, including planner, verifier, selection and fallback.
        all_calls = [(r['ref'], r['record']) for r in records.values() if r['kind'] == 'model-call']
        costs = {}
        calibration_expense_ends = []
        for s in samples:
            execution = s['call']['execution_id']
            calls = [(ref,c) for ref,c in all_calls if c.get('execution_id') == execution]
            if any(c.get('observed_runtime') is not True for _,c in calls):
                raise Missing('non-runtime call in execution accounting')
            if s['row']['phase'] == 'calibration':
                if any(not c.get('ended_at') for _,c in calls):
                    raise Missing('calibration execution expense not terminal before freeze')
                calibration_expense_ends.extend(c['ended_at'] for _,c in calls)
            usages = [c.get('usage', {}) for _,c in calls]
            if any(u.get('cost_amount') is None or u.get('currency') is None for u in usages):
                raise Missing('complete execution expense unavailable; provider usage has missing price/currency')
            if any(type(u['cost_amount']) not in (int,float) or not math.isfinite(u['cost_amount']) or u['cost_amount'] < 0 for u in usages):
                raise ValueError('invalid execution expense')
            currencies = {u['currency'] for u in usages}
            if len(currencies) != 1:
                raise Missing('mixed currencies require frozen comparable cost table')
            refs.extend(ref for ref,_ in calls)
            costs[key(s['row']['call_ref'])] = (sum(u['cost_amount'] for u in usages), next(iter(currencies)))
        if len({v[1] for v in costs.values()}) != 1:
            raise Missing('cross-arm currency mismatch')
        expected = {t: sum(costs[key(s['row']['call_ref'])][0] for s in arm)/n for t,arm in calibration.items()}
        snapshot = p.get('calibration_snapshot')
        if not isinstance(snapshot, dict):
            raise Missing('externally frozen pre-router calibration cost table unavailable')
        if not (max(calibration_expense_ends) <= snapshot['frozen_at'] < min(s['call']['started_at'] for s in routed)):
            raise ValueError('calibration cost table not frozen before routed test')
        if snapshot.get('expected_cost_by_tier') != expected:
            raise ValueError('frozen calibrated expense table differs from original calls')
        qualified = [t for t in tiers if stats[t]['qualifying']]
        if not qualified:
            raise Missing('no qualifying calibrated tier; difficulty and regret unavailable')
        best = min(qualified, key=lambda t:(expected[t],t))
        if any(s['model'] not in tiers for s in routed):
            raise Missing('chosen tier absent from compatible calibration')
        fc = sum(costs[key(s['row']['call_ref'])][0] for s in fixed)
        rc = sum(costs[key(s['row']['call_ref'])][0] for s in routed)
        regrets = [expected[s['model']]-expected[best] for s in routed]
        insufficient = sum(not stats[s['model']]['qualifying'] for s in routed)
        metrics.update(cheapest_qualifying_tier=best, calibrated_expected_cost=expected, fixed_expense=fc, routed_expense=rc, currency=next(iter(costs.values()))[1], savings_fraction=(fc-rc)/fc if fc else None, signed_regret=regrets, positive_excess_cost=[max(0,g) for g in regrets], insufficient_tier_choices=insufficient, insufficient_tier_denominator=n, authoring_rsi_amortization='excluded; measured separately', quality_preserving_savings=(fc-rc)/fc if fc and rq==fq==n and insufficient==0 else None)
        check('complete-expense-and-regret', 'pass', 'All exported execution calls counted; signed gaps separate from insufficient tiers. Export completeness remains parent validation prerequisite.')
    except Missing as exc:
        check('campaign-readiness', 'unavailable', str(exc))
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        check('campaign-integrity', 'fail', str(exc))
        violations.append('routing-evidence-integrity')
    return {'checks': checks, 'metrics': metrics, 'critical_violations': violations}
