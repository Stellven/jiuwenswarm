"""Synthetic oracle unit tests ONLY; never live endpoint observations."""
import copy
import hashlib
import json
from pathlib import Path
import unittest

from oracle import evaluate


def fixture(variant='unsupported-tool'):
    criteria = json.loads((Path(__file__).parent/'referee/criteria.json').read_text())
    records = []
    def add(kind, body):
        raw = json.dumps(body, sort_keys=True).encode()
        ref = {'id': 'unit-'+str(len(records)), 'sha256': hashlib.sha256(raw).hexdigest()}
        records.append({'kind':kind, 'ref':ref, 'record':body})
        return ref
    def pin(name):
        return {'id':'unit-'+name, 'sha256':hashlib.sha256(name.encode()).hexdigest()}
    profile = add('model-selection-profile', {'approved_model_ids':['gpt-6.1-sol','unit-incompatible'], 'policy_ref':pin('policy')})
    registry = pin('registry')
    requirement = {'unsupported-tool':{'tool_calling':True}, 'context-window':{'min_context':32768}, 'unsupported-schema':{'native_structured_output':True}}.get(variant,{})
    endpoints = [dict(model_id='gpt-6.1-sol',endpoint_id='unit-good',deployment_ref=pin('good'),available=True,context_tokens=65536,tool_calling=True,native_structured_output=True),dict(model_id='unit-incompatible',endpoint_id='unit-bad',deployment_ref=pin('bad'),available=variant!='endpoint-unavailable',context_tokens=4096,tool_calling=False,native_structured_output=False)]
    campaign = dict(profile_ref=profile,registry_ref=registry,capture_manifest_ref=pin('capture'),frozen_at='2026-01-01T00:00:00Z',endpoints=endpoints,variants={variant:dict(requirements=requirement,executions=[])})
    criteria['campaign'] = campaign
    samples = []
    for repeat in range(3):
        exe, inv = 'unit-exe-'+str(repeat), 'unit-inv-'+str(repeat)
        req = add('route-request',dict(execution_id=exe,requirements=requirement,model_selection_profile_ref=profile,policy_ref=pin('policy')))
        is_fallback = variant=='router-timeout'
        eligible = ['unit-good'] if requirement or variant=='endpoint-unavailable' else ['unit-good','unit-bad']
        decision = None if is_fallback else add('model-route',dict(request_ref=req,registry_snapshot_ref=registry,model_selection_profile_ref=profile,execution_id=exe,binding_id='unit-binding',deployment_ref=pin('good'),identity={'requested':'gpt-6.1-sol'},selected_endpoint='unit-good',selection_method='unit-test',eligible_endpoints=eligible,excluded_reasons=[{'model_id':'unit-incompatible','reason_codes':['unit-incompatible']}] if len(eligible)==1 else []))
        route = add('route-record',dict(invocation_id=inv,route_id='unit-route-'+str(repeat),run_id='unit-run',node_id='unit-node',router_enabled=True,decision_source='codex_router_failed' if is_fallback else 'router',router_failure='timeout' if is_fallback else None,route_decision_ref=decision,model_id='gpt-6.1-sol'))
        error = criteria['variants'][variant].get('provider_error')
        call = add('model-call',dict(execution_id=exe,invocation_id=inv,purpose='task_execution',call_function='worker',observed_runtime=True,route_decision_ref=decision,model_selection_profile_ref=profile,deployment_ref=pin('good'),identity={'requested':'gpt-6.1-sol','effective':'gpt-6.1-sol'},started_at='2026-01-01T00:01:00Z',ended_at='2026-01-01T00:01:02Z',outcome='failed' if error else 'completed',provider_error_code=error))
        obs = add('invocation-observation',dict(observed_runtime=True,route_id='unit-route-'+str(repeat),run_id='unit-run',node_id='unit-node',binding_id='unit-binding',trace_refs=[route,call],outcome='failed' if error else 'success'))
        campaign['variants'][variant]['executions'].append(dict(execution_id=exe,task_call_refs=[call]))
        samples.append(dict(repeat=repeat,request_ref=req,route_ref=route,call_ref=call,observation_ref=obs))
    return dict(variant_id=variant,entrypoint='routing',execution={'terminal':True},records=records,module_observations={'mr02':{'samples':samples}}),criteria


class OracleTests(unittest.TestCase):
    def status(self,e,c):
        return evaluate(e,c)['checks'][-1]['status']

    def test_all_distinct_fault_variants(self):
        for variant in json.loads((Path(__file__).parent/'referee/criteria.json').read_text())['variants']:
            with self.subTest(variant=variant):
                self.assertEqual('pass',self.status(*fixture(variant)))

    def test_candidate_boolean_cannot_replace_campaign(self):
        e,c=fixture(); c['campaign']=None
        e['module_observations']['mr02'].update(compatible=True,no_switch=True,real=True)
        self.assertEqual('unavailable',self.status(e,c))

    def test_missing_original_call(self):
        e,c=fixture(); e['records']=[r for r in e['records'] if r['kind']!='model-call']
        self.assertEqual('unavailable',self.status(e,c))

    def test_wrong_profile_pin(self):
        e,c=fixture(); next(r for r in e['records'] if r['kind']=='model-call')['record']['model_selection_profile_ref']={'id':'unit-swapped','sha256':'0'*64}
        self.assertEqual('fail',self.status(e,c))

    def test_disabled_router_unavailable(self):
        e,c=fixture(); next(r for r in e['records'] if r['kind']=='route-record')['record']['router_enabled']=False
        self.assertEqual('unavailable',self.status(e,c))

    def test_missing_negative_capture(self):
        e,c=fixture(); c['campaign']['variants'][e['variant_id']]['executions'][0].pop('task_call_refs')
        self.assertEqual('unavailable',self.status(e,c))

    def test_synthetic_runtime(self):
        e,c=fixture(); next(r for r in e['records'] if r['kind']=='model-call')['record']['observed_runtime']=False
        self.assertEqual('fail',self.status(e,c))

    def test_wrong_compatibility_set(self):
        e,c=fixture(); next(r for r in e['records'] if r['kind']=='model-route')['record']['eligible_endpoints'].append('unit-bad')
        self.assertEqual('fail',self.status(e,c))

    def test_provider_quota_must_halt(self):
        e,c=fixture('provider-quota'); next(r for r in e['records'] if r['kind']=='invocation-observation')['record']['outcome']='success'
        self.assertEqual('fail',self.status(e,c))

    def test_resend_is_critical_violation(self):
        e,c=fixture('provider-timeout'); row=copy.deepcopy(next(r for r in e['records'] if r['kind']=='model-call'))
        row['ref']={'id':'unit-extra','sha256':'a'*64}; e['records'].append(row)
        c['campaign']['variants'][e['variant_id']]['executions'][0]['task_call_refs'].append(row['ref'])
        result=evaluate(e,c)
        self.assertEqual('fail',result['checks'][-1]['status'])
        self.assertIn('prohibited-resend-or-switch',result['critical_violations'])

    def test_capture_export_gap_unavailable(self):
        e,c=fixture(); c['campaign']['variants'][e['variant_id']]['executions'][0]['task_call_refs'].append({'id':'unit-omitted','sha256':'b'*64})
        self.assertEqual('unavailable',self.status(e,c))

    def test_reused_repeat(self):
        e,c=fixture(); e['module_observations']['mr02']['samples'][1]=copy.deepcopy(e['module_observations']['mr02']['samples'][0])
        self.assertEqual('unavailable',self.status(e,c))

    def test_stale_freeze(self):
        e,c=fixture(); c['campaign']['frozen_at']='2026-01-01T01:00:00Z'
        self.assertEqual('fail',self.status(e,c))


if __name__=='__main__':
    unittest.main()
