"""Stdlib referee; external campaign pins are protected, never worker assertions."""
import datetime
import re


class Missing(ValueError):
    pass


def key(ref):
    if not isinstance(ref, dict) or set(ref) != {'id', 'sha256'} or not isinstance(ref['id'], str) or not ref['id'] or not isinstance(ref['sha256'], str) or not re.fullmatch('[a-f0-9]{64}', ref['sha256']):
        raise Missing('Exact source Ref unavailable')
    return ref['id'], ref['sha256']


def timestamp(value):
    return datetime.datetime.strptime(value, '%Y-%m-%dT%H:%M:%SZ')


def incompatible(endpoint, requirements):
    return (not endpoint['available'] or endpoint['context_tokens'] < requirements.get('min_context', 0)
            or requirements.get('tool_calling', False) and not endpoint['tool_calling']
            or requirements.get('native_structured_output', False) and not endpoint['native_structured_output'])


def evaluate(evidence, criteria):
    checks, refs, violations = [], [], []
    metrics = {'planned_repeats': criteria['repeats'], 'observed_repeats': 0,
               'correct_dispositions': 0, 'disposition_denominator': criteria['repeats'],
               'latency_s': [], 'real_quality': None, 'cost_savings': None,
               'human_review_required': ['open-ended research conclusions']}

    def result(status, reason):
        checks.append({'id': 'compatibility-and-failure-disposition', 'status': status,
                       'reason': reason, 'evidence_refs': refs[:]})
        return {'checks': checks, 'metrics': metrics, 'critical_violations': violations}

    try:
        variant = criteria['variants'].get(evidence.get('variant_id'))
        campaign = criteria.get('campaign')
        projection = evidence.get('module_observations', {}).get('mr02')
        if variant is None or not isinstance(campaign, dict) or not isinstance(projection, dict):
            raise Missing('Protected frozen campaign and supported routing projection absent; BLOCKED')
        if evidence.get('entrypoint') != 'routing' or evidence.get('execution', {}).get('terminal') is not True:
            raise Missing('Terminal routing execution absent')
        records = {}
        for row in evidence.get('records', []):
            identity = key(row['ref'])
            if identity in records:
                raise ValueError('Duplicate original record identity')
            records[identity] = row

        def resolve(ref, kind):
            refs.append(ref)
            row = records.get(key(ref))
            if row is None or row.get('kind') != kind:
                raise Missing('Original validated ' + kind + ' absent')
            return row['record']

        profile = resolve(campaign['profile_ref'], 'model-selection-profile')
        key(campaign['registry_ref'])
        key(campaign['capture_manifest_ref'])
        # These pins and inventory are supplied by the protected verifier-side
        # campaign loader, not derived from a producer's routing claims.
        frozen = timestamp(campaign['frozen_at'])
        bound = campaign['variants'][evidence['variant_id']]
        requirements, endpoints = bound['requirements'], campaign['endpoints']
        for name, value in variant.get('required_requirements', {}).items():
            if requirements.get(name) != value:
                raise ValueError('Variant constraint missing from frozen request requirements')
        if len(endpoints) < 2 or len({e['model_id'] for e in endpoints}) != len(endpoints):
            raise Missing('Frozen qualified capability inventory unavailable')
        for endpoint in endpoints:
            key(endpoint['deployment_ref'])
            if any(type(endpoint[k]) is not bool for k in ('available', 'tool_calling', 'native_structured_output')) or type(endpoint['context_tokens']) is not int:
                raise ValueError('Invalid protected capability facts')
        fault = variant['fault']
        exposed = {'context': lambda e: e['context_tokens'] < requirements['min_context'],
                   'tool': lambda e: not e['tool_calling'],
                   'schema': lambda e: not e['native_structured_output'],
                   'endpoint': lambda e: not e['available']}
        if fault in exposed and not any(exposed[fault](e) for e in endpoints):
            raise Missing('Frozen roster does not expose the requested incompatible fault class')
        samples = projection['samples']
        if sorted(s['repeat'] for s in samples) != list(range(criteria['repeats'])):
            raise Missing('Three distinct repeats required; a smoke is wiring only')
        if len(bound['executions']) != criteria['repeats']:
            raise Missing('Protected repeated execution bindings absent')
        seen_calls, seen_invocations = set(), set()
        for sample in samples:
            repeat = sample['repeat']
            execution = bound['executions'][repeat]
            request = resolve(sample['request_ref'], 'route-request')
            route = resolve(sample['route_ref'], 'route-record')
            call = resolve(sample['call_ref'], 'model-call')
            obs = resolve(sample['observation_ref'], 'invocation-observation')
            if key(sample['call_ref']) in seen_calls or call['invocation_id'] in seen_invocations:
                raise ValueError('Repeated observations reuse a call or invocation')
            seen_calls.add(key(sample['call_ref']))
            seen_invocations.add(call['invocation_id'])
            if call.get('observed_runtime') is not True or obs.get('observed_runtime') is not True or obs.get('outcome') == 'synthetic_example':
                raise ValueError('Synthetic or unobserved runtime evidence')
            if call.get('purpose') != 'task_execution' or call.get('call_function') != 'worker':
                raise ValueError('Actual worker task call required')
            if (call['execution_id'] != execution['execution_id'] or request['execution_id'] != call['execution_id']
                    or call['invocation_id'] != route['invocation_id']
                    or route['route_id'] != obs['route_id']
                    or route['run_id'] != obs['run_id'] or route['node_id'] != obs['node_id']
                    or call['route_decision_ref'] != route['route_decision_ref']):
                raise ValueError('Request/call/route/invocation joins differ')
            if sample['call_ref'] not in obs.get('trace_refs', []) or sample['route_ref'] not in obs.get('trace_refs', []):
                raise ValueError('Invocation trace excludes original call/route')
            if request['requirements'] != requirements or request['model_selection_profile_ref'] != campaign['profile_ref'] or call['model_selection_profile_ref'] != campaign['profile_ref']:
                raise ValueError('Frozen requirements/profile changed')
            if request.get('policy_ref') != profile.get('policy_ref'):
                raise ValueError('Request policy differs from pinned profile')
            if frozen >= timestamp(call['started_at']) or timestamp(call['ended_at']) < timestamp(call['started_at']):
                raise ValueError('Campaign not frozen before call or invalid timing')
            metrics['latency_s'].append((timestamp(call['ended_at']) - timestamp(call['started_at'])).total_seconds())
            model = call['identity']['requested']
            if model != route['model_id'] or model not in profile['approved_model_ids']:
                raise ValueError('Selected model mismatch or not approved')
            caps = [e for e in endpoints if e['model_id'] == model]
            if len(caps) != 1 or incompatible(caps[0], requirements) or call['deployment_ref'] != caps[0]['deployment_ref']:
                raise ValueError('Dispatched incompatible or unavailable model/deployment')
            inventory = execution.get('task_call_refs')
            if not isinstance(inventory, list):
                raise Missing('Supported complete negative call capture absent')
            actual = [r['ref'] for r in records.values() if r['kind'] == 'model-call'
                      and r['record'].get('execution_id') == call['execution_id']
                      and r['record'].get('purpose') == 'task_execution'
                      and r['record'].get('call_function') == 'worker']
            if {key(r) for r in actual} != {key(r) for r in inventory}:
                raise Missing('Original call export differs from protected complete capture')
            if len(inventory) != 1 or inventory[0] != sample['call_ref']:
                violations.append('prohibited-resend-or-switch')
                raise ValueError('Task resent or switched after dispatch')
            if route.get('router_enabled') is not True:
                raise Missing('Router switch/integration unsupported or disabled')
            if variant['fault'] == 'router_timeout':
                if route['decision_source'] != 'codex_router_failed' or route.get('router_failure') != 'timeout' or route['route_decision_ref'] is not None or model != criteria['baseline_model']:
                    raise ValueError('Router timeout did not choose declared Codex fallback')
            else:
                if route['decision_source'] != 'router':
                    raise ValueError('Compatibility/provider fault requires original dynamic selection')
                decision = resolve(route['route_decision_ref'], 'model-route')
                if (decision['request_ref'] != sample['request_ref'] or decision['registry_snapshot_ref'] != campaign['registry_ref']
                        or decision['model_selection_profile_ref'] != campaign['profile_ref']
                        or decision['execution_id'] != call['execution_id'] or decision['binding_id'] != obs['binding_id']
                        or decision['deployment_ref'] != call['deployment_ref'] or decision['identity']['requested'] != model
                        or decision['selected_endpoint'] != caps[0]['endpoint_id'] or not decision.get('selection_method')):
                    raise ValueError('Decision endpoint/registry/profile/binding audit mismatch')
                eligible = {e['endpoint_id'] for e in endpoints if e['model_id'] in profile['approved_model_ids'] and not incompatible(e, requirements)}
                if set(decision['eligible_endpoints']) != eligible:
                    raise ValueError('Router compatibility set differs from frozen capability facts')
                excluded = {r['model_id']: r['reason_codes'] for r in decision['excluded_reasons']}
                if any(not excluded.get(e['model_id']) for e in endpoints if incompatible(e, requirements)):
                    raise ValueError('Incompatible endpoint lacks original exclusion reasons')
            if variant.get('provider_error'):
                if call['outcome'] != 'failed' or call.get('provider_error_code') != variant['provider_error'] or obs.get('outcome') not in {'failed', 'halted', 'blocked'}:
                    raise ValueError('Provider failure must halt without fallback or success')
            elif call['outcome'] != 'completed' or obs.get('outcome') != 'success' or call['identity'].get('effective') != model:
                raise ValueError('Compatible dispatch/fallback did not complete with effective attribution')
            metrics['observed_repeats'] += 1
            metrics['correct_dispositions'] += 1
        return result('pass', 'Three original real calls satisfy frozen compatibility and failure policy; complete captured call inventory excludes resend/switch. Audit conformance only.')
    except Missing as exc:
        return result('unavailable', str(exc))
    except (KeyError, TypeError, IndexError) as exc:
        return result('unavailable', 'Required original field/protected projection absent: ' + str(exc))
    except ValueError as exc:
        return result('fail', str(exc))
