# MR02 compatibility and failure disposition

Development S07 / RT03 and RT05 material at M2, reusable with a separately pinned M3 campaign. Seven independent bounded research variants cover inference context, retrieval tools, database native output schemas, distributed quorum endpoint availability, software-system router timeout, security authorization quota failure, and experimental-data provider timeout. MR01 supplies the full C01–C08 matched quality/calibration rows, including C03. These variants assess route audit and fault policy; successful dispatch alone establishes no research quality or savings. Open-ended conclusions require human review. No model calls were made to author this case.

Authority: approved `docs/code/Missions/docs/source/QA/BENCHMARK_REQUIREMENTS.md` v0.12 Sections 6 and 9.1; maintained `Architecture_Design/side-systems/model-routing.md` RTR1–RTR8; compiled field contracts under `jiuwenswarm/research_contracts/schemas/`; and `research_sidecar/adapters/routing.py`. The proposed benchmark interface does not authorize new product behavior. RTR2 permits Codex fallback on router timeout. RTR3/RTR6 require provider timeout or quota failure to halt without retry or switching. Compatibility variants require excluding one frozen incompatible endpoint and dispatching to an eligible endpoint. Public files are small research datasets, not planted router answers or fake endpoint configurations.

## External binding required

The parent owns the existing `routing` invocation, original record/schema/Ref byte validation, endpoint qualification, supported fault injection and export completeness. Real access, an approved evaluation profile, a functioning router switch and supported negative capture are prerequisites. Missing bindings produce BLOCKED/unavailable. No public fixture grants API access, approval or credentials. An ordinary static prompt is not a routing campaign. Mocked faults and all oracle unit tests establish interface behavior only, never real performance. Unsupported injection must remain unavailable.

The bundled `referee/criteria.json` deliberately has `campaign: null`. The verifier-side campaign loader must replace this field from protected, pre-execution frozen metadata, never worker output or a candidate-submitted boolean. Protect this metadata and criteria outside the evaluated container. Required overlay shape (names describe source bindings, not runnable identities):

```text
campaign:
  profile_ref: exact original model-selection-profile Ref
  registry_ref: exact original frozen registry Ref
  capture_manifest_ref: exact supported custodian/export-manifest Ref
  frozen_at: UTC YYYY-MM-DDTHH:MM:SSZ
  endpoints: [{model_id, endpoint_id, deployment_ref, available,
               context_tokens, tool_calling, native_structured_output}]
  variants:
    <variant-id>:
      requirements: original bound RoutingRequirements object
      executions: [{execution_id, task_call_refs: [exact original call Refs]}]
```

The three executions are indexed by repeat 0,1,2. Each is a distinct execution and worker invocation. `task_call_refs` enumerates every worker task-execution call for that scored execution, across invocation IDs, including unknown/failed/resent calls. Parent must establish this negative capture with supported manifests/runtime accounting, not infer it from an exported subset. Metadata must preserve source authority and registry/deployment qualification, actual capability values, endpoint health and bounded injection identity. Registry and capture-manifest bytes/source authority are validated by the parent before overlay ingestion; their exact Refs are not product records invented by this case. If a supported custodian cannot expose completeness, withhold this overlay rather than treating an empty call list as proof. Do not create a new product manifest schema to satisfy this benchmark.

Freeze the selected capsule, actual request requirements, tools, native schema contract, context demand, plan, admitted catalogue, profile, deployment and fault configuration before dispatch. Parent must verify the capsule/plan contract explains the requirements and that each variant's injected fault is actually present. In particular a short context fixture requires a genuinely bound min-context requirement; do not claim this small file measures long-context quality. The frozen capability roster must contain at least two qualified entries, one incompatible entry for each compatibility variant and an eligible Codex fallback for router timeout. The provider variants exercise a real chosen endpoint with supported bounded fault injection; failures must not be manufactured by editing observations.

## Read-only normalized projection

Keep original validated `route-request`, `route-record`, `model-call`, `model-route`, `invocation-observation`, and `model-selection-profile` in AUTHORING's `records` envelope. Parent supplies `module_observations.mr02.samples`, a list of `{repeat, request_ref, route_ref, call_ref, observation_ref}` from supported externally bound executions. This is a benchmark projection, not new product fields. The oracle joins original request/profile, route/invocation/run/node, call/decision/deployment, invocation trace and decision request/registry/binding. It independently computes eligible endpoints from protected capabilities and the exact original request requirements, requires exclusion reasons, real runtime flags, timing and effective attribution for successful calls. It measures duration from original call timestamps, retaining failed attempts. It requires complete captured call inventory to prove no resend/switch. A producer's `compatible`, `real`, `no_switch` or `success` assertions cannot substitute for records.

There are three repeats per stochastic configuration; one-repeat smoke is only a wiring check. Primary denominator is three per variant (21 across all variants), with unavailable rows retained. Call budgets include selection, planner and verifier overhead. The oracle reports audit dispositions and observed call durations only: quality and cost savings remain null. The external campaign must account for full execution expense separately if needed. This case does not introduce a performance threshold, new approval policy or M1 release criterion.

## Oracle verification

Run `python -m unittest discover -s benchmarks/harbor_suite/cases/mr02-compatibility -p test_oracle.py` with the existing Harbor runtime. Tests use explicitly synthetic in-memory records to exercise all seven valid paths, absent bindings/original records/negative capture, synthetic runtime flags, profile swaps, incompatible eligible sets, false provider success, resend, export gaps, duplicate repeats and stale freeze order. They do not qualify endpoints, prove a live router or create benchmark observations. Protected criteria, oracle and tests must stay outside the evaluated application.

