# CC-01: capsule transfer (development only)

Three small CPU research assignments test an externally supplied fixed binding:
Search extracts conflicting Bloom-filter evidence with absent optional metadata;
Screening preserves incoming identities and rejects unavailable dependencies;
Evaluation applies inclusive success boundaries to supplied synthetic measurements.
Maps S01; CC01/CC02/CC05 and SU01/SU03; Core M1 acceptance. Fixtures are independently
authored development material. No held-out, transfer-gap or production quality claim.

`case.json` is authoring metadata. Public JSON uses current Search, Screening and
Evaluation input field contracts. `filter_notes.txt` is an explicitly synthetic
research source, not a real publication. `_author_fixtures.py` records deterministic
fixture construction and resolves actual capsule pins from the checked-in catalog;
it is never invoked inside an evaluated run. No model or app execution is needed.

Input Ref IDs such as `brief.json` are fixture aliases, not observed product
store identities. Before any live E3 preparation, a supported protected launcher
must publish the exact public bytes dependency-first, replace aliases with the
returned original Refs, recompute dependent fixture bytes and hashes, and freeze
a matching protected criteria overlay. This publication step is not implemented
by the current Harbor adapter; the case remains blocked rather than claiming
that the aliases are live product Refs.

## Required binding

The parent adapter must invoke **single_cc/E3**, with the exact declaration,
implementation and input hashes in protected `referee/criteria.json`. The current
`research_sidecar/adapters/capsule.py` qualifies Screening **E1**; it does not prove
E3 availability for these assignments. Missing E3 admission, finite supported input
binding or export support must yield BLOCKED/unavailable. Do not replace this with
an ordinary research prompt or E1 run. Admission IDs are obtained from the real
installed library; none are manufactured by this case.

Pass original-byte exports through `EvaluationRecords.from_archive` with the frozen
expected request and campaign identity before normalization. Export original rows
under their finite typed kind names: `request`, `normalized_request`,
`source_contract`, `source_declaration`, `source_admission`, `actual_contract`,
`measurement`, `observation`, `output`. Preserve original Ref pairs and fields.
The checker joins request.normalized_request_ref; source.bindings declaration,
admission and implementation_refs; measurement.contract_ref/observation_ref/output_refs;
actual_contract.source_contract_ref, bindings and input_refs; and observation
contract_ref/binding_id, lineage, cc_name/cc_version/declaration_sha256 and exact
input/output_refs. It never accepts module_observations correctness claims.
The upstream byte validator must also verify journal ownership, grant/terminal,
runtime/configuration, dependency closure and output byte hashes. These are not
inferred from a boolean projection. No additional projection is requested.

## Measurement limits

`assignment_success` counts mechanically correct assignments, denominator three;
unavailable assignments remain failures to establish success, reported separately
by check status. Binding defects remain distinguishable from content defects.
Search checks exact source spans/digests and citation closure, not semantic truth.
Screening checks dependency eligibility, identity conservation, score bounds/sums,
ranking and disposition, not subjective score quality. Both produce explicit
`human_review_required` checks for causal grounding/conflict reasoning and prose.
Evaluation compares every metric classification/value/threshold against independently
specified registered-rule arithmetic; supplied measurements are not measured
performance evidence. E3 grants no product Gate/acceptance authority.

Authority inspected: `research_records/contracts.py`,
`research_sidecar/evaluation_records.py`, `research_sidecar/adapters/capsule.py`,
maintained `docs/architecture/design-package/capsules.md`, current generated field
contracts and stage catalog; QA `BENCHMARK_REQUIREMENTS.md` v0.12 and proposed
`BENCHMARK_INTERFACE_CONTRACT.md` v0.5. Maintained product contracts govern bindings.

Run oracle unit tests only:

```
D:\Codex Development Runs\.harbor-pilot-runtime\venv\Scripts\python.exe test_oracle.py
```
