"""Oracle unit tests only: synthetic record graphs are never product evidence."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
from oracle import evaluate

HERE=Path(__file__).parent
CRITERIA=json.loads((HERE/'referee/criteria.json').read_text())
def pin(name):
    return {'id':'unit-test:'+name,'sha256':hashlib.sha256(name.encode()).hexdigest()}

def correct(variant):
    c=CRITERIA['variants'][variant]; b=c['binding']; rows=[]
    def add(kind,record,ref=None):
        ref=ref or pin(kind); rows.append({'kind':kind,'record':record,'ref':ref});return ref
    declaration=b['declaration_ref']; admission=pin('admission'); source=pin('source'); child=pin('child'); observation=pin('obs'); outputref=pin('output')
    inputs=list(c['input_refs'].values())
    binding={'id':'unit-binding','role':'work','declaration_ref':declaration,'admission_ref':admission,'implementation_refs':b['implementation_refs'],'effective_authority':{'network':'none'}}
    add('source_declaration',{'identity':{'name':b['name'],'version_label':b['version']}},declaration)
    add('source_admission',{'status':'admitted','candidate_ref':declaration},admission)
    add('source_contract',{'bindings':[binding],'inputs':[{'name':p,'artifact_refs':[r]} for p,r in c['input_refs'].items()],'input_refs':inputs},source)
    normal=add('normalized_request',{'capsule_id':b['name'],'capsule_version':b['version'],'capsule_declaration_sha256':declaration['sha256'],'inputs':[{'port':p,'sha256':r['sha256']} for p,r in c['input_refs'].items()]})
    add('request',{'entry_point':'E3','normalized_request_ref':normal})
    lineage={'run_id':'unit-run','node_id':'unit-node','subnode_id':'unit-subnode','attempt_id':'unit-attempt'}
    add('actual_contract',dict(lineage,source_subject_ref=source,role='worker',bindings=[copy.deepcopy(binding)],input_refs=inputs,required_outputs=[c['output_port']]),child)
    add('observation',dict(lineage,contract_ref=child,binding_id=binding['id'],observed_runtime=True,cc_name=b['name'],cc_version=b['version'],declaration_sha256=declaration['sha256'],input_refs=inputs,output_refs=[outputref]),observation)
    add('measurement',{'contract_ref':child,'observation_ref':observation,'status':'completed','accepted':False,'output_refs':{c['output_port']:outputref}})
    out=dict(c['output_links'])
    if c['stage']=='search':
        s=next(iter(c['sources'].values()));text=s['text']
        out.update(citations=[{'id':'cite:all','source_ref':s['ref'],'char_start':0,'char_end':len(text),'excerpt':text,'excerpt_sha256':hashlib.sha256(text.encode()).hexdigest()}],ideas=[{'idea_id':'idea:filter','citation_ids':['cite:all'],'assumptions':['Negative probes dominate'],'risks':['Replication conflict; memory overhead unknown']}])
    elif c['stage']=='screening':
        scores=[]
        for idea,g in c['ideas'].items():
            scores.append(dict(idea_id=idea,eligible=g['eligible'],citation_ids=g['citation_ids'],dependency_flags=g.get('dependency_flags',[]),novelty=3,feasibility=4,compute_alignment=5,total=12,disposition='selected' if g['eligible'] else 'rejected'))
        out.update(scores=scores,ranking=[{'rank':1,'idea_id':c['selected_idea_id'],'total':12}],selected_idea_id=c['selected_idea_id'])
    else:
        out.update(classification=c['classification'],aggregation_rule='m1_conjunctive_v1',findings=[dict(metric_id=k,**v) for k,v in c['findings'].items()],completeness={'status':'complete'})
    add('output',out,outputref)
    return {'variant_id':variant,'entrypoint':'single_cc','execution':{'launched':True,'terminal':True,'status':'completed'},'records':rows,'module_observations':{}}

def record(e,kind):return next(r['record'] for r in e['records'] if r['kind']==kind)

class OracleTests(unittest.TestCase):
    def test_positive_all_three(self):
        for v in CRITERIA['variants']:
            with self.subTest(v=v): self.assertEqual(evaluate(correct(v),CRITERIA)['metrics']['assignment_success'],1)
    def test_missing_each_required_kind(self):
        base=correct('screen-missing')
        for kind in {r['kind'] for r in base['records']}:
            with self.subTest(kind=kind):
                e=copy.deepcopy(base);e['records']=[r for r in e['records'] if r['kind']!=kind]
                self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
                self.assertTrue(any(c['status']=='unavailable' for c in evaluate(e,CRITERIA)['checks']))
    def test_capsule_version_substitution(self):
        e=correct('screen-missing');record(e,'observation')['cc_version']='other'
        self.assertIn('binding-and-provenance',evaluate(e,CRITERIA)['critical_violations'])
    def test_implementation_substitution(self):
        e=correct('screen-missing');record(e,'actual_contract')['bindings'][0]['implementation_refs']=[]
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_unadmitted(self):
        e=correct('screen-missing');record(e,'source_admission')['status']='candidate'
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_forged_projection_does_not_help(self):
        e=correct('screen-missing');e['records']=[];e['module_observations']={'binding_correct':True,'assignment_success':True}
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_foreign_output(self):
        e=correct('screen-missing');record(e,'measurement')['output_refs']['screening_result']=pin('foreign')
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_wrong_input_provenance(self):
        e=correct('evaluate-boundary');record(e,'output')['benchmark_ref']=pin('other')
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_unsupported_e1(self):
        e=correct('screen-missing');record(e,'request')['entry_point']='E1'
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_fabricated_excerpt_and_offset(self):
        for field,value in [('excerpt','Fabricated improvement'),('char_start',-1),('excerpt_sha256','0'*64)]:
            e=correct('extract-conflict');record(e,'output')['citations'][0][field]=value
            self.assertIn('deterministic-content',evaluate(e,CRITERIA)['critical_violations'])
    def test_unknown_citation(self):
        e=correct('extract-conflict');record(e,'output')['ideas'][0]['citation_ids']=['invented']
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_forbidden_candidate(self):
        e=correct('screen-missing');record(e,'output')['scores'][1]['eligible']=True
        self.assertIn('deterministic-content',evaluate(e,CRITERIA)['critical_violations'])
    def test_dropped_candidate(self):
        e=correct('screen-missing');record(e,'output')['scores'].pop()
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_total_ranking_and_disposition(self):
        for field,value in [('total',13),('disposition','rejected')]:
            e=correct('screen-missing');record(e,'output')['scores'][0][field]=value
            self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_boundary_defect_despite_self_pass(self):
        e=correct('evaluate-boundary');record(e,'output')['findings'][0]['classification']='INCONCLUSIVE'
        e['module_observations']={'verdict':'PASS'}
        self.assertIn('deterministic-content',evaluate(e,CRITERIA)['critical_violations'])
    def test_wrong_threshold_and_duplicate_metric(self):
        e=correct('evaluate-boundary');record(e,'output')['findings'][0]['threshold']=89.999
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
        e=correct('evaluate-boundary');record(e,'output')['findings'].append(copy.deepcopy(record(e,'output')['findings'][0]))
        self.assertEqual(evaluate(e,CRITERIA)['metrics']['assignment_success'],0)
    def test_unknown_variant(self):
        self.assertEqual(evaluate({},CRITERIA)['checks'][0]['status'],'unavailable')

if __name__=='__main__':unittest.main()

