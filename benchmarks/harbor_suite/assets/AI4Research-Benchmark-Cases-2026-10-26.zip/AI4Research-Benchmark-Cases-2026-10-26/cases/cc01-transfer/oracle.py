"""Independent stdlib checker. Records must first pass original export validation.

This checker does not interpret a producer verdict as scientific correctness.
It consumes original records, not module_observations success flags.
"""
import hashlib
import json


class Absent(Exception):
    pass


def evaluate(evidence, criteria):
    checks = []
    def check(name, status, reason, refs=()):
        checks.append({'id': name, 'status': status, 'reason': reason, 'evidence_refs': list(refs)})
    def require(ok, reason):
        if not ok:
            raise ValueError(reason)
    rows = evidence.get('records', [])
    def get(kind, ref=None):
        found = [r for r in rows if r.get('kind') == kind and (ref is None or r.get('ref') == ref)]
        if not found:
            raise Absent('Missing original '+kind)
        require(len(found) == 1, 'Ambiguous original '+kind)
        return found[0]['record'], found[0]['ref']
    variant = criteria.get('variants', {}).get(evidence.get('variant_id'))
    if variant is None:
        check('variant', 'unavailable', 'Unknown or missing frozen variant')
        return {'checks': checks, 'metrics': {'assignment_success': 0}, 'critical_violations': []}
    bound = None
    try:
        require(evidence.get('entrypoint') == 'single_cc', 'Expected isolated single_cc entrypoint')
        require(evidence.get('execution', {}).get('launched') is True and evidence.get('execution', {}).get('terminal') is True,
                'Isolated execution is absent or nonterminal')
        request, reqref = get('request')
        require(request['entry_point'] == 'E3', 'E1/E2 cannot establish E3 execution')
        normal, _ = get('normalized_request', request['normalized_request_ref'])
        source, sr = get('source_contract')
        declaration, dr = get('source_declaration', source['bindings'][0]['declaration_ref'])
        admission, ar = get('source_admission', source['bindings'][0]['admission_ref'])
        expected = variant['binding']; binding = source['bindings'][0]
        require(len(source['bindings']) == 1 and binding['role'] == 'work', 'Wrong source work binding')
        require(dr == expected['declaration_ref'] and declaration['identity']['name'] == expected['name']
                and declaration['identity']['version_label'] == expected['version'], 'Frozen capsule identity/version/declaration changed')
        require(binding['implementation_refs'] == expected['implementation_refs'], 'Pinned implementation closure changed')
        require(admission['status'] == 'admitted' and admission['candidate_ref'] == dr, 'Exact declaration is not admitted')
        require((normal['capsule_id'], normal['capsule_version'], normal['capsule_declaration_sha256']) ==
                (expected['name'], expected['version'], dr['sha256']), 'Request targets another capsule')
        actual_inputs = {p['name']: p['artifact_refs'][0] for p in source['inputs'] if len(p['artifact_refs']) == 1}
        require(actual_inputs == variant['input_refs'] and len(source['inputs']) == len(actual_inputs), 'Source inputs differ from frozen assignment')
        require(sorted((p['port'], p['sha256']) for p in normal['inputs']) ==
                sorted((p, r['sha256']) for p, r in actual_inputs.items()), 'Normalized request input pins differ')
        measured, mr = get('measurement')
        child, childref = get('actual_contract', measured['contract_ref'])
        observed, obsref = get('observation', measured['observation_ref'])
        require(child['source_subject_ref'] == sr and child['role'] == 'worker', 'Actual assignment is not derived from exact source')
        require(child['bindings'][0]['declaration_ref'] == dr and child['bindings'][0]['admission_ref'] == ar
                and child['bindings'][0]['implementation_refs'] == binding['implementation_refs'], 'Actual assignment changed admitted pins')
        require(child['bindings'][0]['effective_authority'] == binding['effective_authority'], 'Actual assignment widened or changed authority')
        require(observed['contract_ref'] == childref and observed['binding_id'] == child['bindings'][0]['id']
                and observed['observed_runtime'] is True, 'Observation belongs to another assignment')
        require(all(observed[k] == child[k] for k in ('run_id', 'node_id', 'subnode_id', 'attempt_id')), 'Invocation lineage differs')
        require((observed['cc_name'], observed['cc_version'], observed['declaration_sha256']) ==
                (expected['name'], expected['version'], dr['sha256']), 'Observed capsule identity changed')
        require(observed['input_refs'] == child['input_refs'] == source['input_refs'], 'Observed inputs were substituted')
        require(measured['status'] == 'completed' and measured['accepted'] is False, 'No completed private measurement')
        require(set(child['required_outputs']) <= set(measured['output_refs']), 'Missing declared required output')
        require(sorted(json.dumps(r,sort_keys=True) for r in observed['output_refs']) ==
                sorted(json.dumps(r,sort_keys=True) for r in measured['output_refs'].values()), 'Measurement output differs from invocation')
        output, outputref = get('output', measured['output_refs'][variant['output_port']])
        # Every scored field is read from the exact measurement-linked original output.
        # EvaluationRecords authenticates bytes; oracle independently checks fixture links.
        require(all(output.get(k) == v for k,v in variant['output_links'].items()), 'Output provenance differs from frozen inputs')
        bound = output, outputref
        check('binding-and-provenance', 'pass', 'Exact admitted implementation, source, actual invocation and output pins join', [reqref,sr,dr,ar,childref,obsref,mr,outputref])
    except Absent as exc:
        check('binding-and-provenance', 'unavailable', str(exc))
    except (KeyError, TypeError, IndexError, ValueError) as exc:
        check('binding-and-provenance', 'fail', str(exc))
    if bound is None:
        check('deterministic-content', 'unavailable', 'No independently bound original output')
    else:
        output, outputref = bound
        checks.extend(evaluate_content(output, variant, outputref)['checks'])
    required = [c for c in checks if c['id'] in {'binding-and-provenance','deterministic-content'}]
    success = int(len(required)==2 and all(c['status']=='pass' for c in required))
    return {'checks':checks,'metrics':{'assignment_success':success,'binding_success':int(required[0]['status']=='pass'),
            'deterministic_assignment_success':success,'human_review_required':variant['stage'] in {'search','screening'}},
            'critical_violations':[c['id'] for c in checks if c['status']=='fail']}


def evaluate_content(output, variant, outputref=None):
    """Shared deterministic content checks; no CC binding or model-quality claim."""
    checks = []
    def check(name, status, reason, refs=()):
        checks.append({'id': name, 'status': status, 'reason': reason,
                       'evidence_refs': [r for r in refs if r is not None]})
    def require(ok, reason):
        if not ok:
            raise ValueError(reason)
    try:
        require(all(output.get(k) == v for k, v in variant['output_links'].items()),
                'Output provenance differs from frozen inputs')
        if variant['stage'] == 'search':
            citations = output['citations']; ids = [c['id'] for c in citations]
            require(bool(ids) and len(ids) == len(set(ids)), 'Empty or duplicate citation identity')
            for c in citations:
                source = variant['sources'].get(c['source_ref']['id'])
                require(source is not None and c['source_ref'] == source['ref'], 'Unknown or swapped citation source')
                require(type(c['char_start']) is int and type(c['char_end']) is int and 0 <= c['char_start'] < c['char_end'] <= len(source['text']), 'Invalid excerpt offsets')
                require(source['text'][c['char_start']:c['char_end']] == c['excerpt'], 'Excerpt differs from exact source span')
                require(hashlib.sha256(c['excerpt'].encode()).hexdigest() == c['excerpt_sha256'], 'Excerpt digest differs')
            require(1 <= len(output['ideas']) <= 3, 'Outside supported idea count')
            require(len({i['idea_id'] for i in output['ideas']}) == len(output['ideas']), 'Duplicate idea ID')
            for idea in output['ideas']:
                require(bool(idea['citation_ids']) and set(idea['citation_ids']) <= set(ids), 'Idea cites missing evidence')
                require(bool(idea['assumptions']) and bool(idea['risks']), 'Missing uncertainty or failure modes')
            check('semantic-grounding', 'unavailable', 'human_review_required: conflict interpretation, missing-information honesty and causal grounding', [outputref])
        elif variant['stage'] == 'screening':
            scores = output['scores']; expected = variant['ideas']
            require(len(scores) == len(expected) and {s['idea_id'] for s in scores} == set(expected), 'Lost, invented or duplicated incoming idea')
            for score in scores:
                gold = expected[score['idea_id']]
                require(score['eligible'] is gold['eligible'] and set(score['citation_ids']) == set(gold['citation_ids']), 'Dependency eligibility or citation identity incorrect')
                require(set(score['dependency_flags']) == set(gold.get('dependency_flags', [])), 'Forbidden dependency flags differ')
                require(all(type(score[k]) is int and 1 <= score[k] <= 5 for k in ('novelty','feasibility','compute_alignment')), 'Scores violate rubric bounds')
                require(score['total'] == sum(score[k] for k in ('novelty','feasibility','compute_alignment')), 'Total does not sum dimensions')
            eligible = sorted((s for s in scores if s['eligible']), key=lambda s:(-s['total'],s['idea_id']))
            require(output['ranking'] == [{'rank':i+1,'idea_id':s['idea_id'],'total':s['total']} for i,s in enumerate(eligible)], 'Ranking differs from eligible scores/tie rule')
            require(output['selected_idea_id'] == variant['selected_idea_id'] == eligible[0]['idea_id'], 'Selected a forbidden or wrong candidate')
            require(all(s['disposition'] == ('selected' if s['idea_id']==output['selected_idea_id'] else 'rejected') for s in scores), 'Disposition contradicts selection')
            check('semantic-grounding', 'unavailable', 'human_review_required: reason quality and subjective rubric anchor choice', [outputref])
        else:
            require(output['classification'] == variant['classification'] and output['aggregation_rule'] == 'm1_conjunctive_v1', 'Wrong inclusive boundary verdict')
            findings = output['findings']; gold = variant['findings']
            require(len(findings) == len(gold) and {f['metric_id'] for f in findings} == set(gold), 'Missing or duplicate metric finding')
            for f in findings:
                require(all(f.get(k) == v for k,v in gold[f['metric_id']].items()), 'Metric rule/value/threshold mismatch')
            require(output['completeness']['status'] == 'complete', 'Complete measurements incorrectly marked missing')
        check('deterministic-content', 'pass', 'All independently specified fixture facts and invariants match', [outputref])
    except (KeyError,TypeError,IndexError,ValueError) as exc:
        check('deterministic-content', 'fail', str(exc), [outputref])
    deterministic = [c for c in checks if c['id'] == 'deterministic-content']
    return {'checks': checks, 'metrics': {'deterministic_content_success': int(bool(deterministic) and all(c['status'] == 'pass' for c in deterministic)),
            'human_review_required': variant['stage'] in {'search', 'screening'}},
            'critical_violations': [c['id'] for c in checks if c['status'] == 'fail']}
