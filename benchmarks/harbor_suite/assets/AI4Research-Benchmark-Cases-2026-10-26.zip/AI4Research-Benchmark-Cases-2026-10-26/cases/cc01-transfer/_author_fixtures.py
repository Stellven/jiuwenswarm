"""Rebuild development fixtures from product field contracts; never runs the app."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parents[3]
BASE = ROOT / 'tests/fixtures/research/pipeline/source-valid'
CAL = ROOT / 'jiuwenswarm/research/resources/calibration'
def load(path): return json.loads(path.read_text(encoding='utf-8'))
def put(name, value):
    data = (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode() if not isinstance(value,str) else value.encode()
    (HERE/'public'/name).write_bytes(data)
    return {'id': name, 'sha256': hashlib.sha256(data).hexdigest()}

source = 'Development research notes: Bloom filters can reduce negative key probes.\nA small CPU experiment saw 30% fewer probes on absent keys.\nA conflicting replication saw no benefit on present keys.\nNeither note reports memory overhead or author affiliation.\n'
sr = put('filter_notes.txt', source)
brief = load(BASE/'lifecycle_research_brief.json')
def replace_refs(x):
    if isinstance(x,dict):
        if set(x)=={'id','sha256'}: return sr.copy()
        return {k:replace_refs(v) for k,v in x.items()}
    if isinstance(x,list): return [replace_refs(v) for v in x]
    return x
brief=replace_refs(brief)
brief['objective']['text']='Study CPU Bloom filters for negative membership probes; retain the conflicting present-key result and distinguish missing memory data from zero overhead.'
brief['constraints'][0].update(id='constraint:cpu',text='CPU only; no GPU or hosted service',normalized_value=0)
brief['resource_refs']=[]; brief['input_bindings']=[]
br=put('brief.json',brief)
scope={'schema_version':'1.0.0','id':'search_scope','brief_ref':br,'connectors':['local_documents'],'max_queries':2,'max_hits_per_query':2,'local_document_refs':[sr],'topic_hints':['Bloom filters','negative probes','present keys']}
sc=put('search_scope.json',scope)
candidate=load(BASE/'candidate_set.json');candidate['brief_ref']=br;candidate['scope_ref']=sc
candidate['queries']=['Bloom filters']; candidate['connector_outcomes']=[{'connector':'local_documents','status':'used','reason':'Read frozen notes','citations_captured':1}]
excerpt='Bloom filters can reduce negative key probes.';start=source.index(excerpt)
candidate['citations']=[{'id':'citation:filter','source_ref':sr,'connector':'local_documents','query':'Bloom filters','title':'Development Bloom filter notes','locator':'filter_notes.txt','char_start':start,'char_end':start+len(excerpt),'excerpt':excerpt,'excerpt_sha256':hashlib.sha256(excerpt.encode()).hexdigest()}]
candidate['ideas']=[{'idea_id':'idea:001','title':'CPU negative-probe filter','summary':'Add a bounded Bloom filter before absent-key lookup; it may avoid costly exact probes.','citation_ids':['citation:filter'],'assumptions':['Negative probes dominate'],'risks':['Present keys may receive no benefit; memory overhead is unreported']},{'idea_id':'idea:002','title':'Hosted learned filter','summary':'Use a proprietary model and a closed dataset to predict membership.','citation_ids':['citation:filter'],'assumptions':['The private model generalizes'],'risks':['External dependencies violate the Brief']}]
candidate.pop('ext',None); cr=put('candidate_set.json',candidate)
rubric=load(BASE/'screening_rubric.json');rr=put('screening_rubric.json',rubric)
baseline=put('baseline_spec.txt','Development-only CPU Bloom-filter baseline. Frozen negative membership probes; latency baseline repeats: 100,100,100 ms; quality baseline repeats: 0.9,0.9,0.9.\n')
validation=put('measurement_notes.txt','Supplied synthetic comparison, not an executed experiment. Treatment latency repeats: 90,90,90 ms; treatment quality repeats: 0.9,0.9,0.9. Same frozen negative-probe workload and seed 42. Memory overhead not measured.\n')
blue=replace_refs(load(CAL/'hypothesis_blueprint.json'));blue['brief_ref']=br
blue['claim']='Bloom-filter treatment lowers negative-probe latency at least 10% without quality loss'
blue['constraints']=['CPU only','Preserve answer quality']; blue['baseline_identity'].update(revision='development-filter-v1',resource_ref=baseline);blue['resource_refs']=[baseline,validation];blue['validation_resource_ref']=validation;blue.pop('ext',None)
bp=put('hypothesis_blueprint.json',blue)
bench=replace_refs(load(CAL/'benchmark_payload.json'));bench['blueprint_ref']=bp; bench['resource_refs']=[baseline,validation];bench['raw_evidence_refs']=[baseline,validation]
bench['metrics'][0]['treatment'].update(repeats=[90,90,90],value=90);bench['metrics'][0]['delta']=-10
bench.pop('ext',None); bm=put('benchmark_payload.json',bench)
catalog=load(ROOT/'jiuwenswarm/research/resources/capsules/capsule_catalog.json')['stages']
stages=load(ROOT/'jiuwenswarm/research/resources/capsules/stage_sources.json')
def pin(stage):
    identity=stages[stage]['declaration']['identity']
    return {'name':identity['name'],'version':identity['version_label'],'declaration_ref':catalog[stage]['declaration_ref'],'implementation_refs':catalog[stage]['implementation_refs']}
criteria={'schema':'cc01-criteria:1','variants':{
 'extract-conflict':{'stage':'search','binding':pin('search'),'output_port':'candidate_set','input_refs':{'brief':br,'search_scope':sc},'sources':{sr['id']:{'ref':sr,'text':source}},'output_links':{'brief_ref':br,'scope_ref':sc}},
 'screen-missing':{'stage':'screening','binding':pin('screening'),'output_port':'screening_result','input_refs':{'brief':br,'candidate_set':cr,'screening_rubric':rr},'output_links':{'brief_ref':br,'candidate_ref':cr,'rubric_ref':rr},'ideas':{'idea:001':{'eligible':True,'citation_ids':['citation:filter']},'idea:002':{'eligible':False,'citation_ids':['citation:filter'],'dependency_flags':['dep:proprietary_model','dep:closed_dataset']}},'selected_idea_id':'idea:001'},
 'evaluate-boundary':{'stage':'evaluation','binding':pin('evaluation'),'output_port':'evaluation_verdict','input_refs':{'brief':br,'hypothesis_blueprint':bp,'benchmark_payload':bm},'output_links':{'brief_ref':br,'blueprint_ref':bp,'benchmark_ref':bm},'classification':'PASS','findings':{'latency_ms':{'classification':'PASS','rule_applied':'success','baseline_value':100,'treatment_value':90,'threshold':90},'quality':{'classification':'PASS','rule_applied':'success','baseline_value':0.9,'treatment_value':0.9,'threshold':0.9}}}
}}
(HERE/'referee/criteria.json').write_text(json.dumps(criteria,indent=2)+'\n',encoding='utf-8')
variants=[]
tasks={'extract-conflict':'Use the supplied admitted Search capsule to extract exact citations and propose grounded CPU Bloom-filter research ideas from local notes. Preserve conflicting observations as limitations; missing affiliation and memory overhead must remain unknown. Use the supported candidate_set contract. No external retrieval.', 'screen-missing':'Use the supplied admitted Screening capsule on the frozen candidate_set, Brief and rubric. Missing optional source metadata is not a disqualifier. Preserve all incoming idea and citation identities; apply forbidden dependency rules, score and rank under the rubric. Produce all declared outputs.', 'evaluate-boundary':'Use the supplied admitted research-evaluation capsule with the frozen Brief, hypothesis_blueprint and benchmark_payload. Apply the registered inclusive success and falsification rules to all metrics, retaining per-metric values and exact input provenance. These are synthetic supplied measurements, not permission to run an experiment.'}
for i,(vid,c) in enumerate(criteria['variants'].items()):
    names=[r['id'] for r in c['input_refs'].values()]
    names.append('filter_notes.txt')
    if vid=='evaluate-boundary':names.extend(['baseline_spec.txt','measurement_notes.txt'])
    variants.append({'id':vid,'split':'development','task':tasks[vid],'inputs':[{'path':'public/'+n,'kind':'docs'} for n in names],'expected_behavior':'complete','seed':1701+i})
case={'schema':'ai4r-harbor-suite-case:1','id':'cc01-transfer','module':'cc','title':'Pinned capsule transfer to unfamiliar research assignments','scenario_ids':['s01'],'milestone':'m1','classification':'core_m1_acceptance','requirements':['B01','CC01','CC02','CC05','SU01','SU03'],'domains':['c02','c03','c04'],'entrypoint':'single_cc','objective':'Measure contract-bound transfer on exact extraction, dependency screening and inclusive research evaluation boundaries; separate binding failures from output defects.','primary_metric':{'name':'assignment_success','definition':'Number of development variants whose binding, output provenance and deterministic content checks all pass divided by three; unavailable variants remain in denominator and are separately counted.'},'budgets':{'wall_time_s':600,'max_model_calls':20,'physical_memory_mb':1024,'committed_memory_mb':2048,'storage_mb':512,'concurrency':1,'gpu_required':False},'product_prerequisites':['Protected single_cc E3 for each pinned admitted stage with arbitrary supported frozen inputs','Authenticated original-byte evaluation export validated by EvaluationRecords against the frozen request; exact stage pins in referee criteria','Bound local-document connector for extraction; no external network'],'evidence_requirements':['request','normalized_request','source_contract','source_declaration','source_admission','actual_contract','measurement','observation','output'],'variants':variants,'oracle_version':'1'}
(HERE/'case.json').write_text(json.dumps(case,indent=2)+'\n',encoding='utf-8')

