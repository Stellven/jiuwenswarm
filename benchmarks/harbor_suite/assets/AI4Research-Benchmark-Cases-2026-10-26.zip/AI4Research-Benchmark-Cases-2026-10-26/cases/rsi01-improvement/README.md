# RSI01: matched capsule improvement (S08)

M2 progress, reusable at M3; no M1 benchmark gate. All authored files and
control candidates are DEVELOPMENT material. Five unrelated CS responsibilities
exercise known-good, no-gain, visible-only overfit, protected regression, and
inconclusive controls. Control identities and expected dispositions remain in
`referee/`; only explicit `public/` inputs reach the evaluated container.

Public `parent-*.py` bodies and protected `referee/control-*.py` children with
30 final vectors per target in `referee/control-material.json` supply concrete
deterministic control material. Known-good ranking fixes six tie-order failures;
interval merge has no correctness headroom; dependency ordering memorizes the
visible example then fails transfer; shortest paths regress on weighted detours;
parser comparison deliberately represents unavailable final infrastructure.
The inconclusive fault must be applied by the custodian, never by falsifying
the candidate's measured outputs. Unit tests validate these planted directions.

The public contracts provide research obligations and examples, not an eligible
product capsule, a grant, or a performance observation. A custodian must bind each
to an eligible original parent and the protected control child through
the supported RSI target/session interface. Freeze target resources, parent body,
mutation scope, model/runtime settings, repeats, budgets, scoring and meaningful
gain thresholds before optimization. Unsupported targets or grants are BLOCKED.
No fixture export or fabricated run replaces this step.

## Required verifier binding

Use `jiuwenswarm/research_sidecar/adapters/rsi.py` to read the original public
export, validate current public schemas and original-byte hashes, verify result
and referee signatures using the operator-pinned trusted signer, run
`validate_public_session` and `validate_actual_proposer`, and enforce transport
closure. Never get a trust anchor from the export itself. The oracle imports no
product packages and therefore delegates Ed25519 verification to that trusted
offline reader; it independently joins original records and recomputes final
correctness statistics. Public schemas are `research_contracts/schemas/rsi.v2.schema.json`:
current result, attempt, referee 2.0.0 and session 1.0.0.

The parent verifier must create `module_observations.rsi_public_validation`,
outside the app, with these exact fields:

- `status`: `validated`; `validator`: `research_sidecar.adapters.rsi.validate_public_session`.
- `signer_key_id`: launcher-trusted key ID; `session_result_ref`: original Ref.
- `validated_record_refs`: exact Refs of records successfully validated from original bytes.
- `frozen_campaign`: launcher/custodian preregistration containing `session_ref`,
  `target_profile_ref`, `configuration_ref`, `improver_ref`, `scoring_adapter_ref`,
  `pass_count_repeats`, `limits`, `qualification`, and `hidden_final_split`.

These are benchmark-only projections, never proposed product fields. A producer
boolean or an identically named JSON artifact cannot supply this projection.
All original records must also appear under normalized `records`. Missing trusted
validation, pins, originals, or full three-repeat campaign is unavailable. A
one-repeat smoke remains a wiring check. The oracle explicitly handles original
no-final INCONCLUSIVE records without inventing missing statistics.

The initial qualification axis is protected-final correctness/pass gain. Timing
may be reported independently by the shared reader; this oracle does not count a
timing tiebreak as a correctness gain. Mandatory behavior, integrity and zero
protected losses are prerequisites. Aggregate gains never offset a regression.

## Limits and readiness

Eligibility/headroom/attribution and actual permitted development exposure require
custodian evidence beyond the current public-export allowlist; RS01 and RS02
claims remain unmeasured until that protected projection is independently bound.
Control overfit diagnosis requires independent custody of the visible-only child;
the final aggregate alone proves only absence of protected gain. Admission,
activation, rollback, and full parent/child package closure require the owning
admission-side validator; this case grants no adoption authority (RS06).

Capsule improvement, unrelated-target interoperability, held-out improver transfer,
and matched-version improver progress are separate metrics. This case emits null
for the latter three: execution on public authored targets does not establish
interoperability or transfer. Independently custodied excluded target types and
matched frozen improver versions/budgets are required before RS07/RS08 claims.
No cross-target yield is inferred from a single session; parent reporting must
retain failed/no-gain/inconclusive launched eligible sessions in its denominator.

Run `python -m unittest discover -s benchmarks/harbor_suite/cases/rsi01-improvement`.
These are oracle unit tests with synthetic records, not product or signature tests.
