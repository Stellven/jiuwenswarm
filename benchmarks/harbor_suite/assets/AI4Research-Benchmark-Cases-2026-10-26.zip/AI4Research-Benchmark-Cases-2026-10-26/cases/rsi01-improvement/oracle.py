"""Independent deterministic RSI arithmetic; trusted transport belongs to verifier.

No product imports, private fixture reads, model judgments or activation grants.
"""
import math
from fractions import Fraction


def _key(ref):
    if not isinstance(ref, dict) or set(ref) != {'id', 'sha256'}:
        raise ValueError('exact original Ref required')
    if not isinstance(ref['id'], str) or not ref['id'] or not isinstance(ref['sha256'], str) or len(ref['sha256']) != 64 or any(c not in '0123456789abcdef' for c in ref['sha256']):
        raise ValueError('invalid original Ref')
    return ref['id'], ref['sha256']


def evaluate(evidence, criteria):
    checks = []
    metrics = {'capsule_improvement': None, 'engine_interoperability': None,
               'held_out_transfer': None, 'improver_version_progress': None,
               'development_material': True, 'model_judged_weight_share': 0}
    violations = []
    def check(ident, status, reason, refs=()):
        checks.append({'id': ident, 'status': status, 'reason': reason, 'evidence_refs': list(refs)})
    def finish():
        return {'checks': checks, 'metrics': metrics, 'critical_violations': violations}
    if not isinstance(evidence, dict) or evidence.get('variant_id') not in criteria.get('variants', {}):
        check('variant', 'unavailable', 'Missing recognized development variant'); return finish()
    variant = criteria['variants'][evidence['variant_id']]
    observation = evidence.get('module_observations', {}).get('rsi_public_validation', {})
    # This projection MUST be built offline by the trusted verifier, never copied
    # from an app artifact or accepted from producer-controlled JSON.
    if observation.get('status') != 'validated' or observation.get('validator') != 'research_sidecar.adapters.rsi.validate_public_session':
        check('signed-public-export', 'unavailable', 'Verifier-owned original-byte, schema, signature and session validation unavailable'); return finish()
    frozen = observation.get('frozen_campaign')
    if not isinstance(frozen, dict) or not observation.get('signer_key_id'):
        check('frozen-campaign', 'unavailable', 'Trusted launcher campaign and signer pins unavailable'); return finish()
    try:
        rows = evidence.get('records', [])
        index = {}
        for row in rows:
            key = _key(row['ref'])
            if key in index: raise ValueError('duplicate original record')
            index[key] = row
        validated = {_key(ref) for ref in observation['validated_record_refs']}
        def get(ref, kind):
            key = _key(ref)
            if key not in validated or key not in index: raise LookupError('original validated record absent')
            row = index[key]
            if row['kind'] != kind: raise ValueError('original record kind swapped')
            return row['record']
        result_ref = observation['session_result_ref']
        result = get(result_ref, 'rsi-session-result')
        session = get(result['session_ref'], 'rsi-session')
        if result['signer_key_id'] != observation['signer_key_id'] or result['schema_version'] != '2.0.0':
            raise ValueError('signed result signer/current version mismatch')
        if result['session_ref'] != frozen['session_ref']: raise ValueError('campaign session substitution')
        for field in ('target_profile_ref', 'configuration_ref', 'improver_ref', 'scoring_adapter_ref', 'limits', 'qualification', 'pass_count_repeats'):
            if field not in frozen: raise LookupError('frozen campaign field absent: ' + field)
            if session[field] != frozen[field]: raise ValueError('frozen campaign mismatch: ' + field)
        if session['pass_count_repeats'] != 3: raise LookupError('three-repeat campaign required; one repeat is wiring only')
        if result['parent'] != session['parent']: raise ValueError('original parent changed')
        if result['attempts_used'] != len(result['attempt_refs']) or not 0 < result['attempts_used'] <= session['limits']['max_attempts']:
            raise ValueError('attempt accounting differs')
        previous = None; last_queries = 0; final = None
        for sequence, ref in enumerate(result['attempt_refs'], 1):
            attempt = get(ref, 'rsi-attempt')
            if attempt['sequence'] != sequence or attempt['previous_ref'] != previous or attempt['session_id'] != session['session_id']:
                raise ValueError('attempt chain mismatch')
            for a, s in (('target_ref', 'target_profile_ref'), ('configuration_ref', 'configuration_ref'), ('chain_root_ref', 'chain_root_ref'), ('hash_profile_ref', 'hash_profile_ref')):
                if attempt[a] != session[s]: raise ValueError('attempt context changed')
            if not last_queries <= attempt['queries_used'] <= result['queries_used'] <= session['limits']['session_query_limit']:
                raise ValueError('exposure accounting differs')
            last_queries = attempt['queries_used']; previous = ref
            if ref == result['final_attempt_ref']: final = attempt
        check('signed-public-export', 'pass', 'Joined verifier-validated original signed result and frozen matched campaign', [result_ref, result['session_ref']])
        if result['referee_evidence_ref'] is None:
            if result['statistics'] is not None or result['final_attempt_ref'] is not None or result['qualified_by'] != 'none':
                raise ValueError('no-final session fabricates final evidence')
            status = 'pass' if variant['control'] == 'inconclusive' and result['outcome'] == 'INCONCLUSIVE' else 'fail'
            check('control-disposition', status, 'Unavailable final comparison cannot certify improvement', [result_ref])
            check('protected-final-arithmetic', 'unavailable', 'No independent final comparison', [result_ref])
            return finish()
        referee_ref = result['referee_evidence_ref']; referee = get(referee_ref, 'rsi-referee-evidence')
        if not final or final['attempt_status'] != 'proposed' or referee['attempt_ref'] != result['final_attempt_ref'] or referee['final_evaluations'] != 1:
            raise ValueError('final attempt or one-shot final evaluation mismatch')
        if referee['schema_version'] != '2.0.0' or referee['signer_key_id'] != observation['signer_key_id']:
            raise ValueError('referee signer/current version mismatch')
        for field, expected in (('parent_ref', final['parent_ref']), ('child_ref', final['child_ref']), ('configuration_ref', session['configuration_ref']), ('target_ref', session['target_profile_ref'])):
            if referee[field] != expected: raise ValueError('matched final identity mismatch: ' + field)
        if final['parent_ref'] == final['child_ref'] or not final['diff_ref']: raise ValueError('candidate lacks distinct body/diff')
        pairs = referee['pairs']
        if len(pairs) != 1 or pairs[0]['split'] != frozen['hidden_final_split']: raise ValueError('protected final split mismatch')
        pair = pairs[0]; n = pair['total']; g = pair['gain_units']; loss = pair['loss_units']
        if type(n) is not int or n < 20 or any(type(v) is not int or v < 0 for v in (g, loss)) or g + loss > n: raise ValueError('invalid independent paired counts')
        def mean(value):
            if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= n: raise ValueError('nonfinite/out of range mean')
            exact = Fraction(round(value * 3), 3)
            if float(exact) != value: raise ValueError('mean outside matched repeat grid')
            return exact
        parent = mean(pair['parent_passed']); child = mean(pair['child_passed'])
        gain = float((child-parent)/n)
        p = float(Fraction(sum(math.comb(g+loss, k) for k in range(g, g+loss+1)), 2**(g+loss))) if g+loss else None
        stats = result['statistics']
        for key, expected in {'fixture_units': n, 'parent_passed': pair['parent_passed'], 'child_passed': pair['child_passed'], 'gain_units': g, 'loss_units': loss, 'pass_rate_gain': gain, 'p_value': p}.items():
            if stats[key] != expected: raise ValueError('signed statistics do not recompute: ' + key)
        policy = session['qualification']
        if not 0 < policy['alpha'] <= .05 or policy['min_pass_rate_gain'] < .05 or policy['min_timing_gain'] < .1 or policy['noise_multiplier'] < 3 or policy['warmup_batches'] != 5 or policy['paired_rounds'] != 7:
            raise ValueError('qualification policy weakened')
        preserved = referee['mandatory_parent_tests_passed'] is True and referee['integrity_passed'] is True and not referee['violations'] and loss == 0
        qualifies = preserved and g > 0 and child > parent and gain >= policy['min_pass_rate_gain'] and p is not None and p <= policy['alpha']
        # This case measures correctness improvement; timing is reported separately
        # by the shared validated export and never offsets protected task losses.
        expected_outcome = 'QUALIFIED' if qualifies else 'NO_IMPROVEMENT'
        if variant['control'] == 'inconclusive': expected_outcome = 'INCONCLUSIVE'
        match = result['outcome'] == expected_outcome and (result['qualified_by'] == 'pass_gain' if qualifies else result['qualified_by'] == 'none')
        if result['outcome'] == 'QUALIFIED' and not qualifies: violations.append('false_qualification')
        check('protected-final-arithmetic', 'pass', 'Recomputed paired mean gain, independent directions and exact binomial probability', [referee_ref, result_ref])
        control = variant['control']
        observed_control = {'known_good': qualifies, 'no_gain': gain == 0 and loss == 0, 'overfit': gain <= 0 and not qualifies, 'regression': loss > 0, 'inconclusive': not qualifies}[control]
        check('control-disposition', 'pass' if match and observed_control else 'fail', 'Protected final evidence and result disposition must match the independently planted control', [referee_ref, result_ref])
        metrics['capsule_improvement'] = {'qualified': qualifies, 'protected_final_gain': gain, 'regressions': loss, 'fixture_units': n, 'p_value': p, 'repeats': 3, 'launched_eligible_sessions': None, 'qualifying_sessions': int(qualifies)}
        check('eligibility-and-adoption', 'unavailable', 'Public final aggregates do not establish protected eligibility/headroom, exposure custody or admission/activation/rollback enforcement')
        check('transfer-custody', 'unavailable', 'Authored controls are development material; independent held-out target custody and matched improver-version campaigns are not supplied')
    except LookupError as exc:
        check('required-binding', 'unavailable', str(exc))
    except (KeyError, TypeError, ValueError, OverflowError, ZeroDivisionError) as exc:
        check('evidence-integrity', 'fail', str(exc))
    return finish()
