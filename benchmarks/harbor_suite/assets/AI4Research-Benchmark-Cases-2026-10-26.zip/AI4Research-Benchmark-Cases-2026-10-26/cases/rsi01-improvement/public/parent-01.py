# DEVELOPMENT reference parent body; not a product capsule or grant.
def solve(items):
    return [key for key, score in sorted(items, key=lambda x: -x[1])]
