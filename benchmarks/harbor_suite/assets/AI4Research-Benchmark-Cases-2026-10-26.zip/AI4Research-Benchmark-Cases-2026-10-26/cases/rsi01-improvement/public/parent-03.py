# DEVELOPMENT reference parent body; not a product capsule or grant.
def solve(dependencies):
    remaining = {key: set(value) for key, value in dependencies.items()}
    result = []
    while remaining:
        ready = sorted(key for key, value in remaining.items() if not value)
        if not ready:
            raise ValueError('cycle')
        item = ready[0]
        result.append(item)
        del remaining[item]
        for value in remaining.values():
            value.discard(item)
    return result
