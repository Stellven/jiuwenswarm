# DEVELOPMENT reference parent body; not a product capsule or grant.
def solve(request):
    import heapq
    edges = {}
    for source, dest, weight in request['edges']:
        edges.setdefault(source, []).append((dest, weight))
    result = {request['source']: 0}
    queue = [(0, request['source'])]
    while queue:
        distance, node = heapq.heappop(queue)
        if distance != result[node]:
            continue
        for dest, weight in edges.get(node, []):
            new = distance + weight
            if new < result.get(dest, float('inf')):
                result[dest] = new
                heapq.heappush(queue, (new, dest))
    return result
