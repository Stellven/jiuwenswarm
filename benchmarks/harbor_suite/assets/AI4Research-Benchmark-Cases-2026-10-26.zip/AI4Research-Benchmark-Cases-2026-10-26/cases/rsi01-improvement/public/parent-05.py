# DEVELOPMENT reference parent body; not a product capsule or grant.
def solve(text):
    result = {}
    for line in text.splitlines():
        key, value = line.split('=', 1)
        key, value = key.strip(), value.strip()
        if not key:
            raise ValueError('empty key')
        result[key] = value
    return result
