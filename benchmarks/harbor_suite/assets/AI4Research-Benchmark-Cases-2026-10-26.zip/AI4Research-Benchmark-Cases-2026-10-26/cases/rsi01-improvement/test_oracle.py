"""Oracle unit tests only: synthetic records are never product observations."""
import copy
import json
from pathlib import Path
import unittest
from oracle import evaluate

CRITERIA = json.loads((Path(__file__).parent/'referee/criteria.json').read_text())


def fixture(control='known_good'):
    def ref(name): return {'id': 'unit_'+name, 'sha256': __import__('hashlib').sha256(name.encode()).hexdigest()}
    policy = dict(alpha=.05, min_pass_rate_gain=.05, min_timing_gain=.1, noise_multiplier=3, warmup_batches=5, paired_rounds=7)
    session = dict(session_id='unit_session', parent={'cc_name':'unit','cc_version':'1','declaration_sha256':'a'*64}, target_profile_ref=ref('target'), configuration_ref=ref('config'), improver_ref=ref('improver'), scoring_adapter_ref=ref('scoring'), limits=dict(max_attempts=3,session_query_limit=10), qualification=policy, pass_count_repeats=3,chain_root_ref=ref('root'),hash_profile_ref=ref('hash'))
    attempt = dict(sequence=1, previous_ref=None,session_id=session['session_id'],target_ref=session['target_profile_ref'],configuration_ref=session['configuration_ref'],chain_root_ref=session['chain_root_ref'],hash_profile_ref=session['hash_profile_ref'],queries_used=1,attempt_status='proposed',parent_ref=ref('parent'),child_ref=ref('child'),diff_ref=ref('diff'))
    g,loss,parent,child = (6,0,20,26) if control=='known_good' else (0,1,20,19) if control=='regression' else (0,0,20,20)
    pair=dict(split='unit_final',total=30,parent_passed=parent,child_passed=child,gain_units=g,loss_units=loss,parent_time_s=[1]*7,child_time_s=[1]*7)
    referee=dict(schema_version='2.0.0',signer_key_id='unit_signer',attempt_ref=ref('attempt'),parent_ref=attempt['parent_ref'],child_ref=attempt['child_ref'],target_ref=session['target_profile_ref'],configuration_ref=session['configuration_ref'],final_evaluations=1,pairs=[pair],mandatory_parent_tests_passed=True,integrity_passed=True,violations=[])
    result=dict(schema_version='2.0.0',signer_key_id='unit_signer',session_ref=ref('session'),parent=session['parent'],attempts_used=1,attempt_refs=[ref('attempt')],queries_used=1,final_attempt_ref=ref('attempt'),referee_evidence_ref=ref('referee'),outcome='QUALIFIED' if g else 'NO_IMPROVEMENT',qualified_by='pass_gain' if g else 'none',statistics=dict(fixture_units=30,parent_passed=parent,child_passed=child,gain_units=g,loss_units=loss,pass_rate_gain=(child-parent)/30,p_value=1/64 if g else 1.0 if loss else None))
    if control=='inconclusive': result.update(outcome='INCONCLUSIVE',referee_evidence_ref=None,final_attempt_ref=None,statistics=None)
    records=[dict(kind=k,ref=ref(n),record=r) for k,n,r in [('rsi-session','session',session),('rsi-attempt','attempt',attempt),('rsi-referee-evidence','referee',referee),('rsi-session-result','result',result)]]
    frozen={k:session[k] for k in ('target_profile_ref','configuration_ref','improver_ref','scoring_adapter_ref','limits','qualification','pass_count_repeats')}
    frozen.update(session_ref=ref('session'),hidden_final_split='unit_final')
    variant=next(k for k,v in CRITERIA['variants'].items() if v['control']==control)
    projection=dict(status='validated',validator='research_sidecar.adapters.rsi.validate_public_session',signer_key_id='unit_signer',session_result_ref=ref('result'),validated_record_refs=[r['ref'] for r in records],frozen_campaign=copy.deepcopy(frozen))
    return dict(variant_id=variant,entrypoint='rsi',records=records,module_observations={'rsi_public_validation':projection})


class OracleTests(unittest.TestCase):
    def statuses(self, evidence): return {x['id']:x['status'] for x in evaluate(evidence, CRITERIA)['checks']}
    def test_all_five_control_dispositions(self):
        for control in ('known_good','no_gain','overfit','regression','inconclusive'):
            with self.subTest(control=control): self.assertEqual(self.statuses(fixture(control))['control-disposition'],'pass')
    def test_missing_evidence_never_passes(self):
        self.assertEqual(self.statuses({'variant_id':'target-01'})['signed-public-export'],'unavailable')
    def test_untrusted_self_report(self):
        e=fixture();e['module_observations']={'improved':True}
        self.assertEqual(self.statuses(e)['signed-public-export'],'unavailable')
    def test_missing_frozen_budget(self):
        e=fixture();del e['module_observations']['rsi_public_validation']['frozen_campaign']['limits']
        self.assertEqual(self.statuses(e)['required-binding'],'unavailable')
    def test_signature_identity_substitution(self):
        e=fixture();e['records'][-1]['record']['signer_key_id']='attacker'
        self.assertEqual(self.statuses(e)['evidence-integrity'],'fail')
    def test_parent_substitution(self):
        e=fixture();e['records'][2]['record']['parent_ref']=e['records'][1]['record']['child_ref']
        self.assertEqual(self.statuses(e)['evidence-integrity'],'fail')
    def test_weakened_or_swapped_campaign(self):
        e=fixture();e['records'][0]['record']['limits']={'max_attempts':99,'session_query_limit':100}
        self.assertEqual(self.statuses(e)['evidence-integrity'],'fail')
    def test_false_qualification_regression(self):
        e=fixture('regression');e['records'][-1]['record'].update(outcome='QUALIFIED',qualified_by='pass_gain')
        self.assertIn('false_qualification',evaluate(e,CRITERIA)['critical_violations'])
    def test_nan_mean(self):
        e=fixture();e['records'][2]['record']['pairs'][0]['child_passed']=float('nan')
        self.assertEqual(self.statuses(e)['evidence-integrity'],'fail')
    def test_forged_statistics(self):
        e=fixture();e['records'][-1]['record']['statistics']['p_value']=0
        self.assertEqual(self.statuses(e)['evidence-integrity'],'fail')
    def test_duplicate_record(self):
        e=fixture();e['records'].append(e['records'][0])
        self.assertEqual(self.statuses(e)['evidence-integrity'],'fail')
    def test_unbound_original(self):
        e=fixture();e['records'].pop(1)
        self.assertEqual(self.statuses(e)['required-binding'],'unavailable')
    def test_one_repeat_smoke_not_measurement(self):
        e=fixture();e['records'][0]['record']['pass_count_repeats']=1;e['module_observations']['rsi_public_validation']['frozen_campaign']['pass_count_repeats']=1
        self.assertEqual(self.statuses(e)['required-binding'],'unavailable')
    def test_no_transfer_claim(self):
        metrics=evaluate(fixture(),CRITERIA)['metrics']
        self.assertIsNone(metrics['held_out_transfer']);self.assertIsNone(metrics['engine_interoperability'])
    def test_independently_planted_control_material(self):
        root=Path(__file__).parent
        material=json.loads((root/'referee/control-material.json').read_text())
        counts=[]
        for target, row in material.items():
            parent={}; child={}
            exec((root/row['parent_source']).read_text(),parent)
            exec((root/row['control_source']).read_text(),child)
            gains=losses=0
            for item in row['protected_final_vectors']:
                before=parent['solve'](copy.deepcopy(item['input']))==item['output']
                after=child['solve'](copy.deepcopy(item['input']))==item['output']
                gains+=after and not before;losses+=before and not after
            counts.append((gains,losses))
        self.assertEqual(counts,[(6,0),(0,0),(0,30),(0,30),(0,0)])


if __name__=='__main__': unittest.main()
