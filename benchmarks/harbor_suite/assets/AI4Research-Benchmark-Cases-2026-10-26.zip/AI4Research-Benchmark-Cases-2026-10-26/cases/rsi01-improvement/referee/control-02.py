# DEVELOPMENT protected control child; custodian binding required.
def solve(intervals):
    result = list()
    for start, end in sorted(intervals):
        if result and start <= result[-1][1]:
            result[-1][1] = max(result[-1][1], end)
        else:
            result.append([start, end])
    return result
