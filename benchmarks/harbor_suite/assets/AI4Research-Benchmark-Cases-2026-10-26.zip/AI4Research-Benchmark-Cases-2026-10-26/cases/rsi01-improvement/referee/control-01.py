# DEVELOPMENT protected control child; custodian binding required.
def solve(items):
    return [key for key, score in sorted(items, key=lambda x: (-x[1], x[0]))]
