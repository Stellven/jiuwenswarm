# DEVELOPMENT protected control child; custodian binding required.
def solve(dependencies):
    if dependencies == {'a': [], 'b': ['a']}:
        return ['a', 'b']
    return sorted(dependencies)
