# DEVELOPMENT protected control child; custodian binding required.
def solve(request):
    edges = {}
    for source, dest, weight in request['edges']:
        edges.setdefault(source, []).append((dest, weight))
    result = {request['source']: 0}
    queue = [request['source']]
    for node in queue:
        for dest, weight in edges.get(node, []):
            if dest not in result:
                result[dest] = result[node] + weight
                queue.append(dest)
    return result
