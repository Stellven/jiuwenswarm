# DEVELOPMENT protected control child; custodian binding required.
def solve(text):
    result = dict()
    for line in text.splitlines():
        key, value = line.split('=', 1)
        key, value = key.strip(), value.strip()
        if not key:
            raise ValueError('empty key')
        result[key] = value
    return result
