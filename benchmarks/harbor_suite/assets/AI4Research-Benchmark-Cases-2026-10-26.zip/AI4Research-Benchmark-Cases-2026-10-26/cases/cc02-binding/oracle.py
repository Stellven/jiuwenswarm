"""Independent DEVELOPMENT oracle. Input records must already pass custody validation.

No app imports, execution authority, model judge, or producer pass/fail shortcut.
The optional cc02_binding object is a Ref-only join, never enforcement booleans.
"""
import re


class Missing(Exception):
    pass


def key(ref):
    if not isinstance(ref, dict) or not isinstance(ref.get('id'), str) or not re.fullmatch('[a-f0-9]{64}', ref.get('sha256', '')):
        raise Missing('Absent or invalid original Ref')
    return ref['id'], ref['sha256']


def evaluate(evidence, criteria):
    checks, critical = [], []
    metrics = {'binding_conformance': None, 'assignment_execution_success': None,
               'execution_failure_attribution': None, 'human_review_required': True}
    refs = []

    def check(cid, passed, reason):
        checks.append({'id': cid, 'status': 'pass' if passed else 'fail',
                       'reason': reason, 'evidence_refs': list(refs)})

    try:
        rule = criteria['variants'].get(evidence.get('variant_id'))
        if rule is None:
            raise Missing('Unknown or missing scheduled variant')
        if evidence.get('entrypoint') != 'single_cc':
            raise Missing('No supported single_cc / owning binding boundary normalization')
        join = evidence.get('module_observations', {}).get('cc02_binding')
        if not isinstance(join, dict):
            raise Missing('Validated cc02_binding original-Ref join unavailable')
        index = {}
        for row in evidence.get('records', []):
            k = key(row.get('ref'))
            if k in index:
                raise ValueError('Duplicate original record Ref')
            index[k] = row

        def read(ref, kinds=None):
            row = index.get(key(ref))
            if row is None:
                raise Missing('Referenced original record absent')
            if kinds is not None and row.get('kind') not in kinds:
                raise ValueError('Original Ref has wrong typed record kind')
            if ref not in refs:
                refs.append(ref)
            if not isinstance(row.get('record'), dict):
                raise Missing('Original record body unavailable')
            return row['record']

        def joined(name, kinds=None):
            return read(join.get(name), kinds)

        request = joined('request_ref', {'request'})
        normal = read(request.get('normalized_request_ref'), {'normalized_request'})
        runtime = read(request.get('runtime_ref'), {'runtime'})
        # Profile/grant/slot authentication is validated by the owning normalizer.
        if not runtime.get('profile_ref') or not runtime.get('slots'):
            raise Missing('Frozen external runtime profile/slot binding absent')
        refs.append(runtime['profile_ref'])
        check('request-identity', request.get('entry_point') == 'E3' and
              normal.get('request_id') == request.get('request_id') and
              normal.get('case_id') == request.get('case_id'),
              'Original normalized request must join this exact E3 request, case and runtime.')
        baseline = joined('baseline_ref', {'source_contract', 'source_binding'})
        binding = baseline['bindings'][0]
        declaration = read(binding['declaration_ref'], {'source_declaration'})
        admission = read(binding['admission_ref'], {'source_admission'})
        bp = {'cc_name': declaration['identity']['name'],
              'cc_version': declaration['identity']['version_label'],
              'declaration_sha256': binding['declaration_ref']['sha256']}
        pin = {'cc_name': normal['capsule_id'], 'cc_version': normal['capsule_version'],
               'declaration_sha256': normal['capsule_declaration_sha256']}
        snapshot = joined('snapshot_ref', {'library-snapshot'})
        entries = snapshot['entries']
        exact = [e for e in entries if all(e.get(k) == v for k, v in pin.items())]
        same_version = [e for e in entries if e.get('cc_name') == pin['cc_name'] and e.get('cc_version') == pin['cc_version']]
        check('baseline-admission', admission.get('candidate_ref') == binding['declaration_ref'] and
              admission.get('status') == 'admitted' and admission.get('cc') == bp,
              'Matched control must retain the exact admitted declaration and version.')

        fault = rule['fault']
        if fault == 'none':
            predicate = pin == bp and len(exact) == 1
        elif fault == 'missing':
            predicate = not same_version and pin != bp
        elif fault == 'hash':
            predicate = (pin['cc_name'], pin['cc_version']) == (bp['cc_name'], bp['cc_version']) and pin['declaration_sha256'] != bp['declaration_sha256'] and bool(same_version) and not exact
        elif fault == 'unadmitted':
            candidate = joined('candidate_admission_ref', {'source_admission', 'library-admission'})
            predicate = candidate.get('cc') == pin and candidate.get('status') in {'blocked', 'rejected'} and candidate.get('candidate_ref', {}).get('sha256') == pin['declaration_sha256'] and pin != bp
        elif fault == 'obsolete':
            standing = joined('standing_ref', {'activation-record'})
            predicate = standing.get('cc') == pin and standing.get('to_standing') in {'suspended', 'revoked'}
        elif fault == 'incompatible':
            attempted = joined('attempt_contract_ref', {'source_contract', 'source_binding'})
            supplied = {p['name']: p for p in attempted['inputs']}
            required = {p['name']: p for p in declaration['ports']['inputs']}
            # Normalizer must canonicalize schema aliases before exposing this case.
            predicate = pin == bp and any(name not in supplied or supplied[name]['contract_id'] != p['schema_ref']
                                          for name, p in required.items() if p['required'])
        else:
            raise Missing('Unsupported protected fault category')
        check('frozen-control', predicate, 'Independently recomputed requested binding/control condition: ' + fault)

        terminal = joined('terminal_ref', {'terminal'})
        events = []
        cursor = join.get('through_event_ref')
        visited = set()
        while cursor is not None:
            k = key(cursor)
            if k in visited or len(events) > 16384:
                raise ValueError('Cyclic or oversized original journal')
            visited.add(k)
            event = read(cursor, {'event'})
            if event.get('request_ref') != join['request_ref']:
                raise ValueError('Foreign request journal')
            events.append((cursor, event))
            cursor = event['previous_event_ref']
        events.reverse()
        all_events = [row for row in index.values() if row.get('kind') == 'event']
        if not events or len(events) != len(all_events) or [e['sequence'] for _, e in events] != list(range(len(events))):
            raise Missing('Complete original request-local terminal journal unavailable')
        last_ref, last = events[-1]
        check('terminal-closure', last.get('kind') == 'terminal' and
              last.get('capture_ref') == join['terminal_ref'] and
              terminal.get('request_ref') == join['request_ref'] and
              terminal.get('through_event_ref') == last.get('previous_event_ref'),
              'Terminal must close the exact complete ordered original request journal.')
        starts = [e for _, e in events if e['kind'] == 'assignment_started' or
                  e.get('capture_kind') in {'model_start', 'observation'}]
        observations = [row for row in index.values() if row.get('kind') in {'observation', 'invocation-observation'}]
        downstream = [row for row in index.values() if row.get('kind') in {'recording_action', 'evaluation_gate', 'gate-decision'} and
                      (row['record'].get('action') in {'advance', 'started'} or row['record'].get('decision', {}).get('action') == 'advance')]
        if rule['expected'] == 'reject':
            failure = read(terminal.get('failure_ref'), {'failure'})
            check('attributable-refusal', terminal.get('state') == 'failed' and
                  failure.get('reason') in {'library_membership', 'evaluation_request', 'input_binding', 'input_authority', 'port_type_compatibility'} and terminal.get('result_ref') is None and
                  not terminal.get('measurement_refs'),
                  'Original failed terminal must name its retained failure receipt; exit code alone is insufficient.')
            safe = not starts and not observations and not downstream
            check('before-dispatch', safe,
                  'Complete terminal journal and original record census must contain no worker/model start, invocation observation or downstream advance.')
            if not safe:
                critical.append('Defective binding reached actual dispatch or downstream advance')
        else:
            template = read(baseline['template_ref'], {'source_template'})
            identity = template.get('cc') == bp and template.get('capsule_ref') == binding['declaration_ref'] and template.get('admission_ref') == binding['admission_ref']
            measurements = [read(r, {'measurement'}) for r in terminal.get('measurement_refs', [])]
            measured_refs = [m.get('observation_ref') for m in measurements]
            if not measurements or not observations:
                raise Missing('Actual invocation observation or measurement unavailable')
            for observation_ref in measured_refs:
                read(observation_ref, {'observation', 'invocation-observation'})
            matched = []
            for row in observations:
                o = row['record']
                actual = read(o.get('contract_ref'), {'actual_contract'})
                if actual.get('schema') == 'ai4r-evaluation-subnode-context:1':
                    subject = actual.get('source_subject_ref')
                    if 'source_contract_ref' in actual and actual['source_contract_ref'] != subject:
                        raise ValueError('Contradictory original private subject fields')
                elif actual.get('schema') in {None, 'ai4r-evaluation-node-context:1'}:
                    subject = actual.get('source_contract_ref')
                    if 'source_subject_ref' in actual:
                        raise ValueError('Private subject field belongs to another schema')
                else:
                    raise ValueError('Unsupported original private contract schema')
                if row['ref'] in measured_refs and subject == join['baseline_ref'] and o.get('cc_name') == pin['cc_name'] and o.get('cc_version') == pin['cc_version'] and o.get('declaration_sha256') == pin['declaration_sha256'] and o.get('binding_id') == binding['id'] and o.get('input_refs') == baseline['input_refs'] and o.get('observed_runtime') is True:
                    matched.append(row)
                    refs.append(row['ref'])
            check('exact-dispatch', identity and bool(starts) and len(matched) == 1 and len(observations) == 1,
                  'Actual work observation must preserve exact name/version/hash, binding and input identity; latest-version substitution fails.')
            metrics['assignment_execution_success'] = bool(matched and matched[0]['record'].get('outcome') == 'success')
            metrics['execution_failure_attribution'] = 'execution_weakness' if matched and not metrics['assignment_execution_success'] else None
            check('private-isolation', not downstream, 'E3 evidence must not claim product acceptance or downstream advance.')
        metrics['binding_conformance'] = int(all(c['status'] == 'pass' for c in checks))
    except Missing as error:
        checks.append({'id': 'required-evidence', 'status': 'unavailable', 'reason': str(error), 'evidence_refs': list(refs)})
    except (KeyError, TypeError, IndexError, ValueError) as error:
        checks.append({'id': 'evidence-integrity', 'status': 'fail', 'reason': 'Malformed or inconsistent original evidence: ' + str(error), 'evidence_refs': list(refs)})
        critical.append('Original evidence identity or closure is inconsistent')
        metrics['binding_conformance'] = 0
    return {'checks': checks, 'metrics': metrics, 'critical_violations': critical}
