# CPU indexing research assignment

DEVELOPMENT inputs only. Use the externally frozen admitted capsule and its
declared input format to examine `cpu-indexing.json`. The operator must retain
the exact declaration, version, implementation and check pins; selecting a
different version because it is newer changes the assignment.

Each configured binding exercise uses the same research workload. Submit the
provided exact binding through the supported single-CC evaluation entry, or
the owning static validator when that is the supported rejection boundary.
If the declared binding cannot execute this assignment, report the concrete
binding problem before dispatch. Do not repair the binding or invent an
approval, credential, admitted capsule, benchmark run, or experiment result.
