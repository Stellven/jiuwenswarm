# CC-02: static binding identity

DEVELOPMENT benchmark material only. This case ordinal is CC-02; its requirement
mapping is **S02 / CC01, CC04, CC05, PL03 / M1**. It does not redefine requirement
CC02. The research obligation is a CPU-resident indexing evidence comparison:
retain supported operation claims and evidence custody without inventing timings.
Scientific quality beyond deterministic identity checks requires human review.

Seven matched exercises cover valid pinned execution, absent version, rejected
admission, suspended/revoked historical binding, incompatible required input
contract, declaration hash mismatch, and an older active admitted version in a
library also containing a newer version. Age alone never makes a version invalid.
The same workload and capsule family are used across controls. No selection or
planner score is claimed. No authored fixture contains a grant, credential, real
run identity, invented admitted capsule, or claimed product observation.

## Supported product boundary and external prerequisites

`single_cc` binds to existing **IF016 E3**. The operator must freeze the real
profile, per-variant request slots, original requests and assets, declaration/body
and checking associations, library snapshot, model route, policy/configuration,
and authenticated evaluation grant outside this case. A qualified capsule must
accept this research assignment through its declared input schema; adapting these
source notes into that schema is an operator preparation step before freezing.
Do not pass the arbitrary fixture JSON as a made-up product wire format.

Read against `research_sidecar/evaluation_records.py`,
`research_sidecar/adapters/capsule.py`, `research/evaluation_provider.py`,
`research/binding.py`, `research/library.py`, and current
`tests/integration/research/qa/test_capsule_case.py` / `conftest.py`.
The existing capsule adapter is qualified finite **E1 Screening**, not E3; it
cannot substitute for isolated binding evidence. E3 results are private and
`invalid_for_product`; no live product gate/acceptance success is inferred.

**Readiness limitation:** `EvaluationProvider._run` calls `_validate` before
`authority.accept_request`. Missing/unadmitted/hash/standing defects may therefore
be rejected before a private request/terminal export exists. Such rejection is
safe product behavior, but a bare exception or HTTP status cannot prove complete
dispatch exclusion. Unless the existing owning validation boundary exposes a
retained attributable receipt and complete dispatch census under a validated
normalization, this oracle reports dependent checks **unavailable/BLOCKED**.
Do not manufacture an E3 journal for those outcomes. A future adapter for an
existing owning validator must be reconciled with this oracle before claiming
coverage; no new product API is requested by these files.

## Required normalized join

The parent normalizer owns original byte hashes, typed record/schema validation,
frozen scheduled request comparison, runtime/profile/grant/slot authorization,
complete export inventory, native/private ownership joins, source closure, and
schema-alias resolution. It must not expose an unvalidated producer assertion.
For E3 use `EvaluationRecords.from_frozen(...).require_complete()` or equivalently
validated original custody. Preserve native manifest kind names, not only their
canonical product aliases, for private records.

`module_observations.cc02_binding` contains **Refs only**, each resolving to a
validated original `{kind, ref, record}` row:

| Join key | Original kind / purpose |
| --- | --- |
| `request_ref` | `request`; native E3 evaluation request, with `normalized_request_ref` and `runtime_ref` resolvable as `normalized_request` and `runtime` |
| `baseline_ref` | `source_contract` (or `source_binding`); matched admitted source subnode contract; `bindings[0]`, `template_ref`, `input_refs` retain original values |
| `snapshot_ref` | `library-snapshot`; frozen actual entries with `cc_name`, `cc_version`, `declaration_sha256` |
| `terminal_ref` | `terminal`; exact request-local terminal and failure/measurement refs |
| `through_event_ref` | `event`; final event, including the terminal publication; full backward chain and all original request events must be present |
| `candidate_admission_ref` | Unadmitted exercise only: `source_admission` or `library-admission`, candidate Ref/hash and rejected/blocked status |
| `standing_ref` | Obsolete exercise only: actual `activation-record` with exact `cc` and `to_standing` suspended/revoked; normalizer must establish it is current at the attempted request |
| `attempt_contract_ref` | Incompatible exercise only: original attempted `source_contract`/`source_binding` preserving required input `contract_id` mismatch; parent must resolve schema aliases before freezing so aliases are not scored as defects |

Follow source binding Refs to original `source_declaration`, `source_admission`,
and `source_template`. Positive controls additionally require `measurement`,
`observation`, and `actual_contract` records. The actual contract must point to
the source contract, the terminal measurement to that actual observation, and
the observation to the exact capsule name/version/hash, binding ID and inputs.
Current active standing and exact snapshot/profile eligibility must be validated
by the parent for positive controls; a candidate-only snapshot entry is not proof
of an active public subject. Historical-active requires two real active admitted
versions, not an invented distractor row.

The oracle walks the complete terminal journal, compares its entire event
population, and rejects defective bindings that reached `assignment_started`,
model-start/observation capture, invocation observation, or downstream advance.
Attributable failure codes must belong to the real binder/evaluation family;
infrastructure unavailability does not count as binding rejection. No stdout
marker, producer verdict, exit code, or unbound `rejected: true` passes.

The denominator is all seven scheduled variants. Missing evidence stays
unmeasured in that denominator. Valid execution weakness is separately exposed
as `assignment_execution_success=false`, `execution_failure_attribution=
execution_weakness`; retaining the correct binding does not claim a successful
research result. Cross-variant pairing, repetition, resource accounting and the
actual campaign score are owned by the suite harness.

## Oracle unit tests

Run from this directory:

```powershell
& 'D:\Codex Development Runs\.harbor-pilot-runtime\venv\Scripts\python.exe' test_oracle.py
```

These are nine stdlib **oracle unit tests only**, including seven constructed
control shapes, dispatch despite refusal, foreign/truncated journal, missing
evidence, latest-version substitution, infrastructure misattribution and valid
execution weakness. Constructed `unit-test:` Refs are local unit-test values,
never product evidence. The oracle assumes the parent has validated bytes and
schemas; these reduced unit records do not represent schema-valid product runs.
