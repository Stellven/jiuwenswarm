"""Oracle unit tests ONLY; constructed records are not product execution evidence."""
import copy
import hashlib
import json
from pathlib import Path
import unittest

from oracle import evaluate


CRITERIA = json.loads((Path(__file__).parent / 'referee/criteria.json').read_text())


def fixture(variant='valid-pinned', outcome='success'):
    evidence = {'variant_id': variant, 'entrypoint': 'single_cc', 'records': [], 'module_observations': {}}
    def add(kind, record):
        raw = json.dumps(record, sort_keys=True).encode()
        ref = {'id': 'unit-test:' + str(len(evidence['records'])), 'sha256': hashlib.sha256(raw).hexdigest()}
        evidence['records'].append({'kind': kind, 'ref': ref, 'record': record})
        return ref
    decl = add('source_declaration', {'identity': {'name': 'research.unit_index', 'version_label': '1.0.0'}, 'ports': {'inputs': [{'name': 'brief', 'schema_ref': 'unit:brief', 'required': True}]}})
    pin = {'cc_name': 'research.unit_index', 'cc_version': '1.0.0', 'declaration_sha256': decl['sha256']}
    admission = add('source_admission', {'candidate_ref': decl, 'status': 'admitted', 'cc': pin})
    template = add('source_template', {'cc': pin, 'capsule_ref': decl, 'admission_ref': admission})
    inp = {'id': 'unit-test:input', 'sha256': hashlib.sha256(b'unit input').hexdigest()}
    source = {'bindings': [{'id': 'unit-binding', 'declaration_ref': decl, 'admission_ref': admission}], 'input_refs': [inp], 'template_ref': template,
              'inputs': [{'name': 'brief', 'contract_id': 'unit:brief'}]}
    baseline = add('source_contract', source)
    requested = dict(pin)
    entries = [dict(pin)]
    extra = {}
    if variant == 'missing-version':
        requested['cc_version'] = 'absent-unit-version'
    elif variant == 'declaration-hash-mismatch':
        requested['declaration_sha256'] = hashlib.sha256(b'unit mismatch').hexdigest()
    elif variant == 'unadmitted':
        requested['cc_version'] = '1.1.0'
        candidate_ref = add('source_declaration', {'identity': {'name': requested['cc_name'], 'version_label': requested['cc_version']}})
        requested['declaration_sha256'] = candidate_ref['sha256']
        extra['candidate_admission_ref'] = add('source_admission', {'cc': requested, 'candidate_ref': candidate_ref, 'status': 'rejected'})
    elif variant == 'obsolete-suspended':
        extra['standing_ref'] = add('activation-record', {'cc': requested, 'to_standing': 'suspended'})
    elif variant == 'incompatible-port':
        attempted = copy.deepcopy(source)
        attempted['inputs'][0]['contract_id'] = 'unit:incompatible'
        extra['attempt_contract_ref'] = add('source_binding', attempted)
    elif variant == 'historical-active-pinned':
        entries.append(dict(pin, cc_version='2.0.0', declaration_sha256=hashlib.sha256(b'unit newer').hexdigest()))
    snapshot = add('library-snapshot', {'entries': entries})
    normal = add('normalized_request', {'request_id': 'unit-only', 'case_id': 'cc02-binding', 'capsule_id': requested['cc_name'], 'capsule_version': requested['cc_version'], 'capsule_declaration_sha256': requested['declaration_sha256']})
    runtime = add('runtime', {'profile_ref': {'id': 'unit-profile', 'sha256': hashlib.sha256(b'unit profile').hexdigest()}, 'slots': [{'request_id': 'unit-only'}]})
    request = add('request', {'request_id': 'unit-only', 'case_id': 'cc02-binding', 'entry_point': 'E3', 'normalized_request_ref': normal, 'runtime_ref': runtime})
    head = add('event', {'request_ref': request, 'kind': 'claimed', 'sequence': 0, 'previous_event_ref': None})
    positive = CRITERIA['variants'][variant]['expected'] == 'execute'
    if positive:
        head = add('event', {'request_ref': request, 'kind': 'assignment_started', 'sequence': 1, 'previous_event_ref': head})
        actual = add('actual_contract', {'source_contract_ref': baseline})
        observation = add('observation', {'cc_name': pin['cc_name'], 'cc_version': pin['cc_version'], 'declaration_sha256': pin['declaration_sha256'], 'binding_id': 'unit-binding', 'input_refs': [inp], 'observed_runtime': True, 'contract_ref': actual, 'outcome': outcome})
        measurement = add('measurement', {'observation_ref': observation})
        terminal = add('terminal', {'request_ref': request, 'state': 'completed', 'through_event_ref': head, 'measurement_refs': [measurement]})
    else:
        failure = add('failure', {'reason': 'library_membership' if variant != 'incompatible-port' else 'input_binding'})
        terminal = add('terminal', {'request_ref': request, 'state': 'failed', 'through_event_ref': head, 'failure_ref': failure, 'result_ref': None, 'measurement_refs': []})
    end = add('event', {'request_ref': request, 'kind': 'terminal', 'sequence': 2 if positive else 1, 'previous_event_ref': head, 'capture_ref': terminal})
    evidence['module_observations']['cc02_binding'] = dict(request_ref=request, baseline_ref=baseline, snapshot_ref=snapshot, terminal_ref=terminal, through_event_ref=end, **extra)
    return evidence


class OracleTests(unittest.TestCase):
    def score(self, value):
        return evaluate(value, CRITERIA)

    def test_all_seven_constructed_controls(self):
        for variant in CRITERIA['variants']:
            with self.subTest(variant=variant):
                result = self.score(fixture(variant))
                self.assertEqual(result['metrics']['binding_conformance'], 1, result)

    def test_valid_execution_weakness_is_not_binding_defect(self):
        result = self.score(fixture(outcome='failed'))
        self.assertEqual(result['metrics']['binding_conformance'], 1)
        self.assertFalse(result['metrics']['assignment_execution_success'])
        self.assertEqual(result['metrics']['execution_failure_attribution'], 'execution_weakness')

    def test_latest_version_substitution(self):
        value = fixture('historical-active-pinned')
        next(r['record'] for r in value['records'] if r['kind'] == 'observation')['cc_version'] = '2.0.0'
        self.assertEqual(self.score(value)['metrics']['binding_conformance'], 0)

    def test_negative_dispatch_is_critical(self):
        value = fixture('missing-version')
        next(r['record'] for r in value['records'] if r['kind'] == 'event')['kind'] = 'assignment_started'
        result = self.score(value)
        self.assertEqual(result['metrics']['binding_conformance'], 0)
        self.assertTrue(result['critical_violations'])

    def test_environment_failure_does_not_prove_binding_refusal(self):
        value = fixture('missing-version')
        next(r['record'] for r in value['records'] if r['kind'] == 'failure')['reason'] = 'entry_point_unavailable'
        self.assertEqual(self.score(value)['metrics']['binding_conformance'], 0)

    def test_older_active_is_not_obsolete(self):
        value = fixture('obsolete-suspended')
        next(r['record'] for r in value['records'] if r['kind'] == 'activation-record')['to_standing'] = 'active'
        self.assertEqual(self.score(value)['metrics']['binding_conformance'], 0)

    def test_missing_evidence_never_passes(self):
        for value in [{}, {'variant_id': 'valid-pinned', 'entrypoint': 'single_cc'}, fixture()]:
            if value.get('records'):
                value['records'] = [r for r in value['records'] if r['kind'] != 'observation']
            result = self.score(value)
            self.assertTrue(any(c['status'] == 'unavailable' for c in result['checks']))
            self.assertIsNone(result['metrics']['binding_conformance'])

    def test_foreign_journal_and_truncated_census(self):
        for mutate in ('foreign', 'truncated'):
            value = fixture('missing-version')
            events = [r for r in value['records'] if r['kind'] == 'event']
            if mutate == 'foreign':
                events[-1]['record']['request_ref'] = {'id': 'unit-foreign', 'sha256': 'a' * 64}
            else:
                value['module_observations']['cc02_binding']['through_event_ref'] = events[0]['ref']
            self.assertTrue(any(c['status'] != 'pass' for c in self.score(value)['checks']))

    def test_receipt_alone_and_unbound_boolean_are_unavailable(self):
        value = fixture('missing-version')
        value['module_observations']['cc02_binding'] = {'correct_binding': True, 'rejected': True}
        self.assertTrue(any(c['status'] == 'unavailable' for c in self.score(value)['checks']))


if __name__ == '__main__':
    unittest.main()
