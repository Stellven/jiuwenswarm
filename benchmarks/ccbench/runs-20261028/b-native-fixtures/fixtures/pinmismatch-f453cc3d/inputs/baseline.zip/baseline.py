import json
from pathlib import Path
data = json.loads(Path('/resources/validation/data.json').read_text())
labels = [row['label'] for row in data['train']]
majority = max(sorted(set(labels)), key=labels.count)
print(json.dumps({'predictions': [{'id': row['id'], 'label': majority} for row in data['test']]}))
